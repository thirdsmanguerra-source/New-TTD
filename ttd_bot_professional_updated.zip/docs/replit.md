# Toilet Tower Defense Discord Bot

## Overview
A Discord game bot inspired by the Roblox game "Toilet Tower Defense" - a tower defense game where players defend against toilet-themed enemies using various units like Cameramen, Speakermen, TV Men, and more.

## Features

### Core Gameplay
- **Gacha/Summoning System**: Pull for units with different rarities (Basic to Exclusive)
- **Auto-Battle System**: Battles run automatically with real-time updates
- **Unit Loadout System**: Equip up to 10 units for battle with placement options
- **Unit Placement**: Position units in Front/Middle/Back for strategic advantages
- **Unit Upgrading**: Sacrifice duplicate units to level up your equipped units
- **Difficulty Levels**: Easy, Normal, Hard, Nightmare, and Endless modes
- **Unit Collection**: 35+ unique TTD-inspired units with abilities
- **Trading**: Trade units with other players using interactive buttons

### Interactive UI
- **Button-based Navigation**: All menus use Discord buttons instead of text commands
- **Case-insensitive Text Prefix**: Use `ttd`, `TTD`, `Ttd`, etc. before commands
- **Pagination**: Browse inventory with prev/next buttons
- **Trade Confirmations**: Accept/decline trades with buttons

### Economy
- Coins and Gems currency system
- Daily rewards (150-400 coins, 8-20 gems)
- Multiple crate types with different rates
- Currency exchange in shop

## Project Structure
```
├── main.py          # Main Discord bot with slash commands and text prefix
├── database.py      # SQLite database operations (including loadout system)
├── units.py         # Unit/enemy data, abilities, difficulties, crates
└── ttd_game.db      # SQLite database (created on first run)
```

## Commands

### Text Commands (ttd prefix - case insensitive)
- `ttd start` - Begin your journey
- `ttd menu` - Open main menu with buttons
- `ttd summon` - Open summon menu
- `ttd battle` - Start auto-battle
- `ttd inventory` - View your units
- `ttd loadout` - Manage your battle loadout
- `ttd daily` - Claim daily rewards
- `ttd shop` - Visit the shop
- `ttd leaderboard` - View rankings
- `ttd rates` - View summon rates
- `ttd help` - Get help

### Slash Commands
- `/start` - Begin your journey
- `/menu` - Open main menu
- `/profile` - View stats
- `/summon` - Open summon menu
- `/battle` - Start a battle
- `/inventory` - View units
- `/loadout` - Manage your battle loadout
- `/daily` - Claim daily rewards
- `/shop` - Visit the shop
- `/trade @user <unit_id>` - Trade with players
- `/leaderboard` - View rankings
- `/help` - Get help

## Loadout System
- Equip up to 10 units in your loadout
- Different difficulties allow different max units:
  - Easy: 5 units
  - Normal: 6 units
  - Hard: 7 units
  - Nightmare: 8 units
  - Endless: 10 units
- Set unit placement (Front/Middle/Back) for strategic advantages:
  - Front: +15% attack, takes more damage
  - Middle: Balanced position
  - Back: +15% defense, safer position
- Auto-equip feature selects your best units automatically
- Upgrade units by sacrificing duplicates

## Difficulty Levels
| Difficulty | HP Mult | DMG Mult | Reward Mult | Max Wave | Max Units |
|------------|---------|----------|-------------|----------|-----------|
| 🟢 Easy | 0.7x | 0.7x | 0.8x | 20 | 5 |
| 🟡 Normal | 1.0x | 1.0x | 1.0x | 40 | 6 |
| 🟠 Hard | 1.5x | 1.3x | 1.5x | 60 | 7 |
| 🔴 Nightmare | 2.0x | 1.7x | 2.0x | 80 | 8 |
| 💀 Endless | 1.2x | 1.2x | 1.3x | 999 | 10 |

## Crate Types
- **Standard** (100 coins): Basic to Legendary
- **Premium** (50 gems): Rare+ guaranteed
- **Mythic** (150 gems): Epic+ guaranteed
- **Titan** (200 gems): Legendary+ guaranteed

## Unit Rarities
⚪ Basic → 🟢 Uncommon → 🔵 Rare → 🟣 Epic → 🟡 Legendary → 🔮 Mythic → 🔴 Godly → 💠 Celestial → ⭐ Exclusive

## Unit Abilities
- 💥 AOE - Area damage
- ⚡ Stun - Disable enemies
- 🔥 Burn - Damage over time
- 💚 Heal - Restore HP
- ⬆️ Boost - Buff allies
- 🎯 Pierce - Hit multiple enemies
- 🐌 Slow - Reduce enemy speed

## Setup Requirements
- Discord Bot Token (DISCORD_BOT_TOKEN secret)

## Technologies
- discord.py 2.6+
- aiosqlite for async database
- SQLite for data storage

## Recent Updates (December 2025)

### Latest Changes (December 5, 2025)
- **Fixed Battle System**: Improved difficulty button interaction handling - battles now start reliably
- **Fixed Unit Display**: Replaced broken wiki image URLs with emoji-based unit icons for all 50+ units
- **Boss Rush Mode** (NEW): Fight 7 consecutive bosses for massive rewards (Level 10+ required)
  - G-Man Toilet, Titan Toilet, Upgraded Titan, Astro, Glitch, Omega, and Final Toilet
  - No retreating - test your loadout against increasingly difficult bosses
- **Weekly Challenges** (NEW): Complete timed challenges for bonus rewards
  - Battle Master: Win 20 battles
  - Toilet Slayer: Defeat 500 enemies
  - Wave Rider: Reach wave 50
  - Lucky Summoner: Summon 30 units
  - Boss Hunter: Defeat 10 bosses
- **Lucky Spin** (NEW): Spend 50 gems for a chance at coins, gems, XP, or free crates
- **Improved Error Handling**: Better fallback messaging when button interactions fail
- **New Commands**: `/bossrush`, `/challenges`, `/spin`

### Previous Changes
- **Fixed Battle System**: Proper deferred interaction responses for button interactions
- **Admin Commands**: Restricted to user ID 1155354373250109570
  - `/admin give_coins`, `/admin give_gems`, `/admin give_unit`
  - `/admin set_level`, `/admin reset_player`, `/admin give_all_units`
  - `/admin broadcast` - Send announcements to all servers
- **Safe Interaction Handling**: Helper functions for robust button response handling
- **Updated Help Command**: Shows all features and admin commands for admins

### Previous Updates
- **Shiny Units System**: 1% chance to get shiny versions of units with 25% stat boost and special visual marker
- **Map Selection System**: 6 different maps with unique modifiers:
  - Classic Map (base difficulty)
  - Apocalypse City (1.2x difficulty, 1.3x rewards, Level 5+)
  - Steampunk Factory (1.4x difficulty, 1.5x rewards, Level 10+)
  - Wastelands (1.6x difficulty, 1.8x rewards, Level 15+)
  - Space Station (1.8x difficulty, 2.0x rewards, Level 20+)
  - The Void (2.5x difficulty, 3.0x rewards, Level 30+)
- **Unit Fusion System**: Combine 3 units of the same rarity to create 1 unit of the next tier
- **Achievements System**: Unlock achievements for various milestones and earn rewards
- **Enhanced Visual UI**: Fancier embeds with ANSI colored ASCII art boxes
- **Progress Bars**: Visual progress indicators for XP, loadout, battle power, and win rate
- **Theme Colors**: Consistent color scheme across all menus (primary, success, warning, battle, summon, gold)
- **Number Formatting**: Large numbers formatted with K/M suffixes for readability
- **Rank System**: Player titles based on wins (Recruit, Fighter, Warrior, Veteran, Master, Legend)
- **Formation Display**: Shows front/middle/back unit distribution in loadout
- **Better Visual Hierarchy**: Decorative separators and structured information layout

## Previous Updates
- Added unit loadout/equipping system
- Added unit placement (Front/Middle/Back)
- Added unit upgrading with duplicate sacrifice
- Added auto-equip best units feature
- Battles now use equipped units only
- Different difficulties have different max unit slots
- Improved battle system with placement bonuses
- Added case-insensitive text prefix ("ttd")
- Button-based UI for all menus
- Auto-battle system with real-time updates
- 5 difficulty levels
- 4 crate types with different rates
- Unit abilities system
- 35+ units with DPS stats
