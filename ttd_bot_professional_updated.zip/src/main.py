from keep_alive import start_keepalive
import discord
from discord import app_commands
from discord.ext import commands, tasks
import asyncio
import random
from datetime import datetime, timedelta
import os
import re
from typing import Optional, Union
from dotenv import load_dotenv

from database import (
    init_db, get_player, create_player, update_player,
    add_unit_to_inventory, get_inventory, get_unit_by_id,
    remove_unit, transfer_unit, get_leaderboard,
    create_battle_session, get_active_battle, update_battle, end_battle,
    equip_unit, unequip_unit, unequip_unit_by_inventory_id, get_equipped_units,
    get_loadout_count, is_unit_equipped, update_unit_placement,
    upgrade_unit, get_duplicate_units, clear_loadout, auto_equip_best_units,
    MAX_LOADOUT_SLOTS, get_achievements, unlock_achievement, has_achievement,
    get_daily_streak, update_daily_streak, fuse_units
)
from units import (
    UNITS, ENEMIES, RARITY_COLORS, RARITY_EMOJIS, GACHA_RATES, ABILITY_EMOJIS,
    roll_gacha, roll_crate, get_enemies_for_wave, simulate_wave, calculate_battle_power,
    DIFFICULTIES, CRATES, MAPS, SHINY_CHANCE, SHINY_STAT_BOOST
)

load_dotenv()

ADMIN_USER_IDS = [1155354373250109570]

UNIT_DISPLAY_ICONS = {
    "cameraman": "📷",
    "large_cameraman": "📹",
    "camerawoman": "📸",
    "ninja_cameraman": "🥷",
    "medic_cameraman": "⚕️",
    "jetpack_cameraman": "🚀",
    "scientist_cameraman": "🔬",
    "engineer_cameraman": "🔧",
    "corrupted_cameraman": "👁️",
    "sniper_cameraman": "🎯",
    "titan_cameraman": "🦾",
    "upgraded_titan_cameraman": "⚡",
    "mech_cameraman": "🤖",
    "speakerman": "🔊",
    "large_speakerman": "📢",
    "dark_speakerman": "🖤",
    "sonic_speakerman": "🎵",
    "dj_speakerman": "🎧",
    "announcer_speakerman": "📣",
    "bass_speakerman": "🔉",
    "titan_speakerman": "🎵",
    "upgraded_titan_speakerman": "🎶",
    "wormhole_speakerman": "🌀",
    "tv_man": "📺",
    "tv_woman": "🖥️",
    "large_tv_man": "🎬",
    "plasma_tv_man": "⚡",
    "dj_tv_man": "🎛️",
    "titan_tv_man": "📡",
    "titan_cinemaman": "🎥",
    "upgraded_titan_cinemaman": "🎞️",
    "camera_helicopter": "🚁",
    "speaker_helicopter": "🛩️",
    "camera_attack_helicopter": "✈️",
    "stealth_bomber": "🛸",
    "clockman": "⏰",
    "chrono_clockman": "⌚",
    "titan_clockman": "🕐",
    "quantum_clockman": "⚛️",
    "drillman": "⛏️",
    "mega_drillman": "🔨",
    "titan_drillman": "🔩",
    "medic_speakerman": "💊",
    "shield_cameraman": "🛡️",
    "vampire_tv_man": "🧛",
    "berserker_cameraman": "😡",
    "poison_speakerman": "☠️",
    "astro_cameraman": "🌟",
    "glitch_cameraman": "👾",
    "cosmic_speakerman": "🌌",
    "titan_titan_man": "💎",
    "ultimate_cameraman": "👑",
    "omega_speakerman": "Ω",
}

intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix=commands.when_mentioned, intents=intents, help_command=None)

SUMMON_COST = 100
PREMIUM_SUMMON_COST = 10
MULTI_SUMMON_COUNT = 10

active_auto_battles = {}

PLACEMENT_EMOJIS = {
    "front": "🛡️",
    "middle": "⚔️", 
    "back": "🎯"
}

THEME_COLORS = {
    "primary": 0x5865F2,
    "success": 0x57F287,
    "warning": 0xFEE75C,
    "danger": 0xED4245,
    "premium": 0xF47FFF,
    "gold": 0xFFD700,
    "legendary": 0xFFAA00,
    "mythic": 0xE040FB,
    "godly": 0xFF5252,
    "celestial": 0x00E5FF,
    "exclusive": 0xFFFFFF,
    "battle": 0xFF6B35,
    "shop": 0x00D9FF,
    "summon": 0xFFD93D
}

ACHIEVEMENTS = {
    "first_win": {"name": "First Victory", "emoji": "🏆", "description": "Win your first battle", "reward_coins": 100, "reward_gems": 5},
    "10_wins": {"name": "Rising Champion", "emoji": "⭐", "description": "Win 10 battles", "reward_coins": 500, "reward_gems": 25},
    "50_wins": {"name": "Toilet Slayer", "emoji": "💀", "description": "Win 50 battles", "reward_coins": 2000, "reward_gems": 100},
    "100_wins": {"name": "Legendary Defender", "emoji": "👑", "description": "Win 100 battles", "reward_coins": 5000, "reward_gems": 250},
    "250_wins": {"name": "Toilet Terminator", "emoji": "🔱", "description": "Win 250 battles", "reward_coins": 10000, "reward_gems": 500},
    "500_wins": {"name": "God of War", "emoji": "⚔️", "description": "Win 500 battles", "reward_coins": 25000, "reward_gems": 1000},
    "first_legendary": {"name": "Lucky Pull", "emoji": "🎰", "description": "Get your first Legendary unit", "reward_coins": 200, "reward_gems": 20},
    "first_mythic": {"name": "Mythic Discovery", "emoji": "🔮", "description": "Get your first Mythic unit", "reward_coins": 500, "reward_gems": 50},
    "first_godly": {"name": "Divine Blessing", "emoji": "🔴", "description": "Get your first Godly unit", "reward_coins": 1000, "reward_gems": 100},
    "first_celestial": {"name": "Celestial Awakening", "emoji": "💠", "description": "Get your first Celestial unit", "reward_coins": 2500, "reward_gems": 200},
    "first_exclusive": {"name": "Ultimate Collector", "emoji": "👑", "description": "Get your first Exclusive unit", "reward_coins": 5000, "reward_gems": 500},
    "collector_10": {"name": "Collector", "emoji": "📦", "description": "Collect 10 units", "reward_coins": 150, "reward_gems": 10},
    "collector_50": {"name": "Hoarder", "emoji": "🏠", "description": "Collect 50 units", "reward_coins": 750, "reward_gems": 50},
    "collector_100": {"name": "Unit Master", "emoji": "🗃️", "description": "Collect 100 units", "reward_coins": 2000, "reward_gems": 150},
    "collector_200": {"name": "Army Commander", "emoji": "🎖️", "description": "Collect 200 units", "reward_coins": 5000, "reward_gems": 300},
    "wave_20": {"name": "Wave Survivor", "emoji": "🌊", "description": "Reach wave 20", "reward_coins": 200, "reward_gems": 15},
    "wave_50": {"name": "Wave Master", "emoji": "🌊", "description": "Reach wave 50", "reward_coins": 1000, "reward_gems": 75},
    "wave_100": {"name": "Wave Legend", "emoji": "🌊", "description": "Reach wave 100", "reward_coins": 3000, "reward_gems": 200},
    "wave_200": {"name": "Endless Champion", "emoji": "♾️", "description": "Reach wave 200", "reward_coins": 8000, "reward_gems": 500},
    "7_day_streak": {"name": "Dedicated Player", "emoji": "🔥", "description": "7 day login streak", "reward_coins": 500, "reward_gems": 50},
    "30_day_streak": {"name": "True Defender", "emoji": "💎", "description": "30 day login streak", "reward_coins": 2000, "reward_gems": 200},
    "60_day_streak": {"name": "TTD Veteran", "emoji": "🏅", "description": "60 day login streak", "reward_coins": 5000, "reward_gems": 400},
    "first_fusion": {"name": "Alchemist", "emoji": "⚗️", "description": "Fuse units for the first time", "reward_coins": 300, "reward_gems": 30},
    "fusion_master": {"name": "Fusion Master", "emoji": "🧪", "description": "Fuse 10 units", "reward_coins": 1500, "reward_gems": 100},
    "boss_slayer": {"name": "Boss Slayer", "emoji": "👹", "description": "Defeat 10 boss waves", "reward_coins": 500, "reward_gems": 50},
    "boss_hunter": {"name": "Boss Hunter", "emoji": "🎯", "description": "Defeat 50 boss waves", "reward_coins": 2000, "reward_gems": 150},
    "nightmare_clear": {"name": "Nightmare Conqueror", "emoji": "😈", "description": "Beat Nightmare difficulty", "reward_coins": 1500, "reward_gems": 150},
    "endless_survivor": {"name": "Endless Survivor", "emoji": "💀", "description": "Reach wave 50 in Endless mode", "reward_coins": 2000, "reward_gems": 200},
    "millionaire": {"name": "Millionaire", "emoji": "💰", "description": "Earn 1,000,000 total coins", "reward_coins": 10000, "reward_gems": 500},
    "level_10": {"name": "Rising Star", "emoji": "⭐", "description": "Reach level 10", "reward_coins": 300, "reward_gems": 25},
    "level_25": {"name": "Experienced", "emoji": "🌟", "description": "Reach level 25", "reward_coins": 1000, "reward_gems": 75},
    "level_50": {"name": "Elite Player", "emoji": "💫", "description": "Reach level 50", "reward_coins": 3000, "reward_gems": 200},
    "level_100": {"name": "Legendary Status", "emoji": "👑", "description": "Reach level 100", "reward_coins": 10000, "reward_gems": 500},
    "first_shiny": {"name": "Lucky Shine", "emoji": "✨", "description": "Get your first shiny unit", "reward_coins": 1000, "reward_gems": 100},
    "titan_collector": {"name": "Titan Collector", "emoji": "🦾", "description": "Collect 5 different Titan units", "reward_coins": 2500, "reward_gems": 200},
    "speed_runner": {"name": "Speed Runner", "emoji": "⚡", "description": "Complete 10 battles in one day", "reward_coins": 500, "reward_gems": 50},
    "full_loadout": {"name": "Full Power", "emoji": "💪", "description": "Equip 10 units at once", "reward_coins": 300, "reward_gems": 30},
}

def create_progress_bar(current: int, maximum: int, length: int = 10, filled: str = "▓", empty: str = "░") -> str:
    if maximum <= 0:
        return empty * length
    ratio = min(current / maximum, 1.0)
    filled_length = int(length * ratio)
    return filled * filled_length + empty * (length - filled_length)

def create_hp_bar(hp: int, max_hp: int = 100) -> str:
    if hp > 70:
        color_emoji = "🟩"
    elif hp > 40:
        color_emoji = "🟨"
    elif hp > 20:
        color_emoji = "🟧"
    else:
        color_emoji = "🟥"
    bar = create_progress_bar(hp, max_hp, 10)
    return f"{color_emoji} `{bar}` {hp}%"

def create_fancy_border(text: str, style: str = "simple") -> str:
    if style == "stars":
        return f"✧･ﾟ: *✧･ﾟ:* {text} *:･ﾟ✧*:･ﾟ✧"
    elif style == "sparkle":
        return f"✨ {text} ✨"
    elif style == "battle":
        return f"⚔️═══════════⚔️\n{text}\n⚔️═══════════⚔️"
    return text

def format_number(num: int) -> str:
    if num >= 1000000:
        return f"{num/1000000:.1f}M"
    elif num >= 1000:
        return f"{num/1000:.1f}K"
    return str(num)

def create_embed(title: str, description: str, color: int = 0x00BFFF):
    embed = discord.Embed(title=title, description=description, color=color)
    embed.set_footer(text="🚽 Toilet Tower Defense | Use buttons or 'ttd help' 🚽")
    return embed

def create_fancy_embed(title: str, description: str, color: int = 0x00BFFF, thumbnail_url: str = None, footer_icon: str = None):
    embed = discord.Embed(
        title=f"{'━' * 2} {title} {'━' * 2}",
        description=description,
        color=color
    )
    if thumbnail_url:
        embed.set_thumbnail(url=thumbnail_url)
    footer_text = "🚽 Toilet Tower Defense 🚽"
    embed.set_footer(text=footer_text)
    embed.timestamp = discord.utils.utcnow()
    return embed

def get_unit_emoji(unit_id):
    base = next((bu for bu in UNITS if bu['id'] == unit_id), None)
    return base['emoji'] if base else '❓'

def get_unit_ability(unit_id):
    base = next((bu for bu in UNITS if bu['id'] == unit_id), None)
    return base.get('ability') if base else None

def get_unit_dps(unit_id):
    base = next((bu for bu in UNITS if bu['id'] == unit_id), None)
    return base.get('dps', base.get('attack', 0)) if base else 0

def get_unit_display_icon(unit_id):
    return UNIT_DISPLAY_ICONS.get(unit_id, get_unit_emoji(unit_id))

def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_USER_IDS

async def safe_respond(interaction: discord.Interaction, embed: discord.Embed, view: discord.ui.View = None, ephemeral: bool = False):
    try:
        if interaction.response.is_done():
            await interaction.followup.send(embed=embed, view=view, ephemeral=ephemeral)
        else:
            await interaction.response.send_message(embed=embed, view=view, ephemeral=ephemeral)
    except Exception as e:
        print(f"Response error: {e}")
        try:
            await interaction.followup.send(embed=embed, view=view, ephemeral=ephemeral)
        except:
            pass

async def safe_edit_or_send(interaction: discord.Interaction, embed: discord.Embed, view: discord.ui.View = None):
    try:
        if interaction.response.is_done():
            await interaction.edit_original_response(embed=embed, view=view)
        else:
            try:
                await interaction.response.edit_message(embed=embed, view=view)
            except discord.errors.InteractionResponded:
                await interaction.edit_original_response(embed=embed, view=view)
            except Exception:
                await interaction.response.send_message(embed=embed, view=view)
    except Exception as e:
        print(f"Edit/send error: {e}")
        try:
            await interaction.followup.send(embed=embed, view=view)
        except:
            pass

class MainMenuView(discord.ui.View):
    def __init__(self, user_id: int):
        super().__init__(timeout=180)
        self.user_id = user_id
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("This menu is not for you!", ephemeral=True)
            return False
        return True
    
    @discord.ui.button(label="Profile", style=discord.ButtonStyle.primary, emoji="👤", row=0)
    async def profile_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_profile(interaction, interaction.user)
    
    @discord.ui.button(label="Summon", style=discord.ButtonStyle.success, emoji="🎰", row=0)
    async def summon_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_summon_menu(interaction)
    
    @discord.ui.button(label="Battle", style=discord.ButtonStyle.danger, emoji="⚔️", row=0)
    async def battle_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_battle_menu(interaction)
    
    @discord.ui.button(label="Inventory", style=discord.ButtonStyle.secondary, emoji="📦", row=1)
    async def inventory_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_inventory(interaction, 1)
    
    @discord.ui.button(label="Loadout", style=discord.ButtonStyle.primary, emoji="🎒", row=1)
    async def loadout_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_loadout(interaction)
    
    @discord.ui.button(label="Shop", style=discord.ButtonStyle.secondary, emoji="🏪", row=1)
    async def shop_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_shop(interaction)
    
    @discord.ui.button(label="Daily", style=discord.ButtonStyle.success, emoji="🎁", row=2)
    async def daily_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await claim_daily(interaction)
    
    @discord.ui.button(label="Achievements", style=discord.ButtonStyle.primary, emoji="🏆", row=2)
    async def achievements_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_achievements(interaction)
    
    @discord.ui.button(label="Fusion", style=discord.ButtonStyle.danger, emoji="⚗️", row=2)
    async def fusion_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_fusion_menu(interaction)
    
    @discord.ui.button(label="Boss Rush", style=discord.ButtonStyle.danger, emoji="💀", row=2)
    async def boss_rush_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_boss_rush(interaction)
    
    @discord.ui.button(label="Challenges", style=discord.ButtonStyle.primary, emoji="📅", row=3)
    async def challenges_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_weekly_challenges(interaction)
    
    @discord.ui.button(label="Lucky Spin", style=discord.ButtonStyle.success, emoji="🎰", row=3)
    async def spin_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_lucky_spin(interaction)
    
    @discord.ui.button(label="Help", style=discord.ButtonStyle.secondary, emoji="❓", row=3)
    async def help_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_help(interaction)
    
    @discord.ui.button(label="Leaderboard", style=discord.ButtonStyle.primary, emoji="📊", row=4)
    async def leaderboard_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_leaderboard(interaction)

class SummonMenuView(discord.ui.View):
    def __init__(self, user_id: int):
        super().__init__(timeout=120)
        self.user_id = user_id
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("This menu is not for you!", ephemeral=True)
            return False
        return True
    
    @discord.ui.button(label="Standard (100 coins)", style=discord.ButtonStyle.primary, emoji="📦", row=0)
    async def standard_summon(self, interaction: discord.Interaction, button: discord.ui.Button):
        await do_summon(interaction, "standard", 1)
    
    @discord.ui.button(label="10x Standard (900 coins)", style=discord.ButtonStyle.primary, emoji="🎁", row=0)
    async def multi_summon(self, interaction: discord.Interaction, button: discord.ui.Button):
        await do_summon(interaction, "standard", 10)
    
    @discord.ui.button(label="Premium (50 gems)", style=discord.ButtonStyle.success, emoji="💎", row=1)
    async def premium_summon(self, interaction: discord.Interaction, button: discord.ui.Button):
        await do_summon(interaction, "premium", 1)
    
    @discord.ui.button(label="Mythic Crate (150 gems)", style=discord.ButtonStyle.danger, emoji="🔮", row=1)
    async def mythic_summon(self, interaction: discord.Interaction, button: discord.ui.Button):
        await do_summon(interaction, "mythic", 1)
    
    @discord.ui.button(label="View Rates", style=discord.ButtonStyle.secondary, emoji="📊", row=2)
    async def view_rates(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_rates(interaction)
    
    @discord.ui.button(label="Back", style=discord.ButtonStyle.secondary, emoji="◀️", row=2)
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_main_menu(interaction)

class LoadoutView(discord.ui.View):
    def __init__(self, user_id: int):
        super().__init__(timeout=120)
        self.user_id = user_id
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("This is not your loadout!", ephemeral=True)
            return False
        return True
    
    @discord.ui.button(label="Equip Units", style=discord.ButtonStyle.success, emoji="➕", row=0)
    async def equip_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_equip_menu(interaction, 1)
    
    @discord.ui.button(label="Unequip All", style=discord.ButtonStyle.danger, emoji="🗑️", row=0)
    async def unequip_all_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await clear_loadout(interaction.user.id)
        embed = create_embed("Loadout Cleared", "All units have been unequipped.", 0xFF6600)
        await interaction.response.edit_message(embed=embed, view=LoadoutView(interaction.user.id))
    
    @discord.ui.button(label="Auto-Equip Best", style=discord.ButtonStyle.primary, emoji="✨", row=0)
    async def auto_equip_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        count = await auto_equip_best_units(interaction.user.id, 6)
        embed = create_embed("Auto-Equip Complete!", f"Equipped your **{count} best units** automatically!", 0x00FF00)
        await interaction.response.edit_message(embed=embed, view=LoadoutView(interaction.user.id))
    
    @discord.ui.button(label="Manage Placement", style=discord.ButtonStyle.secondary, emoji="📍", row=1)
    async def placement_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_placement_menu(interaction)
    
    @discord.ui.button(label="Upgrade Units", style=discord.ButtonStyle.success, emoji="⬆️", row=1)
    async def upgrade_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_upgrade_menu(interaction, 1)
    
    @discord.ui.button(label="Refresh", style=discord.ButtonStyle.secondary, emoji="🔄", row=1)
    async def refresh_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_loadout(interaction)
    
    @discord.ui.button(label="Back to Menu", style=discord.ButtonStyle.secondary, emoji="🏠", row=2)
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_main_menu(interaction)

class EquipMenuView(discord.ui.View):
    def __init__(self, user_id: int, units: list, current_page: int, total_pages: int):
        super().__init__(timeout=120)
        self.user_id = user_id
        self.current_page = current_page
        self.total_pages = total_pages
        
        for i, unit in enumerate(units[:5]):
            button = EquipUnitButton(unit, i)
            self.add_item(button)
        
        self._setup_pagination_buttons()
    
    def _setup_pagination_buttons(self):
        for child in self.children:
            if hasattr(child, 'label'):
                if "Prev" in str(child.label) and self.current_page <= 1:
                    child.disabled = True
                if "Next" in str(child.label) and self.current_page >= self.total_pages:
                    child.disabled = True
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("This is not your menu!", ephemeral=True)
            return False
        return True
    
    @discord.ui.button(label="◀️ Prev", style=discord.ButtonStyle.primary, row=2)
    async def prev_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_equip_menu(interaction, self.current_page - 1)
    
    @discord.ui.button(label="Next ▶️", style=discord.ButtonStyle.primary, row=2)
    async def next_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_equip_menu(interaction, self.current_page + 1)
    
    @discord.ui.button(label="Back to Loadout", style=discord.ButtonStyle.secondary, emoji="🎒", row=2)
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_loadout(interaction)

class EquipUnitButton(discord.ui.Button):
    def __init__(self, unit, index: int):
        self.unit = unit
        emoji = get_unit_emoji(unit['unit_id'])
        label = f"{unit['unit_name'][:15]}"
        super().__init__(style=discord.ButtonStyle.success, label=label, emoji=emoji, row=index // 3)
    
    async def callback(self, interaction: discord.Interaction):
        equipped_count = await get_loadout_count(interaction.user.id)
        next_slot = equipped_count
        
        if next_slot >= 10:
            await interaction.response.send_message("Loadout is full! Max 10 units.", ephemeral=True)
            return
        
        success, message = await equip_unit(interaction.user.id, self.unit['id'], next_slot)
        
        if success:
            embed = create_embed(
                "Unit Equipped! ✅",
                f"{get_unit_emoji(self.unit['unit_id'])} **{self.unit['unit_name']}** equipped to slot {next_slot + 1}!",
                0x00FF00
            )
        else:
            embed = create_embed("Error", message, 0xFF0000)
        
        await interaction.response.edit_message(embed=embed, view=LoadoutView(interaction.user.id))

class PlacementMenuView(discord.ui.View):
    def __init__(self, user_id: int, equipped_units: list):
        super().__init__(timeout=120)
        self.user_id = user_id
        self.equipped_units = equipped_units
        
        for unit in equipped_units[:5]:
            button = PlacementButton(unit)
            self.add_item(button)
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("This is not your menu!", ephemeral=True)
            return False
        return True
    
    @discord.ui.button(label="Back to Loadout", style=discord.ButtonStyle.secondary, emoji="🎒", row=2)
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_loadout(interaction)

class PlacementButton(discord.ui.Button):
    def __init__(self, unit):
        self.unit = unit
        current_placement = unit['placement']
        emoji = PLACEMENT_EMOJIS.get(current_placement, "⚔️")
        label = f"Slot {unit['slot']+1}: {unit['unit_name'][:12]}"
        super().__init__(style=discord.ButtonStyle.primary, label=label, emoji=emoji, row=0)
    
    async def callback(self, interaction: discord.Interaction):
        placements = ["front", "middle", "back"]
        current = self.unit['placement']
        current_idx = placements.index(current) if current in placements else 0
        new_placement = placements[(current_idx + 1) % 3]
        
        await update_unit_placement(interaction.user.id, self.unit['slot'], new_placement)
        await show_placement_menu(interaction)

class UpgradeMenuView(discord.ui.View):
    def __init__(self, user_id: int, upgradeable_units: list, current_page: int, total_pages: int):
        super().__init__(timeout=120)
        self.user_id = user_id
        self.current_page = current_page
        self.total_pages = total_pages
        
        for i, (unit, dupes) in enumerate(upgradeable_units[:5]):
            button = UpgradeUnitButton(unit, dupes, i)
            self.add_item(button)
        
        self._setup_pagination_buttons()
    
    def _setup_pagination_buttons(self):
        for child in self.children:
            if hasattr(child, 'label'):
                if "Prev" in str(child.label) and self.current_page <= 1:
                    child.disabled = True
                if "Next" in str(child.label) and self.current_page >= self.total_pages:
                    child.disabled = True
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("This is not your menu!", ephemeral=True)
            return False
        return True
    
    @discord.ui.button(label="◀️ Prev", style=discord.ButtonStyle.primary, row=2)
    async def prev_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_upgrade_menu(interaction, self.current_page - 1)
    
    @discord.ui.button(label="Next ▶️", style=discord.ButtonStyle.primary, row=2)
    async def next_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_upgrade_menu(interaction, self.current_page + 1)
    
    @discord.ui.button(label="Back to Loadout", style=discord.ButtonStyle.secondary, emoji="🎒", row=2)
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_loadout(interaction)

class UpgradeUnitButton(discord.ui.Button):
    def __init__(self, unit, dupes: int, index: int):
        self.unit = unit
        self.dupes = dupes
        emoji = get_unit_emoji(unit['unit_id'])
        label = f"{unit['unit_name'][:12]} (x{dupes})"
        super().__init__(style=discord.ButtonStyle.success, label=label, emoji=emoji, row=index // 3)
    
    async def callback(self, interaction: discord.Interaction):
        duplicates = await get_duplicate_units(interaction.user.id, self.unit['unit_id'])
        
        if not duplicates:
            await interaction.response.send_message("No duplicate units to sacrifice!", ephemeral=True)
            return
        
        dupe_to_remove = duplicates[0]
        await remove_unit(dupe_to_remove['id'], interaction.user.id)
        
        attack_boost = max(1, self.unit['attack'] // 10)
        defense_boost = max(1, self.unit['defense'] // 10)
        await upgrade_unit(interaction.user.id, self.unit['id'], attack_boost, defense_boost)
        
        embed = create_embed(
            "Unit Upgraded! ⬆️",
            f"{get_unit_emoji(self.unit['unit_id'])} **{self.unit['unit_name']}** is now Level {self.unit['level'] + 1}!\n\n"
            f"⚔️ Attack +{attack_boost}\n"
            f"🛡️ Defense +{defense_boost}\n\n"
            f"*Sacrificed 1 duplicate unit*",
            0x00FF00
        )
        await interaction.response.edit_message(embed=embed, view=LoadoutView(interaction.user.id))

class BattleMenuView(discord.ui.View):
    def __init__(self, user_id: int):
        super().__init__(timeout=120)
        self.user_id = user_id
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("This menu is not for you!", ephemeral=True)
            return False
        return True
    
    @discord.ui.button(label="Easy", style=discord.ButtonStyle.success, emoji="🟢", row=0)
    async def easy_battle(self, interaction: discord.Interaction, button: discord.ui.Button):
        await start_auto_battle(interaction, "easy")
    
    @discord.ui.button(label="Normal", style=discord.ButtonStyle.primary, emoji="🟡", row=0)
    async def normal_battle(self, interaction: discord.Interaction, button: discord.ui.Button):
        await start_auto_battle(interaction, "normal")
    
    @discord.ui.button(label="Hard", style=discord.ButtonStyle.secondary, emoji="🟠", row=0)
    async def hard_battle(self, interaction: discord.Interaction, button: discord.ui.Button):
        await start_auto_battle(interaction, "hard")
    
    @discord.ui.button(label="Nightmare", style=discord.ButtonStyle.danger, emoji="🔴", row=1)
    async def nightmare_battle(self, interaction: discord.Interaction, button: discord.ui.Button):
        await start_auto_battle(interaction, "nightmare")
    
    @discord.ui.button(label="Endless", style=discord.ButtonStyle.danger, emoji="💀", row=1)
    async def endless_battle(self, interaction: discord.Interaction, button: discord.ui.Button):
        await start_auto_battle(interaction, "endless")
    
    @discord.ui.button(label="Manage Loadout", style=discord.ButtonStyle.primary, emoji="🎒", row=2)
    async def loadout_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_loadout(interaction)
    
    @discord.ui.button(label="Back", style=discord.ButtonStyle.secondary, emoji="◀️", row=2)
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_main_menu(interaction)

class AutoBattleView(discord.ui.View):
    def __init__(self, user_id: int):
        super().__init__(timeout=None)
        self.user_id = user_id
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("This is not your battle!", ephemeral=True)
            return False
        return True
    
    @discord.ui.button(label="Retreat & Collect", style=discord.ButtonStyle.danger, emoji="🏃", custom_id="retreat")
    async def retreat_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await retreat_battle(interaction)

class InventoryView(discord.ui.View):
    def __init__(self, user_id: int, current_page: int, total_pages: int):
        super().__init__(timeout=120)
        self.user_id = user_id
        self.current_page = current_page
        self.total_pages = total_pages
        
        self._setup_pagination_buttons()
    
    def _setup_pagination_buttons(self):
        for child in self.children:
            if hasattr(child, 'label'):
                if "Prev" in str(child.label) and self.current_page <= 1:
                    child.disabled = True
                if "Next" in str(child.label) and self.current_page >= self.total_pages:
                    child.disabled = True
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("This is not your inventory!", ephemeral=True)
            return False
        return True
    
    @discord.ui.button(label="◀️ Prev", style=discord.ButtonStyle.primary)
    async def prev_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_inventory(interaction, self.current_page - 1)
    
    @discord.ui.button(label="Next ▶️", style=discord.ButtonStyle.primary)
    async def next_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_inventory(interaction, self.current_page + 1)
    
    @discord.ui.button(label="Manage Loadout", style=discord.ButtonStyle.success, emoji="🎒")
    async def loadout_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_loadout(interaction)
    
    @discord.ui.button(label="Back to Menu", style=discord.ButtonStyle.secondary, emoji="🏠")
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_main_menu(interaction)

class ShopView(discord.ui.View):
    def __init__(self, user_id: int):
        super().__init__(timeout=120)
        self.user_id = user_id
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("This is not your shop!", ephemeral=True)
            return False
        return True
    
    @discord.ui.button(label="Buy 1000 Coins (50 gems)", style=discord.ButtonStyle.success, emoji="💰")
    async def buy_coins(self, interaction: discord.Interaction, button: discord.ui.Button):
        player = await get_player(interaction.user.id)
        if not player or player['gems'] < 50:
            await interaction.response.send_message("Not enough gems!", ephemeral=True)
            return
        
        await update_player(interaction.user.id, gems=player['gems'] - 50, coins=player['coins'] + 1000)
        embed = create_embed("Purchase Complete! 🛒", f"You bought **1,000 Coins** for **50 Gems**!", 0x00FF00)
        await interaction.response.edit_message(embed=embed, view=ShopView(interaction.user.id))
    
    @discord.ui.button(label="Buy 100 Gems (1000 coins)", style=discord.ButtonStyle.primary, emoji="💎")
    async def buy_gems(self, interaction: discord.Interaction, button: discord.ui.Button):
        player = await get_player(interaction.user.id)
        if not player or player['coins'] < 1000:
            await interaction.response.send_message("Not enough coins!", ephemeral=True)
            return
        
        await update_player(interaction.user.id, coins=player['coins'] - 1000, gems=player['gems'] + 100)
        embed = create_embed("Purchase Complete! 🛒", f"You bought **100 Gems** for **1,000 Coins**!", 0x00FF00)
        await interaction.response.edit_message(embed=embed, view=ShopView(interaction.user.id))
    
    @discord.ui.button(label="Go to Summon", style=discord.ButtonStyle.secondary, emoji="🎰")
    async def go_summon(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_summon_menu(interaction)
    
    @discord.ui.button(label="Back to Menu", style=discord.ButtonStyle.secondary, emoji="🏠")
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_main_menu(interaction)

class TradeConfirmView(discord.ui.View):
    def __init__(self, sender_id: int, receiver_id: int, unit_id: int, unit_name: str):
        super().__init__(timeout=60)
        self.sender_id = sender_id
        self.receiver_id = receiver_id
        self.unit_id = unit_id
        self.unit_name = unit_name
    
    @discord.ui.button(label="Accept", style=discord.ButtonStyle.success, emoji="✅")
    async def accept(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.receiver_id:
            await interaction.response.send_message("This trade is not for you!", ephemeral=True)
            return
        
        await transfer_unit(self.unit_id, self.sender_id, self.receiver_id)
        embed = create_embed("Trade Complete! 🤝", f"**{self.unit_name}** has been traded!", 0x00FF00)
        await interaction.response.edit_message(embed=embed, view=None)
        self.stop()
    
    @discord.ui.button(label="Decline", style=discord.ButtonStyle.danger, emoji="❌")
    async def decline(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.receiver_id:
            await interaction.response.send_message("This trade is not for you!", ephemeral=True)
            return
        
        embed = create_embed("Trade Declined", "The trade was declined.", 0xFF0000)
        await interaction.response.edit_message(embed=embed, view=None)
        self.stop()

class FusionMenuView(discord.ui.View):
    def __init__(self, user_id: int):
        super().__init__(timeout=120)
        self.user_id = user_id
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("This is not your fusion menu!", ephemeral=True)
            return False
        return True
    
    @discord.ui.button(label="Fuse Basic → Uncommon", style=discord.ButtonStyle.secondary, emoji="⚪", row=0)
    async def fuse_basic(self, interaction: discord.Interaction, button: discord.ui.Button):
        await do_fusion(interaction, "Basic")
    
    @discord.ui.button(label="Fuse Uncommon → Rare", style=discord.ButtonStyle.success, emoji="🟢", row=0)
    async def fuse_uncommon(self, interaction: discord.Interaction, button: discord.ui.Button):
        await do_fusion(interaction, "Uncommon")
    
    @discord.ui.button(label="Fuse Rare → Epic", style=discord.ButtonStyle.primary, emoji="🔵", row=1)
    async def fuse_rare(self, interaction: discord.Interaction, button: discord.ui.Button):
        await do_fusion(interaction, "Rare")
    
    @discord.ui.button(label="Fuse Epic → Legendary", style=discord.ButtonStyle.secondary, emoji="🟣", row=1)
    async def fuse_epic(self, interaction: discord.Interaction, button: discord.ui.Button):
        await do_fusion(interaction, "Epic")
    
    @discord.ui.button(label="Fuse Legendary → Mythic", style=discord.ButtonStyle.danger, emoji="🟡", row=2)
    async def fuse_legendary(self, interaction: discord.Interaction, button: discord.ui.Button):
        await do_fusion(interaction, "Legendary")
    
    @discord.ui.button(label="Fuse Mythic → Godly", style=discord.ButtonStyle.danger, emoji="🔮", row=2)
    async def fuse_mythic(self, interaction: discord.Interaction, button: discord.ui.Button):
        await do_fusion(interaction, "Mythic")
    
    @discord.ui.button(label="Back to Menu", style=discord.ButtonStyle.secondary, emoji="🏠", row=3)
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_main_menu(interaction)

class MapSelectView(discord.ui.View):
    def __init__(self, user_id: int, difficulty: str):
        super().__init__(timeout=120)
        self.user_id = user_id
        self.difficulty = difficulty
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("This is not your menu!", ephemeral=True)
            return False
        return True
    
    @discord.ui.button(label="Classic Map", style=discord.ButtonStyle.success, emoji="🏠", row=0)
    async def classic_map(self, interaction: discord.Interaction, button: discord.ui.Button):
        await start_auto_battle_with_map(interaction, self.difficulty, "classic")
    
    @discord.ui.button(label="Apocalypse City", style=discord.ButtonStyle.primary, emoji="🏙️", row=0)
    async def city_map(self, interaction: discord.Interaction, button: discord.ui.Button):
        await start_auto_battle_with_map(interaction, self.difficulty, "city")
    
    @discord.ui.button(label="Steampunk Factory", style=discord.ButtonStyle.secondary, emoji="⚙️", row=1)
    async def steampunk_map(self, interaction: discord.Interaction, button: discord.ui.Button):
        await start_auto_battle_with_map(interaction, self.difficulty, "steampunk")
    
    @discord.ui.button(label="Wastelands", style=discord.ButtonStyle.danger, emoji="☢️", row=1)
    async def wastelands_map(self, interaction: discord.Interaction, button: discord.ui.Button):
        await start_auto_battle_with_map(interaction, self.difficulty, "wastelands")
    
    @discord.ui.button(label="Back", style=discord.ButtonStyle.secondary, emoji="◀️", row=2)
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_battle_menu(interaction)

async def do_fusion(interaction: discord.Interaction, rarity: str):
    inventory = await get_inventory(interaction.user.id)
    
    fuseable_units = []
    for unit in inventory:
        equipped = await is_unit_equipped(interaction.user.id, unit['id'])
        if equipped is None and unit['rarity'] == rarity:
            fuseable_units.append(unit)
    
    if len(fuseable_units) < 3:
        await interaction.response.send_message(
            f"You need at least 3 unequipped {rarity} units to fuse!",
            ephemeral=True
        )
        return
    
    units_to_fuse = [u['id'] for u in fuseable_units[:3]]
    result = await fuse_units(interaction.user.id, units_to_fuse)
    
    if result['success']:
        new_unit = result['new_unit']
        embed = create_embed(
            "⚗️ Fusion Successful!",
            f"**Combined 3 {rarity} units!**\n\n"
            f"**New Unit Created:**\n"
            f"{RARITY_EMOJIS.get(new_unit['rarity'], '⚪')} **{new_unit['unit_name']}** ({new_unit['rarity']})\n"
            f"⚔️ Attack: {new_unit['attack']}\n"
            f"🛡️ Defense: {new_unit['defense']}\n"
            f"📏 Range: {new_unit['range']}",
            RARITY_COLORS.get(new_unit['rarity'], 0xE040FB)
        )
        
        if not await has_achievement(interaction.user.id, "first_fusion"):
            await unlock_achievement(interaction.user.id, "first_fusion")
            embed.add_field(
                name="🏆 Achievement Unlocked!",
                value="**Alchemist** - Fuse units for the first time!",
                inline=False
            )
    else:
        embed = create_embed("❌ Fusion Failed", result['error'], 0xFF0000)
    
    try:
        await interaction.response.edit_message(embed=embed, view=FusionMenuView(interaction.user.id))
    except:
        await interaction.response.send_message(embed=embed, view=FusionMenuView(interaction.user.id))

async def show_main_menu(interaction: discord.Interaction):
    player = await get_player(interaction.user.id)
    if not player:
        await interaction.response.send_message("Use `/start` or `ttd start` first!", ephemeral=True)
        return
    
    equipped_count = await get_loadout_count(interaction.user.id)
    
    xp_for_next = player['level'] * 100
    xp_bar = create_progress_bar(player['experience'], xp_for_next, 12, "█", "░")
    loadout_bar = create_progress_bar(equipped_count, 10, 10, "◆", "◇")
    
    title = "✧･ﾟ: *✧ TOILET TOWER DEFENSE ✧* :･ﾟ✧"
    
    description = (
        f"```ansi\n"
        f"\u001b[1;36m╔══════════════════════════════════╗\u001b[0m\n"
        f"\u001b[1;33m   Welcome back, {interaction.user.display_name[:15]}!\u001b[0m\n"
        f"\u001b[1;36m╚══════════════════════════════════╝\u001b[0m\n"
        f"```\n"
        f"**━━━━━ 💫 Your Stats 💫 ━━━━━**\n\n"
        f"💰 **Coins:** `{format_number(player['coins'])}` | 💎 **Gems:** `{player['gems']}`\n"
        f"⭐ **Level {player['level']}** `[{xp_bar}]` {player['experience']}/{xp_for_next} XP\n\n"
        f"🏆 **Wins:** {player['wins']} | 💀 **Losses:** {player['losses']}\n"
        f"🌊 **Highest Wave:** {player['highest_wave']}\n\n"
        f"**━━━━━ 🎒 Loadout ━━━━━**\n"
        f"`[{loadout_bar}]` {equipped_count}/10 units\n\n"
        f"*Select an option below to continue your adventure!*"
    )
    
    embed = discord.Embed(
        title=title,
        description=description,
        color=THEME_COLORS["primary"]
    )
    embed.set_thumbnail(url=interaction.user.display_avatar.url)
    embed.set_footer(text="🚽 Toilet Tower Defense 🚽", icon_url=interaction.user.display_avatar.url)
    embed.timestamp = discord.utils.utcnow()
    
    try:
        await interaction.response.edit_message(embed=embed, view=MainMenuView(interaction.user.id))
    except:
        await interaction.response.send_message(embed=embed, view=MainMenuView(interaction.user.id))

async def show_profile(interaction: discord.Interaction, target: Union[discord.User, discord.Member]):
    player = await get_player(target.id)
    if not player:
        await interaction.response.send_message(f"{'This player' if target != interaction.user else 'You'} haven't started yet!", ephemeral=True)
        return
    
    inventory = await get_inventory(target.id)
    unit_count = len(inventory)
    equipped_units = await get_equipped_units(target.id)
    
    rarity_counts = {}
    for unit in inventory:
        rarity = unit['rarity']
        rarity_counts[rarity] = rarity_counts.get(rarity, 0) + 1
    
    rarity_order = ["Basic", "Uncommon", "Rare", "Epic", "Legendary", "Mythic", "Godly", "Celestial", "Exclusive"]
    rarity_display = ""
    for r in rarity_order:
        if r in rarity_counts:
            rarity_display += f"{RARITY_EMOJIS.get(r, '⚪')} **{r}:** {rarity_counts[r]}\n"
    rarity_display = rarity_display or "No units yet!"
    
    win_rate = (player['wins'] / (player['wins'] + player['losses']) * 100) if (player['wins'] + player['losses']) > 0 else 0
    loadout_power = calculate_battle_power([dict(u) for u in equipped_units]) if equipped_units else 0
    
    xp_for_next = player['level'] * 100
    xp_bar = create_progress_bar(player['experience'], xp_for_next, 15, "▓", "░")
    win_rate_bar = create_progress_bar(int(win_rate), 100, 10, "█", "░")
    
    rank_title = "Recruit"
    if player['wins'] >= 100:
        rank_title = "👑 Legend"
    elif player['wins'] >= 50:
        rank_title = "🌟 Master"
    elif player['wins'] >= 25:
        rank_title = "⚔️ Veteran"
    elif player['wins'] >= 10:
        rank_title = "🛡️ Warrior"
    elif player['wins'] >= 5:
        rank_title = "🗡️ Fighter"
    
    description = (
        f"```ansi\n"
        f"\u001b[1;35m╔═══════════════════════════════════════╗\u001b[0m\n"
        f"\u001b[1;33m   ★ {target.display_name[:20]} ★\u001b[0m\n"
        f"\u001b[1;32m         {rank_title}\u001b[0m\n"
        f"\u001b[1;35m╚═══════════════════════════════════════╝\u001b[0m\n"
        f"```\n"
        f"**━━━ ⭐ Level {player['level']} ━━━**\n"
        f"`[{xp_bar}]`\n"
        f"XP: {player['experience']}/{xp_for_next}\n\n"
        f"**━━━ 💰 Currency ━━━**\n"
        f"💰 Coins: `{format_number(player['coins'])}` | 💎 Gems: `{format_number(player['gems'])}`\n\n"
        f"**━━━ ⚔️ Battle Stats ━━━**\n"
        f"🏆 Wins: **{player['wins']}** | 💀 Losses: **{player['losses']}**\n"
        f"📊 Win Rate: `[{win_rate_bar}]` {win_rate:.1f}%\n"
        f"🌊 Highest Wave: **{player['highest_wave']}**\n"
        f"💪 Battle Power: **{format_number(loadout_power)}**\n\n"
        f"**━━━ 📦 Collection ({unit_count} units) ━━━**\n"
        f"{rarity_display}"
    )
    
    embed = discord.Embed(
        title="✧ Player Profile ✧",
        description=description,
        color=THEME_COLORS["gold"]
    )
    embed.set_thumbnail(url=target.display_avatar.url)
    embed.set_footer(text="🚽 Toilet Tower Defense 🚽")
    embed.timestamp = discord.utils.utcnow()
    
    try:
        await interaction.response.edit_message(embed=embed, view=MainMenuView(interaction.user.id))
    except:
        await interaction.response.send_message(embed=embed, view=MainMenuView(interaction.user.id))

async def show_loadout(interaction: discord.Interaction):
    player = await get_player(interaction.user.id)
    if not player:
        await interaction.response.send_message("Use `/start` first!", ephemeral=True)
        return
    
    equipped = await get_equipped_units(interaction.user.id)
    loadout_bar = create_progress_bar(len(equipped), 10, 10, "◆", "◇")
    
    if not equipped:
        description = (
            f"```ansi\n"
            f"\u001b[1;31m╔═══════════════════════════════════╗\u001b[0m\n"
            f"\u001b[1;33m     ⚠️ NO UNITS EQUIPPED! ⚠️      \u001b[0m\n"
            f"\u001b[1;31m╚═══════════════════════════════════╝\u001b[0m\n"
            f"```\n"
            f"**Loadout Status:** `[{loadout_bar}]` 0/10\n\n"
            f"Equip units to use them in battle!\n"
            f"You can equip up to **10 units** in your loadout.\n\n"
            f"💡 *Tip: Use 'Auto-Equip Best' to quickly set up your strongest team!*"
        )
        embed = discord.Embed(
            title="✧ Your Battle Loadout ✧",
            description=description,
            color=THEME_COLORS["warning"]
        )
    else:
        loadout_display = ""
        for unit in equipped:
            placement_emoji = PLACEMENT_EMOJIS.get(unit['placement'], "⚔️")
            ability = get_unit_ability(unit['unit_id'])
            ability_text = f" {ABILITY_EMOJIS.get(ability, '')}" if ability else ""
            rarity_color = RARITY_EMOJIS.get(unit['rarity'], '⚪')
            loadout_display += (
                f"`{unit['slot']+1}` {placement_emoji} {rarity_color} "
                f"{get_unit_emoji(unit['unit_id'])} **{unit['unit_name']}** Lv.{unit['level']}{ability_text}\n"
                f"    └ ⚔️`{unit['attack']}` 🛡️`{unit['defense']}` 📏`{unit['range']}`\n"
            )
        
        total_power = calculate_battle_power([dict(u) for u in equipped])
        power_bar = create_progress_bar(min(total_power, 5000), 5000, 12, "▓", "░")
        
        front_count = sum(1 for u in equipped if u['placement'] == 'front')
        middle_count = sum(1 for u in equipped if u['placement'] == 'middle')
        back_count = sum(1 for u in equipped if u['placement'] == 'back')
        
        description = (
            f"```ansi\n"
            f"\u001b[1;32m╔═══════════════════════════════════╗\u001b[0m\n"
            f"\u001b[1;33m      ⚔️ BATTLE READY! ⚔️          \u001b[0m\n"
            f"\u001b[1;32m╚═══════════════════════════════════╝\u001b[0m\n"
            f"```\n"
            f"**━━━ 📊 Loadout Stats ━━━**\n"
            f"📦 Units: `[{loadout_bar}]` {len(equipped)}/10\n"
            f"💪 Power: `[{power_bar}]` {format_number(total_power)}\n\n"
            f"**━━━ 📍 Formation ━━━**\n"
            f"🛡️ Front: {front_count} | ⚔️ Mid: {middle_count} | 🎯 Back: {back_count}\n\n"
            f"**━━━ 🎖️ Equipped Units ━━━**\n{loadout_display}\n"
            f"*🛡️Front=+15% ATK | 🎯Back=+15% DEF*"
        )
        embed = discord.Embed(
            title="✧ Your Battle Loadout ✧",
            description=description,
            color=THEME_COLORS["success"]
        )
    
    embed.set_footer(text="🚽 Toilet Tower Defense 🚽")
    embed.timestamp = discord.utils.utcnow()
    
    try:
        await interaction.response.edit_message(embed=embed, view=LoadoutView(interaction.user.id))
    except:
        await interaction.response.send_message(embed=embed, view=LoadoutView(interaction.user.id))

async def show_equip_menu(interaction: discord.Interaction, page: int):
    inventory = await get_inventory(interaction.user.id)
    equipped_ids = [u['id'] for u in await get_equipped_units(interaction.user.id)]
    
    available_units = [u for u in inventory if u['id'] not in equipped_ids]
    
    if not available_units:
        embed = create_embed(
            "No Units Available",
            "All your units are already equipped or you don't have any units!\n\n"
            "Use `/summon` to get more units.",
            0xFF6600
        )
        try:
            await interaction.response.edit_message(embed=embed, view=LoadoutView(interaction.user.id))
        except:
            await interaction.response.send_message(embed=embed, view=LoadoutView(interaction.user.id))
        return
    
    per_page = 5
    total_pages = (len(available_units) + per_page - 1) // per_page
    page = max(1, min(page, total_pages))
    
    start_idx = (page - 1) * per_page
    page_units = available_units[start_idx:start_idx + per_page]
    
    units_display = ""
    for unit in page_units:
        ability = get_unit_ability(unit['unit_id'])
        ability_text = f" {ABILITY_EMOJIS.get(ability, '')}" if ability else ""
        units_display += (
            f"{RARITY_EMOJIS.get(unit['rarity'], '⚪')} "
            f"{get_unit_emoji(unit['unit_id'])} **{unit['unit_name']}** "
            f"(Lv.{unit['level']}){ability_text}\n"
            f"   ⚔️{unit['attack']} 🛡️{unit['defense']} 📏{unit['range']}\n"
        )
    
    embed = create_embed(
        f"➕ Equip Units (Page {page}/{total_pages})",
        f"**Available Units:**\n\n{units_display}\n"
        f"*Click a button to equip that unit*",
        0x00FF00
    )
    
    try:
        await interaction.response.edit_message(embed=embed, view=EquipMenuView(interaction.user.id, page_units, page, total_pages))
    except:
        await interaction.response.send_message(embed=embed, view=EquipMenuView(interaction.user.id, page_units, page, total_pages))

async def show_placement_menu(interaction: discord.Interaction):
    equipped = await get_equipped_units(interaction.user.id)
    
    if not equipped:
        embed = create_embed(
            "No Units Equipped",
            "Equip some units first before managing placement!",
            0xFF6600
        )
        try:
            await interaction.response.edit_message(embed=embed, view=LoadoutView(interaction.user.id))
        except:
            await interaction.response.send_message(embed=embed, view=LoadoutView(interaction.user.id))
        return
    
    placement_display = ""
    for unit in equipped:
        placement_emoji = PLACEMENT_EMOJIS.get(unit['placement'], "⚔️")
        placement_display += (
            f"**Slot {unit['slot']+1}** {placement_emoji} "
            f"{get_unit_emoji(unit['unit_id'])} **{unit['unit_name']}** - {unit['placement'].title()}\n"
        )
    
    embed = create_embed(
        "📍 Unit Placement",
        f"**Current Positions:**\n\n{placement_display}\n"
        f"**Click a unit button to cycle placement:**\n"
        f"🛡️ Front → ⚔️ Middle → 🎯 Back\n\n"
        f"*Placement affects battle strategy!*\n"
        f"• **Front**: Takes more damage, deals more\n"
        f"• **Middle**: Balanced position\n"
        f"• **Back**: Safer, good for ranged units",
        0x00BFFF
    )
    
    try:
        await interaction.response.edit_message(embed=embed, view=PlacementMenuView(interaction.user.id, equipped))
    except:
        await interaction.response.send_message(embed=embed, view=PlacementMenuView(interaction.user.id, equipped))

async def show_upgrade_menu(interaction: discord.Interaction, page: int):
    equipped = await get_equipped_units(interaction.user.id)
    
    if not equipped:
        embed = create_embed(
            "No Equipped Units",
            "Equip some units first before upgrading!",
            0xFF6600
        )
        try:
            await interaction.response.edit_message(embed=embed, view=LoadoutView(interaction.user.id))
        except:
            await interaction.response.send_message(embed=embed, view=LoadoutView(interaction.user.id))
        return
    
    upgradeable = []
    for unit in equipped:
        dupes = await get_duplicate_units(interaction.user.id, unit['unit_id'])
        if dupes:
            upgradeable.append((dict(unit), len(dupes)))
    
    if not upgradeable:
        embed = create_embed(
            "No Upgrades Available",
            "You need **duplicate units** to upgrade!\n\n"
            "Sacrificing a duplicate will increase the equipped unit's level and stats.\n\n"
            "*Summon more units to get duplicates!*",
            0xFF6600
        )
        try:
            await interaction.response.edit_message(embed=embed, view=LoadoutView(interaction.user.id))
        except:
            await interaction.response.send_message(embed=embed, view=LoadoutView(interaction.user.id))
        return
    
    per_page = 5
    total_pages = (len(upgradeable) + per_page - 1) // per_page
    page = max(1, min(page, total_pages))
    
    start_idx = (page - 1) * per_page
    page_units = upgradeable[start_idx:start_idx + per_page]
    
    upgrade_display = ""
    for unit, dupes in page_units:
        upgrade_display += (
            f"{RARITY_EMOJIS.get(unit['rarity'], '⚪')} "
            f"{get_unit_emoji(unit['unit_id'])} **{unit['unit_name']}** "
            f"(Lv.{unit['level']}) - **{dupes}** dupes available\n"
        )
    
    embed = create_embed(
        f"⬆️ Upgrade Units (Page {page}/{total_pages})",
        f"**Upgradeable Units:**\n\n{upgrade_display}\n"
        f"*Sacrifice duplicates to upgrade stats!*\n"
        f"Each upgrade increases Attack and Defense.",
        0x00FF00
    )
    
    try:
        await interaction.response.edit_message(embed=embed, view=UpgradeMenuView(interaction.user.id, page_units, page, total_pages))
    except:
        await interaction.response.send_message(embed=embed, view=UpgradeMenuView(interaction.user.id, page_units, page, total_pages))

async def show_summon_menu(interaction: discord.Interaction):
    player = await get_player(interaction.user.id)
    if not player:
        await interaction.response.send_message("Use `/start` first!", ephemeral=True)
        return
    
    description = (
        f"```ansi\n"
        f"\u001b[1;33m╔═══════════════════════════════════╗\u001b[0m\n"
        f"\u001b[1;35m    🎰 GACHA SUMMONING SHRINE 🎰   \u001b[0m\n"
        f"\u001b[1;33m╚═══════════════════════════════════╝\u001b[0m\n"
        f"```\n"
        f"**━━━ 💰 Your Balance ━━━**\n"
        f"💰 Coins: `{format_number(player['coins'])}` | 💎 Gems: `{player['gems']}`\n\n"
        f"**━━━ 🎁 Available Crates ━━━**\n\n"
        f"📦 **Standard Crate** - `100 Coins`\n"
        f"   ├ ⚪ Basic → 🟡 Legendary\n"
        f"   └ *Best for beginners!*\n\n"
        f"🎁 **10x Standard** - `900 Coins`\n"
        f"   └ ✨ *One FREE pull!* ✨\n\n"
        f"💎 **Premium Crate** - `50 Gems`\n"
        f"   ├ 🔵 Rare+ guaranteed!\n"
        f"   └ 🔴 *Godly chance!*\n\n"
        f"🔮 **Mythic Crate** - `150 Gems`\n"
        f"   ├ 🟣 Epic+ guaranteed!\n"
        f"   └ 💠 *Celestial chance!*\n\n"
        f"*Good luck, defender!* 🍀"
    )
    
    embed = discord.Embed(
        title="✧ Summon Menu ✧",
        description=description,
        color=THEME_COLORS["summon"]
    )
    embed.set_footer(text="🚽 Toilet Tower Defense 🚽")
    embed.timestamp = discord.utils.utcnow()
    
    try:
        await interaction.response.edit_message(embed=embed, view=SummonMenuView(interaction.user.id))
    except:
        await interaction.response.send_message(embed=embed, view=SummonMenuView(interaction.user.id))

async def do_summon(interaction: discord.Interaction, crate_type: str, count: int):
    player = await get_player(interaction.user.id)
    if not player:
        await interaction.response.send_message("Use `/start` first!", ephemeral=True)
        return
    
    crate = CRATES.get(crate_type)
    if not crate:
        await interaction.response.send_message("Invalid crate type!", ephemeral=True)
        return
    
    cost = crate['cost'] * (count if count < 10 else 9)
    currency = crate['currency']
    
    if player[currency] < cost:
        await interaction.response.send_message(f"Not enough {currency}! Need {cost}, have {player[currency]}", ephemeral=True)
        return
    
    await update_player(interaction.user.id, **{currency: player[currency] - cost})
    
    units = []
    for _ in range(count):
        unit = roll_crate(crate_type)
        if unit:
            await add_unit_to_inventory(interaction.user.id, unit)
            units.append(unit)
    
    if count == 1:
        unit = units[0]
        color = RARITY_COLORS.get(unit['rarity'], 0x808080)
        emoji = RARITY_EMOJIS.get(unit['rarity'], '⚪')
        ability_text = f"\n🎯 Ability: {ABILITY_EMOJIS.get(unit.get('ability', ''), '')} {unit.get('ability', 'None').title()}" if unit.get('ability') else ""
        
        embed = create_embed(
            f"{crate['emoji']} {crate['name']} Opened!",
            f"{emoji} **{unit['rarity']}** {emoji}\n\n"
            f"{unit['emoji']} **{unit['name']}**\n\n"
            f"⚔️ Attack: {unit['attack']}\n"
            f"🛡️ Defense: {unit['defense']}\n"
            f"📏 Range: {unit['range']}\n"
            f"💥 DPS: {unit.get('dps', unit['attack'])}"
            f"{ability_text}",
            color
        )
    else:
        units_display = "\n".join(
            f"{RARITY_EMOJIS.get(u['rarity'], '⚪')} {u['emoji']} **{u['name']}** ({u['rarity']})"
            for u in units
        )
        best_unit = max(units, key=lambda u: list(RARITY_COLORS.keys()).index(u['rarity']) if u['rarity'] in RARITY_COLORS else 0)
        color = RARITY_COLORS.get(best_unit['rarity'], 0x808080)
        
        embed = create_embed(
            f"🎰 {count}x Summon Complete!",
            f"**Units Obtained:**\n\n{units_display}",
            color
        )
    
    embed.set_footer(text=f"Remaining: {player[currency] - cost} {currency}")
    
    try:
        await interaction.response.edit_message(embed=embed, view=SummonMenuView(interaction.user.id))
    except:
        await interaction.response.send_message(embed=embed, view=SummonMenuView(interaction.user.id))

async def show_rates(interaction: discord.Interaction):
    rates_text = ""
    for crate_name, crate in CRATES.items():
        rates_text += f"\n**{crate['emoji']} {crate['name']}** ({crate['cost']} {crate['currency']})\n"
        for rarity, rate in crate['rates'].items():
            rates_text += f"{RARITY_EMOJIS.get(rarity, '⚪')} {rarity}: {rate}%\n"
    
    embed = create_embed("📊 Summon Rates", rates_text, 0xFFD700)
    
    try:
        await interaction.response.edit_message(embed=embed, view=SummonMenuView(interaction.user.id))
    except:
        await interaction.response.send_message(embed=embed, view=SummonMenuView(interaction.user.id))

async def show_battle_menu(interaction: discord.Interaction):
    player = await get_player(interaction.user.id)
    if not player:
        await interaction.response.send_message("Use `/start` first!", ephemeral=True)
        return
    
    if interaction.user.id in active_auto_battles:
        await interaction.response.send_message("You already have an active battle! Use the retreat button to end it.", ephemeral=True)
        return
    
    equipped = await get_equipped_units(interaction.user.id)
    
    if not equipped:
        inventory = await get_inventory(interaction.user.id)
        if not inventory:
            await interaction.response.send_message("You need at least one unit to battle! Use `/summon` first.", ephemeral=True)
            return
        
        embed = create_embed(
            "⚔️ No Units Equipped!",
            "You need to equip units to your loadout before battling!\n\n"
            "**Options:**\n"
            "1. Click 'Manage Loadout' to equip units manually\n"
            "2. Use 'Auto-Equip' in the loadout menu for quick setup\n\n"
            f"*You have {len(inventory)} units available to equip*",
            0xFF6600
        )
        try:
            await interaction.response.edit_message(embed=embed, view=BattleMenuView(interaction.user.id))
        except:
            await interaction.response.send_message(embed=embed, view=BattleMenuView(interaction.user.id))
        return
    
    battle_power = calculate_battle_power([dict(u) for u in equipped])
    
    loadout_preview = " ".join(get_unit_emoji(unit['unit_id']) for unit in equipped[:6])
    if len(equipped) > 6:
        loadout_preview += f" +{len(equipped) - 6}"
    
    power_bar = create_progress_bar(min(battle_power, 5000), 5000, 10, "▓", "░")
    
    diff_text = ""
    for diff_id, diff in DIFFICULTIES.items():
        max_slots = MAX_LOADOUT_SLOTS.get(diff_id, 6)
        diff_text += (
            f"{diff['emoji']} **{diff['name']}**\n"
            f"   └ Waves: `{diff['max_wave']}` | Units: `{max_slots}` | Rewards: `x{diff['reward_mult']}`\n"
        )
    
    description = (
        f"```ansi\n"
        f"\u001b[1;31m╔═══════════════════════════════════╗\u001b[0m\n"
        f"\u001b[1;33m       ⚔️ BATTLE ARENA ⚔️           \u001b[0m\n"
        f"\u001b[1;31m╚═══════════════════════════════════╝\u001b[0m\n"
        f"```\n"
        f"**━━━ 🎒 Your Loadout ━━━**\n"
        f"📦 Units: `{len(equipped)}/10`\n"
        f"💪 Power: `[{power_bar}]` {format_number(battle_power)}\n"
        f"🎖️ Team: {loadout_preview}\n\n"
        f"**━━━ 🎮 Select Difficulty ━━━**\n"
        f"{diff_text}\n"
        f"*⚔️ Battles run automatically with your units!*"
    )
    
    embed = discord.Embed(
        title="✧ Battle Arena ✧",
        description=description,
        color=THEME_COLORS["battle"]
    )
    embed.set_footer(text="🚽 Toilet Tower Defense 🚽")
    embed.timestamp = discord.utils.utcnow()
    
    try:
        await interaction.response.edit_message(embed=embed, view=BattleMenuView(interaction.user.id))
    except:
        await interaction.response.send_message(embed=embed, view=BattleMenuView(interaction.user.id))

async def start_auto_battle(interaction: discord.Interaction, difficulty: str):
    try:
        if not interaction.response.is_done():
            await interaction.response.defer()
    except Exception as e:
        print(f"Defer error (non-critical): {e}")
    
    try:
        player = await get_player(interaction.user.id)
        if not player:
            try:
                await interaction.followup.send("Use `/start` first!", ephemeral=True)
            except:
                await interaction.channel.send(f"{interaction.user.mention} Use `/start` first!")
            return
        
        if interaction.user.id in active_auto_battles:
            try:
                await interaction.followup.send("You already have an active battle!", ephemeral=True)
            except:
                await interaction.channel.send(f"{interaction.user.mention} You already have an active battle!")
            return
        
        equipped = await get_equipped_units(interaction.user.id)
        
        if not equipped:
            try:
                await interaction.followup.send("You need to equip units first! Go to Loadout menu.", ephemeral=True)
            except:
                await interaction.channel.send(f"{interaction.user.mention} You need to equip units first!")
            return
        
        max_slots = MAX_LOADOUT_SLOTS.get(difficulty, 6)
        battle_units = [dict(u) for u in equipped[:max_slots]]
        
        diff = DIFFICULTIES.get(difficulty, DIFFICULTIES["normal"])
        session_id = await create_battle_session(interaction.user.id, difficulty)
        
        active_auto_battles[interaction.user.id] = {
            "session_id": session_id,
            "difficulty": difficulty,
            "running": True
        }
        
        units_in_battle = " ".join(get_unit_display_icon(u['unit_id']) for u in battle_units)
        power_bar = create_progress_bar(len(battle_units), max_slots, 8, "▓", "░")
        
        description = (
            f"```ansi\n"
            f"\u001b[1;31m╔═══════════════════════════════════╗\u001b[0m\n"
            f"\u001b[1;33m   🚽 THE TOILETS ARE COMING! 🚽    \u001b[0m\n"
            f"\u001b[1;31m╚═══════════════════════════════════╝\u001b[0m\n"
            f"```\n"
            f"**━━━ {diff['emoji']} {diff['name']} Mode ━━━**\n\n"
            f"📊 **Max Waves:** `{diff['max_wave']}`\n"
            f"🎖️ **Your Team:** {units_in_battle}\n"
            f"📦 **Units:** `[{power_bar}]` {len(battle_units)}/{max_slots}\n\n"
            f"⏳ *Battle starting in 3 seconds...*\n\n"
            f"💡 *Click 'Retreat & Collect' anytime to end and claim rewards!*"
        )
        
        embed = discord.Embed(
            title=f"✧ {diff['name']} Battle Started! ✧",
            description=description,
            color=diff['color']
        )
        embed.set_footer(text="🚽 Toilet Tower Defense 🚽")
        embed.timestamp = discord.utils.utcnow()
        
        try:
            message = await interaction.followup.send(embed=embed, view=AutoBattleView(interaction.user.id), wait=True)
        except Exception as followup_error:
            print(f"Followup failed, trying channel send: {followup_error}")
            message = await interaction.channel.send(embed=embed, view=AutoBattleView(interaction.user.id))
        
        asyncio.create_task(run_auto_battle(interaction.user.id, message, difficulty, battle_units))
        
    except Exception as e:
        print(f"Battle start error: {e}")
        import traceback
        traceback.print_exc()
        if interaction.user.id in active_auto_battles:
            del active_auto_battles[interaction.user.id]
        try:
            await interaction.followup.send("An error occurred starting the battle. Please try again.", ephemeral=True)
        except:
            try:
                await interaction.channel.send(f"{interaction.user.mention} An error occurred starting the battle. Please try again.")
            except:
                pass

async def start_auto_battle_with_map(interaction: discord.Interaction, difficulty: str, map_id: str):
    try:
        if not interaction.response.is_done():
            await interaction.response.defer()
    except Exception as e:
        print(f"Defer error (non-critical): {e}")
    
    try:
        player = await get_player(interaction.user.id)
        if not player:
            try:
                await interaction.followup.send("Use `/start` first!", ephemeral=True)
            except:
                await interaction.channel.send(f"{interaction.user.mention} Use `/start` first!")
            return
        
        if interaction.user.id in active_auto_battles:
            try:
                await interaction.followup.send("You already have an active battle!", ephemeral=True)
            except:
                await interaction.channel.send(f"{interaction.user.mention} You already have an active battle!")
            return
        
        map_data = MAPS.get(map_id, MAPS["classic"])
        if player['level'] < map_data.get('unlock_level', 1):
            try:
                await interaction.followup.send(
                    f"You need to be level {map_data['unlock_level']} to access this map!",
                    ephemeral=True
                )
            except:
                await interaction.channel.send(f"{interaction.user.mention} You need to be level {map_data['unlock_level']} to access this map!")
            return
        
        equipped = await get_equipped_units(interaction.user.id)
        
        if not equipped:
            try:
                await interaction.followup.send("You need to equip units first! Go to Loadout menu.", ephemeral=True)
            except:
                await interaction.channel.send(f"{interaction.user.mention} You need to equip units first!")
            return
        
        max_slots = MAX_LOADOUT_SLOTS.get(difficulty, 6)
        battle_units = [dict(u) for u in equipped[:max_slots]]
        
        diff = DIFFICULTIES.get(difficulty, DIFFICULTIES["normal"])
        session_id = await create_battle_session(interaction.user.id, difficulty)
        
        active_auto_battles[interaction.user.id] = {
            "session_id": session_id,
            "difficulty": difficulty,
            "map": map_id,
            "running": True
        }
        
        units_in_battle = " ".join(get_unit_display_icon(u['unit_id']) for u in battle_units)
        power_bar = create_progress_bar(len(battle_units), max_slots, 8, "▓", "░")
        
        description = (
            f"```ansi\n"
            f"\u001b[1;31m╔═══════════════════════════════════╗\u001b[0m\n"
            f"\u001b[1;33m   🚽 THE TOILETS ARE COMING! 🚽    \u001b[0m\n"
            f"\u001b[1;31m╚═══════════════════════════════════╝\u001b[0m\n"
            f"```\n"
            f"**━━━ {diff['emoji']} {diff['name']} Mode ━━━**\n"
            f"**━━━ {map_data['emoji']} {map_data['name']} ━━━**\n\n"
            f"📊 **Max Waves:** `{diff['max_wave']}`\n"
            f"💰 **Reward Mult:** `x{map_data['reward_mult']}`\n"
            f"🎖️ **Your Team:** {units_in_battle}\n"
            f"📦 **Units:** `[{power_bar}]` {len(battle_units)}/{max_slots}\n\n"
            f"⏳ *Battle starting in 3 seconds...*\n\n"
            f"💡 *Click 'Retreat & Collect' anytime to end and claim rewards!*"
        )
        
        embed = discord.Embed(
            title=f"✧ {map_data['name']} - {diff['name']} ✧",
            description=description,
            color=map_data.get('color', diff['color'])
        )
        embed.set_footer(text="🚽 Toilet Tower Defense 🚽")
        embed.timestamp = discord.utils.utcnow()
        
        try:
            message = await interaction.followup.send(embed=embed, view=AutoBattleView(interaction.user.id), wait=True)
        except Exception as followup_error:
            print(f"Followup failed, trying channel send: {followup_error}")
            message = await interaction.channel.send(embed=embed, view=AutoBattleView(interaction.user.id))
        
        asyncio.create_task(run_auto_battle_with_map(interaction.user.id, message, difficulty, battle_units, map_data))
        
    except Exception as e:
        print(f"Battle start error: {e}")
        import traceback
        traceback.print_exc()
        if interaction.user.id in active_auto_battles:
            del active_auto_battles[interaction.user.id]
        try:
            await interaction.followup.send("An error occurred starting the battle. Please try again.", ephemeral=True)
        except:
            try:
                await interaction.channel.send(f"{interaction.user.mention} An error occurred starting the battle. Please try again.")
            except:
                pass

async def run_auto_battle_with_map(user_id: int, message: discord.Message, difficulty: str, player_units: list, map_data: dict):
    await asyncio.sleep(3)
    
    if user_id not in active_auto_battles:
        return
    
    diff = DIFFICULTIES.get(difficulty, DIFFICULTIES["normal"])
    session_id = active_auto_battles[user_id]["session_id"]
    
    current_wave = 1
    total_coins = 0
    total_enemies = 0
    total_damage = 0
    player_hp = 100
    
    map_reward_mult = map_data.get('reward_mult', 1.0)
    map_difficulty_mult = map_data.get('difficulty_mult', 1.0)
    
    front_units = [u for u in player_units if u.get('placement', 'middle') == 'front']
    back_units = [u for u in player_units if u.get('placement', 'back') == 'back']
    
    for unit in front_units:
        unit['attack'] = int(unit['attack'] * 1.15)
    for unit in back_units:
        unit['defense'] = int(unit['defense'] * 1.15)
    
    map_id = map_data.get('id', 'classic')
    while current_wave <= diff['max_wave'] and user_id in active_auto_battles and active_auto_battles[user_id]["running"]:
        enemies = get_enemies_for_wave(current_wave, difficulty, map_id)
        is_boss_wave = current_wave % 10 == 0
        result = simulate_wave(player_units, enemies, is_boss_wave)
        
        wave_coins = int(result['coins_earned'] * map_reward_mult)
        total_coins += wave_coins
        total_enemies += result['enemies_defeated']
        total_damage += result['damage_dealt']
        player_hp = result['player_hp']
        
        await update_battle(session_id, current_wave=current_wave, hp=player_hp, coins_earned=total_coins)
        
        enemy_display = " ".join(e['emoji'] for e in enemies[:8])
        if len(enemies) > 8:
            enemy_display += f" +{len(enemies) - 8}"
        
        unit_display = " ".join(get_unit_display_icon(u['unit_id']) for u in player_units[:6])
        
        status = "🟢 VICTORY!" if result['won'] else "🔴 DEFEAT!"
        hp_bar = create_hp_bar(player_hp, 100)
        wave_bar = create_progress_bar(current_wave, diff['max_wave'], 10, "▓", "░")
        
        boss_text = "\n⚠️ **BOSS WAVE!** ⚠️\n" if is_boss_wave else ""
        
        description = (
            f"```ansi\n"
            f"\u001b[1;{'31' if not result['won'] else '32'}m══════ WAVE {current_wave}/{diff['max_wave']} ══════\u001b[0m\n"
            f"```\n"
            f"{boss_text}"
            f"**━━━ ⚔️ Battle Result ━━━**\n"
            f"**Status:** {status}\n"
            f"**HP:** {hp_bar}\n\n"
            f"**━━━ 👥 Teams ━━━**\n"
            f"🛡️ **Your Units:** {unit_display}\n"
            f"🚽 **Enemies:** {enemy_display}\n\n"
            f"**━━━ 📊 Wave Stats ━━━**\n"
            f"💀 Defeated: `{result['enemies_defeated']}/{len(enemies)}`\n"
            f"💥 Damage: `{format_number(result['damage_dealt'])}`\n\n"
            f"**━━━ 📈 Total Progress ━━━**\n"
            f"🌊 Waves: `[{wave_bar}]` {current_wave}/{diff['max_wave']}\n"
            f"💰 Coins: `{format_number(total_coins)}` (x{map_reward_mult})\n"
            f"🔥 Enemies: `{total_enemies}` | ⚔️ Damage: `{format_number(total_damage)}`"
        )
        
        embed = discord.Embed(
            title=f"✧ {map_data['emoji']} {map_data['name']} - {diff['name']} ✧",
            description=description,
            color=THEME_COLORS["success"] if result['won'] else THEME_COLORS["warning"]
        )
        embed.set_footer(text="🚽 Toilet Tower Defense 🚽")
        embed.timestamp = discord.utils.utcnow()
        
        try:
            await message.edit(embed=embed, view=AutoBattleView(user_id))
        except:
            break
        
        if not result['won']:
            await finish_battle(user_id, message, difficulty, current_wave, total_coins, total_enemies, total_damage, won=False)
            return
        
        current_wave += 1
        await asyncio.sleep(2)
    
    if user_id in active_auto_battles:
        await finish_battle(user_id, message, difficulty, current_wave - 1, total_coins, total_enemies, total_damage, won=True)

async def run_auto_battle(user_id: int, message: discord.Message, difficulty: str, player_units: list):
    await asyncio.sleep(3)
    
    if user_id not in active_auto_battles:
        return
    
    diff = DIFFICULTIES.get(difficulty, DIFFICULTIES["normal"])
    session_id = active_auto_battles[user_id]["session_id"]
    
    current_wave = 1
    total_coins = 0
    total_enemies = 0
    total_damage = 0
    player_hp = 100
    
    front_units = [u for u in player_units if u.get('placement', 'middle') == 'front']
    middle_units = [u for u in player_units if u.get('placement', 'middle') == 'middle']
    back_units = [u for u in player_units if u.get('placement', 'back') == 'back']
    
    for unit in front_units:
        unit['attack'] = int(unit['attack'] * 1.15)
    for unit in back_units:
        unit['defense'] = int(unit['defense'] * 1.15)
    
    while current_wave <= diff['max_wave'] and user_id in active_auto_battles and active_auto_battles[user_id]["running"]:
        enemies = get_enemies_for_wave(current_wave, difficulty)
        is_boss_wave = current_wave % 10 == 0
        result = simulate_wave(player_units, enemies, is_boss_wave)
        
        total_coins += result['coins_earned']
        total_enemies += result['enemies_defeated']
        total_damage += result['damage_dealt']
        player_hp = result['player_hp']
        
        await update_battle(session_id, current_wave=current_wave, hp=player_hp, coins_earned=total_coins)
        
        enemy_display = " ".join(e['emoji'] for e in enemies[:8])
        if len(enemies) > 8:
            enemy_display += f" +{len(enemies) - 8}"
        
        unit_display = " ".join(get_unit_display_icon(u['unit_id']) for u in player_units[:6])
        
        status = "🟢 VICTORY!" if result['won'] else "🔴 DEFEAT!"
        hp_bar = create_hp_bar(player_hp, 100)
        wave_bar = create_progress_bar(current_wave, diff['max_wave'], 10, "▓", "░")
        
        boss_text = "\n⚠️ **BOSS WAVE!** ⚠️\n" if is_boss_wave else ""
        
        description = (
            f"```ansi\n"
            f"\u001b[1;{'31' if not result['won'] else '32'}m══════ WAVE {current_wave}/{diff['max_wave']} ══════\u001b[0m\n"
            f"```\n"
            f"{boss_text}"
            f"**━━━ ⚔️ Battle Result ━━━**\n"
            f"**Status:** {status}\n"
            f"**HP:** {hp_bar}\n\n"
            f"**━━━ 👥 Teams ━━━**\n"
            f"🛡️ **Your Units:** {unit_display}\n"
            f"🚽 **Enemies:** {enemy_display}\n\n"
            f"**━━━ 📊 Wave Stats ━━━**\n"
            f"💀 Defeated: `{result['enemies_defeated']}/{len(enemies)}`\n"
            f"💥 Damage: `{format_number(result['damage_dealt'])}`\n\n"
            f"**━━━ 📈 Total Progress ━━━**\n"
            f"🌊 Waves: `[{wave_bar}]` {current_wave}/{diff['max_wave']}\n"
            f"💰 Coins: `{format_number(total_coins)}`\n"
            f"🔥 Enemies: `{total_enemies}` | ⚔️ Damage: `{format_number(total_damage)}`"
        )
        
        embed = discord.Embed(
            title=f"✧ {diff['emoji']} {diff['name']} Battle ✧",
            description=description,
            color=THEME_COLORS["success"] if result['won'] else THEME_COLORS["warning"]
        )
        embed.set_footer(text="🚽 Toilet Tower Defense 🚽")
        embed.timestamp = discord.utils.utcnow()
        
        try:
            await message.edit(embed=embed, view=AutoBattleView(user_id))
        except:
            break
        
        if not result['won']:
            await finish_battle(user_id, message, difficulty, current_wave, total_coins, total_enemies, total_damage, won=False)
            return
        
        current_wave += 1
        await asyncio.sleep(2)
    
    if user_id in active_auto_battles:
        await finish_battle(user_id, message, difficulty, current_wave - 1, total_coins, total_enemies, total_damage, won=True)

async def finish_battle(user_id: int, message: discord.Message, difficulty: str, final_wave: int, coins: int, enemies: int, damage: int, won: bool):
    if user_id not in active_auto_battles:
        return
    
    session_id = active_auto_battles[user_id]["session_id"]
    del active_auto_battles[user_id]
    
    await end_battle(session_id)
    
    player = await get_player(user_id)
    if player:
        xp_earned = enemies * 5 + final_wave * 10
        new_xp = player['experience'] + xp_earned
        new_level = player['level']
        
        while new_xp >= new_level * 100:
            new_xp -= new_level * 100
            new_level += 1
        
        update_data = {
            'coins': player['coins'] + coins,
            'experience': new_xp,
            'level': new_level
        }
        
        if won:
            update_data['wins'] = player['wins'] + 1
        else:
            update_data['losses'] = player['losses'] + 1
        
        if final_wave > player['highest_wave']:
            update_data['highest_wave'] = final_wave
        
        await update_player(user_id, **update_data)
        
        level_up_text = f"\n🎉 **LEVEL UP!** Level {new_level}!" if new_level > player['level'] else ""
        
        diff = DIFFICULTIES.get(difficulty, DIFFICULTIES["normal"])
        status = "🏆 VICTORY!" if won else "💀 GAME OVER"
        color = 0x00FF00 if won else 0xFF0000
        
        embed = create_embed(
            f"{status}",
            f"**{diff['emoji']} {diff['name']} Mode**\n\n"
            f"**Final Wave:** {final_wave}\n"
            f"**Enemies Defeated:** {enemies}\n"
            f"**Total Damage:** {damage:,}\n\n"
            f"**Rewards:**\n"
            f"💰 Coins: +{coins:,}\n"
            f"⭐ XP: +{xp_earned}"
            f"{level_up_text}",
            color
        )
        
        try:
            await message.edit(embed=embed, view=None)
        except:
            pass

async def retreat_battle(interaction: discord.Interaction):
    if interaction.user.id not in active_auto_battles:
        await interaction.response.send_message("You don't have an active battle!", ephemeral=True)
        return
    
    battle_data = active_auto_battles[interaction.user.id]
    battle_data["running"] = False
    
    session = await get_active_battle(interaction.user.id)
    if session:
        coins = session['coins_earned']
        wave = session['current_wave']
        xp_earned = wave * 8
        
        del active_auto_battles[interaction.user.id]
        await end_battle(session['id'])
        
        player = await get_player(interaction.user.id)
        if player:
            await update_player(
                interaction.user.id,
                coins=player['coins'] + coins,
                experience=player['experience'] + xp_earned
            )
        
        embed = create_embed(
            "🏃 Retreated!",
            f"You retreated from battle!\n\n"
            f"**Collected:**\n"
            f"💰 Coins: {coins:,}\n"
            f"⭐ XP: {xp_earned}\n"
            f"🌊 Reached Wave: {wave}",
            0xFF6600
        )
        
        await interaction.response.edit_message(embed=embed, view=None)
    else:
        await interaction.response.send_message("Error ending battle.", ephemeral=True)

async def show_inventory(interaction: discord.Interaction, page: int):
    player = await get_player(interaction.user.id)
    if not player:
        await interaction.response.send_message("Use `/start` first!", ephemeral=True)
        return
    
    units = await get_inventory(interaction.user.id)
    
    if not units:
        embed = create_embed("📦 Your Inventory", "You don't have any units yet!\n\nUse `/summon` to get some!", 0x808080)
        try:
            await interaction.response.edit_message(embed=embed, view=MainMenuView(interaction.user.id))
        except:
            await interaction.response.send_message(embed=embed, view=MainMenuView(interaction.user.id))
        return
    
    per_page = 8
    total_pages = (len(units) + per_page - 1) // per_page
    page = max(1, min(page, total_pages))
    
    start_idx = (page - 1) * per_page
    page_units = units[start_idx:start_idx + per_page]
    
    units_display = ""
    for u in page_units:
        equipped_slot = await is_unit_equipped(interaction.user.id, u['id'])
        equipped_text = f" [🎒 Slot {equipped_slot + 1}]" if equipped_slot is not None else ""
        ability = get_unit_ability(u['unit_id'])
        ability_text = f" {ABILITY_EMOJIS.get(ability, '')}" if ability else ""
        
        units_display += (
            f"`#{u['id']}` {RARITY_EMOJIS.get(u['rarity'], '⚪')} "
            f"{get_unit_emoji(u['unit_id'])} **{u['unit_name']}** "
            f"(Lv.{u['level']}){ability_text}{equipped_text}\n"
            f"   ⚔️{u['attack']} 🛡️{u['defense']} 📏{u['range']}\n"
        )
    
    embed = create_embed(
        f"📦 Your Inventory ({len(units)} units)",
        f"{units_display}\nPage {page}/{total_pages}",
        0x00BFFF
    )
    
    try:
        await interaction.response.edit_message(embed=embed, view=InventoryView(interaction.user.id, page, total_pages))
    except:
        await interaction.response.send_message(embed=embed, view=InventoryView(interaction.user.id, page, total_pages))

async def show_shop(interaction: discord.Interaction):
    player = await get_player(interaction.user.id)
    if not player:
        await interaction.response.send_message("Use `/start` first!", ephemeral=True)
        return
    
    embed = create_embed(
        "🏪 Shop",
        f"**Your Balance:**\n"
        f"💰 {player['coins']:,} Coins | 💎 {player['gems']} Gems\n\n"
        f"**Available Purchases:**\n"
        f"💰 1,000 Coins - 50 Gems\n"
        f"💎 100 Gems - 1,000 Coins",
        0x00BFFF
    )
    
    try:
        await interaction.response.edit_message(embed=embed, view=ShopView(interaction.user.id))
    except:
        await interaction.response.send_message(embed=embed, view=ShopView(interaction.user.id))

async def claim_daily(interaction: discord.Interaction):
    player = await get_player(interaction.user.id)
    if not player:
        await interaction.response.send_message("Use `/start` first!", ephemeral=True)
        return
    
    now = datetime.utcnow()
    last_daily = player['last_daily']
    
    if last_daily:
        last_claim = datetime.fromisoformat(last_daily)
        if (now - last_claim).total_seconds() < 86400:
            time_left = timedelta(days=1) - (now - last_claim)
            hours, remainder = divmod(int(time_left.total_seconds()), 3600)
            minutes = remainder // 60
            embed = create_embed("⏰ Daily Not Ready", f"Come back in **{hours}h {minutes}m**!", 0xFF6600)
            try:
                await interaction.response.edit_message(embed=embed, view=MainMenuView(interaction.user.id))
            except:
                await interaction.response.send_message(embed=embed, view=MainMenuView(interaction.user.id))
            return
    
    coins_reward = random.randint(150, 400)
    gems_reward = random.randint(8, 20)
    
    await update_player(
        interaction.user.id,
        coins=player['coins'] + coins_reward,
        gems=player['gems'] + gems_reward,
        last_daily=now.isoformat()
    )
    
    embed = create_embed(
        "🎁 Daily Rewards Claimed!",
        f"**You received:**\n"
        f"💰 {coins_reward} Coins\n"
        f"💎 {gems_reward} Gems",
        0xFFD700
    )
    
    try:
        await interaction.response.edit_message(embed=embed, view=MainMenuView(interaction.user.id))
    except:
        await interaction.response.send_message(embed=embed, view=MainMenuView(interaction.user.id))

async def show_leaderboard(interaction: discord.Interaction):
    players = await get_leaderboard("wins", 10)
    
    if not players:
        embed = create_embed("🏆 Leaderboard", "No players found!", 0xFFD700)
    else:
        medals = ["🥇", "🥈", "🥉"]
        leaderboard_display = ""
        
        for i, player in enumerate(players):
            medal = medals[i] if i < 3 else f"`{i+1}.`"
            leaderboard_display += f"{medal} **{player['username']}** - {player['wins']} wins | Wave {player['highest_wave']}\n"
        
        embed = create_embed("🏆 Top Players", leaderboard_display, 0xFFD700)
    
    try:
        await interaction.response.edit_message(embed=embed, view=MainMenuView(interaction.user.id))
    except:
        await interaction.response.send_message(embed=embed, view=MainMenuView(interaction.user.id))

async def check_achievements(user_id: int, player: dict, inventory: list = None):
    unlocked = []
    
    if player['wins'] >= 1 and not await has_achievement(user_id, "first_win"):
        if await unlock_achievement(user_id, "first_win"):
            unlocked.append("first_win")
    
    if player['wins'] >= 10 and not await has_achievement(user_id, "10_wins"):
        if await unlock_achievement(user_id, "10_wins"):
            unlocked.append("10_wins")
    
    if player['wins'] >= 50 and not await has_achievement(user_id, "50_wins"):
        if await unlock_achievement(user_id, "50_wins"):
            unlocked.append("50_wins")
    
    if player['wins'] >= 100 and not await has_achievement(user_id, "100_wins"):
        if await unlock_achievement(user_id, "100_wins"):
            unlocked.append("100_wins")
    
    if player['highest_wave'] >= 20 and not await has_achievement(user_id, "wave_20"):
        if await unlock_achievement(user_id, "wave_20"):
            unlocked.append("wave_20")
    
    if player['highest_wave'] >= 50 and not await has_achievement(user_id, "wave_50"):
        if await unlock_achievement(user_id, "wave_50"):
            unlocked.append("wave_50")
    
    if inventory:
        if len(inventory) >= 10 and not await has_achievement(user_id, "collector_10"):
            if await unlock_achievement(user_id, "collector_10"):
                unlocked.append("collector_10")
        
        if len(inventory) >= 50 and not await has_achievement(user_id, "collector_50"):
            if await unlock_achievement(user_id, "collector_50"):
                unlocked.append("collector_50")
        
        for unit in inventory:
            rarity = unit.get('rarity', '')
            if rarity == 'Legendary' and not await has_achievement(user_id, "first_legendary"):
                if await unlock_achievement(user_id, "first_legendary"):
                    unlocked.append("first_legendary")
            elif rarity == 'Mythic' and not await has_achievement(user_id, "first_mythic"):
                if await unlock_achievement(user_id, "first_mythic"):
                    unlocked.append("first_mythic")
            elif rarity == 'Godly' and not await has_achievement(user_id, "first_godly"):
                if await unlock_achievement(user_id, "first_godly"):
                    unlocked.append("first_godly")
            elif rarity == 'Celestial' and not await has_achievement(user_id, "first_celestial"):
                if await unlock_achievement(user_id, "first_celestial"):
                    unlocked.append("first_celestial")
    
    total_coins = 0
    total_gems = 0
    for ach_id in unlocked:
        ach = ACHIEVEMENTS.get(ach_id, {})
        total_coins += ach.get('reward_coins', 0)
        total_gems += ach.get('reward_gems', 0)
    
    if total_coins > 0 or total_gems > 0:
        await update_player(user_id, coins=player['coins'] + total_coins, gems=player['gems'] + total_gems)
    
    return unlocked

async def show_achievements(interaction: discord.Interaction):
    player = await get_player(interaction.user.id)
    if not player:
        await interaction.response.send_message("Use `/start` first!", ephemeral=True)
        return
    
    user_achievements = await get_achievements(interaction.user.id)
    unlocked_ids = [a['achievement_id'] for a in user_achievements]
    
    unlocked_display = ""
    locked_display = ""
    
    for ach_id, ach in ACHIEVEMENTS.items():
        if ach_id in unlocked_ids:
            unlocked_display += f"{ach['emoji']} **{ach['name']}** ✅\n└ *{ach['description']}*\n"
        else:
            locked_display += f"🔒 **{ach['name']}**\n└ *{ach['description']}*\n└ 💰{ach['reward_coins']} 💎{ach['reward_gems']}\n"
    
    progress = len(unlocked_ids) / len(ACHIEVEMENTS) * 100
    progress_bar = create_progress_bar(len(unlocked_ids), len(ACHIEVEMENTS), 15, "▓", "░")
    
    description = (
        f"```ansi\n"
        f"\u001b[1;33m╔═══════════════════════════════════╗\u001b[0m\n"
        f"\u001b[1;35m      🏆 ACHIEVEMENTS 🏆           \u001b[0m\n"
        f"\u001b[1;33m╚═══════════════════════════════════╝\u001b[0m\n"
        f"```\n"
        f"**Progress:** `[{progress_bar}]` {len(unlocked_ids)}/{len(ACHIEVEMENTS)} ({progress:.0f}%)\n\n"
        f"**━━━ ✅ Unlocked ━━━**\n"
        f"{unlocked_display if unlocked_display else '*None yet! Keep playing!*'}\n"
        f"**━━━ 🔒 Locked ━━━**\n"
        f"{locked_display if locked_display else '*All achievements unlocked!*'}"
    )
    
    embed = discord.Embed(
        title="✧ Your Achievements ✧",
        description=description[:4000],
        color=THEME_COLORS["gold"]
    )
    embed.set_footer(text="🚽 Toilet Tower Defense 🚽")
    embed.timestamp = discord.utils.utcnow()
    
    try:
        await interaction.response.edit_message(embed=embed, view=MainMenuView(interaction.user.id))
    except:
        await interaction.response.send_message(embed=embed, view=MainMenuView(interaction.user.id))

async def show_fusion_menu(interaction: discord.Interaction):
    player = await get_player(interaction.user.id)
    if not player:
        await interaction.response.send_message("Use `/start` first!", ephemeral=True)
        return
    
    inventory = await get_inventory(interaction.user.id)
    equipped_ids = [u['id'] for u in await get_equipped_units(interaction.user.id)]
    available_units = [u for u in inventory if u['id'] not in equipped_ids]
    
    rarity_counts = {}
    for unit in available_units:
        rarity = unit['rarity']
        if rarity not in ['Celestial', 'Exclusive']:
            rarity_counts[rarity] = rarity_counts.get(rarity, 0) + 1
    
    fuseable_display = ""
    for rarity, count in rarity_counts.items():
        can_fuse = "✅" if count >= 3 else "❌"
        fuseable_display += f"{RARITY_EMOJIS.get(rarity, '⚪')} **{rarity}:** {count} units {can_fuse}\n"
    
    rarity_upgrade = {
        "Basic": "Uncommon", "Uncommon": "Rare", "Rare": "Epic",
        "Epic": "Legendary", "Legendary": "Mythic", "Mythic": "Godly", "Godly": "Celestial"
    }
    
    upgrade_display = ""
    for old, new in rarity_upgrade.items():
        upgrade_display += f"{RARITY_EMOJIS.get(old, '⚪')} → {RARITY_EMOJIS.get(new, '⚪')}\n"
    
    description = (
        f"```ansi\n"
        f"\u001b[1;35m╔═══════════════════════════════════╗\u001b[0m\n"
        f"\u001b[1;33m      ⚗️ UNIT FUSION LAB ⚗️         \u001b[0m\n"
        f"\u001b[1;35m╚═══════════════════════════════════╝\u001b[0m\n"
        f"```\n"
        f"**How Fusion Works:**\n"
        f"• Combine **3 units** of the same rarity\n"
        f"• Creates **1 unit** of the next rarity tier\n"
        f"• Stats are combined (50% of total)\n"
        f"• Cannot fuse equipped units\n\n"
        f"**━━━ 📊 Your Units ━━━**\n"
        f"{fuseable_display if fuseable_display else '*No units available for fusion*'}\n"
        f"**━━━ ⬆️ Upgrade Path ━━━**\n"
        f"{upgrade_display}\n"
        f"*Use `/fuse <id1> <id2> <id3>` to fuse units*"
    )
    
    embed = discord.Embed(
        title="✧ Unit Fusion ✧",
        description=description,
        color=THEME_COLORS["mythic"]
    )
    embed.set_footer(text="🚽 Toilet Tower Defense 🚽")
    embed.timestamp = discord.utils.utcnow()
    
    try:
        await interaction.response.edit_message(embed=embed, view=MainMenuView(interaction.user.id))
    except:
        await interaction.response.send_message(embed=embed, view=MainMenuView(interaction.user.id))

async def show_help(interaction: discord.Interaction):
    is_user_admin = is_admin(interaction.user.id)
    
    admin_section = ""
    if is_user_admin:
        admin_section = (
            "\n\n**🔧 Admin Commands:**\n"
            "`/admin give_coins <user> <amount>` - Give coins\n"
            "`/admin give_gems <user> <amount>` - Give gems\n"
            "`/admin give_unit <user> <unit_id>` - Give a unit\n"
            "`/admin reset_player <user>` - Reset player data\n"
            "`/admin set_level <user> <level>` - Set player level\n"
        )
    
    embed = create_embed(
        "📖 TTD Help",
        "**Main Features:**\n"
        "🎰 **Summon** - Pull for new units\n"
        "⚔️ **Battle** - Fight waves of toilets\n"
        "🎒 **Loadout** - Equip units for battle\n"
        "📦 **Inventory** - View all your units\n"
        "⬆️ **Upgrade** - Level up units with duplicates\n"
        "⚗️ **Fusion** - Combine 3 units for higher rarity\n"
        "🏆 **Achievements** - Track progress (35+ achievements!)\n"
        "🎁 **Daily** - Claim daily rewards\n"
        "🏪 **Shop** - Buy coins and gems\n"
        "📊 **Leaderboard** - View top players\n\n"
        "**Battle System:**\n"
        "• Equip units to your loadout (max 10)\n"
        "• Set unit placement (Front/Middle/Back)\n"
        "• Choose difficulty and start auto-battle\n"
        "• Every 10th wave is a BOSS wave!\n"
        "• Higher difficulty = more rewards\n\n"
        "**Text Commands (ttd prefix):**\n"
        "`ttd start` - Begin your journey\n"
        "`ttd menu` - Open main menu\n"
        "`ttd profile [@user]` - View profile\n"
        "`ttd summon` - Open summon menu\n"
        "`ttd battle` - Start a battle\n"
        "`ttd loadout` - Manage your team\n"
        "`ttd inventory` - View your units\n"
        "`ttd daily` - Claim daily rewards\n"
        "`ttd shop` - Visit the shop\n"
        "`ttd leaderboard` - View rankings\n"
        "`ttd achievements` - View achievements\n"
        "`ttd fusion` - Fuse units\n"
        "`ttd rates` - View summon rates\n\n"
        "*All commands also work as slash commands!*"
        f"{admin_section}",
        0x00BFFF
    )
    
    try:
        await interaction.response.edit_message(embed=embed, view=MainMenuView(interaction.user.id))
    except:
        await interaction.response.send_message(embed=embed, view=MainMenuView(interaction.user.id))

@bot.event
async def on_ready():
    await init_db()
    print(f'{bot.user} is online!')
    try:
        synced = await bot.tree.sync()
        print(f'Synced {len(synced)} commands')
    except Exception as e:
        print(f'Error syncing commands: {e}')

@bot.event
async def on_message(message: discord.Message):
    if message.author.bot:
        return
    
    content = message.content.strip()
    
    prefix_pattern = re.compile(r'^ttd\s+', re.IGNORECASE)
    if not prefix_pattern.match(content):
        return
    
    command_text = prefix_pattern.sub('', content).lower().split()
    if not command_text:
        return
    
    command = command_text[0]
    args = command_text[1:]
    
    if command == "start":
        await handle_start(message)
    elif command == "menu":
        await handle_menu(message)
    elif command == "profile":
        await handle_profile(message, args)
    elif command == "summon":
        await handle_summon(message)
    elif command == "battle":
        await handle_battle(message)
    elif command == "inventory":
        await handle_inventory(message)
    elif command == "loadout":
        await handle_loadout(message)
    elif command == "daily":
        await handle_daily(message)
    elif command == "shop":
        await handle_shop(message)
    elif command == "leaderboard":
        await handle_leaderboard(message)
    elif command == "help":
        await handle_help(message)
    elif command == "rates":
        await handle_rates(message)
    elif command == "achievements":
        await handle_achievements(message)
    elif command == "fusion" or command == "fuse":
        await handle_fusion(message)

async def handle_start(message: discord.Message):
    user_id = message.author.id
    username = message.author.display_name
    
    player = await get_player(user_id)
    if player:
        embed = create_embed(
            "Already Registered!",
            f"You're already a defender, **{username}**!",
            0xFFD700
        )
        await message.channel.send(embed=embed, view=MainMenuView(user_id))
        return
    
    await create_player(user_id, username)
    starter_unit = random.choice([u for u in UNITS if u['rarity'] == 'Basic'])
    await add_unit_to_inventory(user_id, starter_unit)
    await equip_unit(user_id, 1, 0)
    
    embed = create_embed(
        "🚽 Welcome to Toilet Tower Defense! 🚽",
        f"**Welcome, {username}!**\n\n"
        f"**Starting Rewards:**\n"
        f"💰 500 Coins | 💎 50 Gems\n"
        f"📦 Starter: {starter_unit['emoji']} **{starter_unit['name']}**\n\n"
        f"*Your starter unit has been auto-equipped!*",
        0x00FF00
    )
    await message.channel.send(embed=embed, view=MainMenuView(user_id))

async def handle_menu(message: discord.Message):
    player = await get_player(message.author.id)
    if not player:
        await message.channel.send("Use `ttd start` first!")
        return
    
    equipped_count = await get_loadout_count(message.author.id)
    
    embed = create_embed(
        f"🚽 Toilet Tower Defense 🚽",
        f"Welcome back, **{message.author.display_name}**!\n\n"
        f"**Your Stats:**\n"
        f"💰 Coins: {player['coins']:,}\n"
        f"💎 Gems: {player['gems']}\n"
        f"⭐ Level: {player['level']}\n"
        f"🏆 Wins: {player['wins']}\n"
        f"🎒 Loadout: {equipped_count}/10 units\n\n"
        f"Select an option below!",
        0x00BFFF
    )
    embed.set_thumbnail(url=message.author.display_avatar.url)
    await message.channel.send(embed=embed, view=MainMenuView(message.author.id))

async def handle_profile(message: discord.Message, args: list):
    target = message.author
    if message.mentions:
        target = message.mentions[0]
    
    player = await get_player(target.id)
    if not player:
        await message.channel.send(f"{'This player' if target != message.author else 'You'} haven't started yet!")
        return
    
    inventory = await get_inventory(target.id)
    unit_count = len(inventory)
    equipped_units = await get_equipped_units(target.id)
    
    rarity_counts = {}
    for unit in inventory:
        rarity = unit['rarity']
        rarity_counts[rarity] = rarity_counts.get(rarity, 0) + 1
    
    rarity_display = "\n".join(
        f"{RARITY_EMOJIS.get(r, '⚪')} {r}: {c}" 
        for r, c in sorted(rarity_counts.items(), key=lambda x: list(RARITY_EMOJIS.keys()).index(x[0]) if x[0] in RARITY_EMOJIS else 0)
    ) or "No units yet!"
    
    win_rate = (player['wins'] / (player['wins'] + player['losses']) * 100) if (player['wins'] + player['losses']) > 0 else 0
    loadout_power = calculate_battle_power([dict(u) for u in equipped_units]) if equipped_units else 0
    
    embed = create_embed(
        f"{target.display_name}'s Profile",
        f"**Level {player['level']}** | XP: {player['experience']}\n\n"
        f"**Currency:**\n"
        f"💰 Coins: {player['coins']:,}\n"
        f"💎 Gems: {player['gems']:,}\n\n"
        f"**Battle Stats:**\n"
        f"🏆 Wins: {player['wins']}\n"
        f"💀 Losses: {player['losses']}\n"
        f"📊 Win Rate: {win_rate:.1f}%\n"
        f"🌊 Highest Wave: {player['highest_wave']}\n"
        f"💪 Loadout Power: {loadout_power}\n\n"
        f"**Collection ({unit_count} units):**\n{rarity_display}",
        0x00BFFF
    )
    embed.set_thumbnail(url=target.display_avatar.url)
    await message.channel.send(embed=embed, view=MainMenuView(message.author.id))

async def handle_summon(message: discord.Message):
    player = await get_player(message.author.id)
    if not player:
        await message.channel.send("Use `ttd start` first!")
        return
    
    embed = create_embed(
        "🎰 Summon Menu",
        f"**Your Balance:**\n"
        f"💰 {player['coins']:,} Coins | 💎 {player['gems']} Gems\n\n"
        f"**Available Summons:**\n\n"
        f"📦 **Standard Crate** - 100 Coins\n"
        f"🎁 **10x Standard** - 900 Coins\n"
        f"💎 **Premium Crate** - 50 Gems\n"
        f"🔮 **Mythic Crate** - 150 Gems",
        0xFFD700
    )
    await message.channel.send(embed=embed, view=SummonMenuView(message.author.id))

async def handle_battle(message: discord.Message):
    player = await get_player(message.author.id)
    if not player:
        await message.channel.send("Use `ttd start` first!")
        return
    
    if message.author.id in active_auto_battles:
        await message.channel.send("You already have an active battle!")
        return
    
    equipped = await get_equipped_units(message.author.id)
    
    if not equipped:
        inventory = await get_inventory(message.author.id)
        if not inventory:
            await message.channel.send("You need units to battle! Use `ttd summon` first.")
            return
        
        embed = create_embed(
            "⚔️ No Units Equipped!",
            "You need to equip units to your loadout before battling!\n\n"
            "Use `ttd loadout` to manage your team.",
            0xFF6600
        )
        await message.channel.send(embed=embed, view=BattleMenuView(message.author.id))
        return
    
    battle_power = calculate_battle_power([dict(u) for u in equipped])
    
    diff_text = ""
    for diff_id, diff in DIFFICULTIES.items():
        diff_text += f"{diff['emoji']} **{diff['name']}** - Max Wave: {diff['max_wave']}\n"
    
    embed = create_embed(
        "⚔️ Battle Arena",
        f"**Your Stats:**\n"
        f"📦 Equipped Units: {len(equipped)}\n"
        f"💪 Battle Power: {battle_power}\n\n"
        f"**Select Difficulty:**\n{diff_text}",
        0xFF4500
    )
    await message.channel.send(embed=embed, view=BattleMenuView(message.author.id))

async def handle_inventory(message: discord.Message):
    player = await get_player(message.author.id)
    if not player:
        await message.channel.send("Use `ttd start` first!")
        return
    
    units = await get_inventory(message.author.id)
    
    if not units:
        embed = create_embed("📦 Your Inventory", "You don't have any units yet!", 0x808080)
        await message.channel.send(embed=embed, view=MainMenuView(message.author.id))
        return
    
    per_page = 8
    total_pages = (len(units) + per_page - 1) // per_page
    page_units = units[:per_page]
    
    units_display = ""
    for u in page_units:
        equipped_slot = await is_unit_equipped(message.author.id, u['id'])
        equipped_text = f" [🎒 Slot {equipped_slot + 1}]" if equipped_slot is not None else ""
        units_display += (
            f"`#{u['id']}` {RARITY_EMOJIS.get(u['rarity'], '⚪')} {get_unit_emoji(u['unit_id'])} **{u['unit_name']}** "
            f"(Lv.{u['level']}) ATK:{u['attack']} DEF:{u['defense']}{equipped_text}\n"
        )
    
    embed = create_embed(
        f"📦 Your Inventory ({len(units)} units)",
        f"{units_display}\n\nPage 1/{total_pages}",
        0x00BFFF
    )
    await message.channel.send(embed=embed, view=InventoryView(message.author.id, 1, total_pages))

async def handle_loadout(message: discord.Message):
    player = await get_player(message.author.id)
    if not player:
        await message.channel.send("Use `ttd start` first!")
        return
    
    equipped = await get_equipped_units(message.author.id)
    
    if not equipped:
        embed = create_embed(
            "🎒 Your Loadout",
            "**No units equipped!**\n\n"
            "Equip units to use them in battle.\n"
            "You can equip up to **10 units** in your loadout.\n\n"
            "*Tip: Use 'Auto-Equip Best' to quickly set up your strongest team!*",
            0xFF6600
        )
    else:
        loadout_display = ""
        for unit in equipped:
            placement_emoji = PLACEMENT_EMOJIS.get(unit['placement'], "⚔️")
            loadout_display += (
                f"**Slot {unit['slot']+1}** {placement_emoji} "
                f"{RARITY_EMOJIS.get(unit['rarity'], '⚪')} "
                f"{get_unit_emoji(unit['unit_id'])} **{unit['unit_name']}** "
                f"(Lv.{unit['level']})\n"
            )
        
        total_power = calculate_battle_power([dict(u) for u in equipped])
        
        embed = create_embed(
            f"🎒 Your Loadout ({len(equipped)}/10)",
            f"**Battle Power: {total_power}** 💪\n\n"
            f"**Equipped Units:**\n{loadout_display}",
            0x00BFFF
        )
    
    await message.channel.send(embed=embed, view=LoadoutView(message.author.id))

async def handle_daily(message: discord.Message):
    player = await get_player(message.author.id)
    if not player:
        await message.channel.send("Use `ttd start` first!")
        return
    
    now = datetime.utcnow()
    last_daily = player['last_daily']
    
    if last_daily:
        last_claim = datetime.fromisoformat(last_daily)
        if (now - last_claim).total_seconds() < 86400:
            time_left = timedelta(days=1) - (now - last_claim)
            hours, remainder = divmod(int(time_left.total_seconds()), 3600)
            minutes = remainder // 60
            await message.channel.send(f"⏰ Come back in **{hours}h {minutes}m**!")
            return
    
    coins_reward = random.randint(150, 400)
    gems_reward = random.randint(8, 20)
    
    await update_player(
        message.author.id,
        coins=player['coins'] + coins_reward,
        gems=player['gems'] + gems_reward,
        last_daily=now.isoformat()
    )
    
    embed = create_embed(
        "🎁 Daily Rewards Claimed!",
        f"**You received:**\n"
        f"💰 {coins_reward} Coins\n"
        f"💎 {gems_reward} Gems",
        0xFFD700
    )
    await message.channel.send(embed=embed)

async def handle_shop(message: discord.Message):
    player = await get_player(message.author.id)
    if not player:
        await message.channel.send("Use `ttd start` first!")
        return
    
    embed = create_embed(
        "🏪 Shop",
        f"**Your Balance:**\n"
        f"💰 {player['coins']:,} Coins | 💎 {player['gems']} Gems",
        0x00BFFF
    )
    await message.channel.send(embed=embed, view=ShopView(message.author.id))

async def handle_leaderboard(message: discord.Message):
    players = await get_leaderboard("wins", 10)
    
    if not players:
        embed = create_embed("🏆 Leaderboard", "No players found!", 0xFFD700)
    else:
        medals = ["🥇", "🥈", "🥉"]
        leaderboard_display = ""
        
        for i, player in enumerate(players):
            medal = medals[i] if i < 3 else f"`{i+1}.`"
            leaderboard_display += f"{medal} **{player['username']}** - {player['wins']} wins\n"
        
        embed = create_embed("🏆 Top Players", leaderboard_display, 0xFFD700)
    
    await message.channel.send(embed=embed)

async def handle_help(message: discord.Message):
    is_user_admin = is_admin(message.author.id)
    
    admin_section = ""
    if is_user_admin:
        admin_section = (
            "\n\n**🔧 Admin Commands (slash only):**\n"
            "`/admin give_coins`, `/admin give_gems`\n"
            "`/admin give_unit`, `/admin set_level`\n"
            "`/admin reset_player`, `/admin give_all_units`\n"
        )
    
    embed = create_embed(
        "📖 TTD Help",
        "**Text Commands (ttd prefix):**\n"
        "`ttd start` - Begin your journey\n"
        "`ttd menu` - Open main menu\n"
        "`ttd profile [@user]` - View profile\n"
        "`ttd summon` - Open summon menu\n"
        "`ttd battle` - Start a battle\n"
        "`ttd loadout` - Manage your team\n"
        "`ttd inventory` - View your units\n"
        "`ttd daily` - Claim daily rewards\n"
        "`ttd shop` - Visit the shop\n"
        "`ttd leaderboard` - View rankings\n"
        "`ttd achievements` - View achievements\n"
        "`ttd fusion` - Fuse units\n"
        "`ttd rates` - View summon rates\n\n"
        "*All commands also work as slash commands!*"
        f"{admin_section}",
        0x00BFFF
    )
    await message.channel.send(embed=embed, view=MainMenuView(message.author.id))

async def handle_rates(message: discord.Message):
    rates_text = ""
    for crate_name, crate in CRATES.items():
        rates_text += f"\n**{crate['emoji']} {crate['name']}**\n"
        for rarity, rate in crate['rates'].items():
            rates_text += f"{RARITY_EMOJIS.get(rarity, '⚪')} {rarity}: {rate}%\n"
    
    embed = create_embed("📊 Summon Rates", rates_text, 0xFFD700)
    await message.channel.send(embed=embed)

async def handle_achievements(message: discord.Message):
    player = await get_player(message.author.id)
    if not player:
        await message.channel.send("Use `ttd start` first!")
        return
    
    unlocked = await get_achievements(message.author.id)
    unlocked_ids = [a['achievement_id'] for a in unlocked]
    
    achievements_text = ""
    for ach_id, ach in ACHIEVEMENTS.items():
        if ach_id in unlocked_ids:
            achievements_text += f"✅ {ach['emoji']} **{ach['name']}**\n   └ *{ach['description']}*\n"
        else:
            achievements_text += f"🔒 {ach['emoji']} **{ach['name']}**\n   └ *{ach['description']}*\n"
    
    embed = create_embed(
        "🏆 Achievements",
        f"**Unlocked: {len(unlocked)}/{len(ACHIEVEMENTS)}**\n\n{achievements_text}",
        0xFFD700
    )
    await message.channel.send(embed=embed, view=MainMenuView(message.author.id))

async def handle_fusion(message: discord.Message):
    player = await get_player(message.author.id)
    if not player:
        await message.channel.send("Use `ttd start` first!")
        return
    
    inventory = await get_inventory(message.author.id)
    
    rarity_counts = {}
    for unit in inventory:
        equipped = await is_unit_equipped(message.author.id, unit['id'])
        if equipped is None:
            rarity = unit['rarity']
            rarity_counts[rarity] = rarity_counts.get(rarity, 0) + 1
    
    fuseable = [(r, c) for r, c in rarity_counts.items() if c >= 3 and r not in ['Celestial', 'Exclusive']]
    
    if not fuseable:
        embed = create_embed(
            "⚗️ Unit Fusion",
            "You need at least **3 unequipped units** of the same rarity to fuse!\n\n"
            "*Fusion combines 3 units into 1 unit of the next rarity tier!*",
            0xFF6600
        )
    else:
        fuseable_text = "\n".join(
            f"{RARITY_EMOJIS.get(r, '⚪')} **{r}**: {c} units (can fuse {c // 3}x)"
            for r, c in fuseable
        )
        embed = create_embed(
            "⚗️ Unit Fusion",
            f"**Available for Fusion:**\n{fuseable_text}\n\n"
            f"*Use the buttons below to fuse units!*\n"
            f"*3 units of same rarity → 1 unit of higher rarity*",
            0xE040FB
        )
    
    await message.channel.send(embed=embed, view=FusionMenuView(message.author.id))

@bot.tree.command(name="start", description="Start your Toilet Tower Defense journey!")
async def slash_start(interaction: discord.Interaction):
    user_id = interaction.user.id
    username = interaction.user.display_name
    
    player = await get_player(user_id)
    if player:
        embed = create_embed(
            "Already Registered!",
            f"You're already a defender, **{username}**!",
            0xFFD700
        )
        await interaction.response.send_message(embed=embed, view=MainMenuView(user_id))
        return
    
    await create_player(user_id, username)
    starter_unit = random.choice([u for u in UNITS if u['rarity'] == 'Basic'])
    inventory_id = await add_unit_to_inventory(user_id, starter_unit)
    if inventory_id:
        await equip_unit(user_id, inventory_id, 0)
    
    embed = create_embed(
        "🚽 Welcome to Toilet Tower Defense! 🚽",
        f"**Welcome, {username}!**\n\n"
        f"**Starting Rewards:**\n"
        f"💰 500 Coins | 💎 50 Gems\n"
        f"📦 Starter: {starter_unit['emoji']} **{starter_unit['name']}**\n\n"
        f"*Your starter unit has been auto-equipped!*",
        0x00FF00
    )
    await interaction.response.send_message(embed=embed, view=MainMenuView(user_id))

@bot.tree.command(name="menu", description="Open the main menu")
async def slash_menu(interaction: discord.Interaction):
    await show_main_menu(interaction)

@bot.tree.command(name="profile", description="View your profile")
async def slash_profile(interaction: discord.Interaction, member: Optional[discord.Member] = None):
    target = member or interaction.user
    await show_profile(interaction, target)

@bot.tree.command(name="summon", description="Open the summon menu")
async def slash_summon(interaction: discord.Interaction):
    await show_summon_menu(interaction)

@bot.tree.command(name="battle", description="Start a battle")
async def slash_battle(interaction: discord.Interaction):
    await show_battle_menu(interaction)

@bot.tree.command(name="inventory", description="View your inventory")
async def slash_inventory(interaction: discord.Interaction):
    await show_inventory(interaction, 1)

@bot.tree.command(name="loadout", description="Manage your battle loadout")
async def slash_loadout(interaction: discord.Interaction):
    await show_loadout(interaction)

@bot.tree.command(name="daily", description="Claim daily rewards")
async def slash_daily(interaction: discord.Interaction):
    await claim_daily(interaction)

@bot.tree.command(name="shop", description="Visit the shop")
async def slash_shop(interaction: discord.Interaction):
    await show_shop(interaction)

@bot.tree.command(name="leaderboard", description="View the leaderboard")
async def slash_leaderboard(interaction: discord.Interaction):
    await show_leaderboard(interaction)

@bot.tree.command(name="help", description="Get help")
async def slash_help(interaction: discord.Interaction):
    await show_help(interaction)

@bot.tree.command(name="trade", description="Trade a unit with another player")
async def slash_trade(interaction: discord.Interaction, member: discord.Member, unit_id: int):
    if member.id == interaction.user.id:
        await interaction.response.send_message("You can't trade with yourself!", ephemeral=True)
        return
    
    if member.bot:
        await interaction.response.send_message("You can't trade with bots!", ephemeral=True)
        return
    
    sender = await get_player(interaction.user.id)
    receiver = await get_player(member.id)
    
    if not sender:
        await interaction.response.send_message("Use `/start` first!", ephemeral=True)
        return
    
    if not receiver:
        await interaction.response.send_message(f"{member.display_name} hasn't started yet!", ephemeral=True)
        return
    
    unit = await get_unit_by_id(unit_id, interaction.user.id)
    if not unit:
        await interaction.response.send_message("Unit not found in your inventory!", ephemeral=True)
        return
    
    equipped_slot = await is_unit_equipped(interaction.user.id, unit_id)
    if equipped_slot is not None:
        await interaction.response.send_message("You can't trade an equipped unit! Unequip it first.", ephemeral=True)
        return
    
    embed = create_embed(
        "🔄 Trade Request!",
        f"**{interaction.user.display_name}** wants to trade:\n\n"
        f"{RARITY_EMOJIS.get(unit['rarity'], '⚪')} **{unit['unit_name']}** ({unit['rarity']})\n"
        f"ATK: {unit['attack']} | DEF: {unit['defense']}\n\n"
        f"{member.mention}, do you accept?",
        0xFFD700
    )
    
    await interaction.response.send_message(
        embed=embed, 
        view=TradeConfirmView(interaction.user.id, member.id, unit_id, unit['unit_name'])
    )

admin_group = app_commands.Group(name="admin", description="Admin commands (restricted)")

@admin_group.command(name="give_coins", description="Give coins to a player")
async def admin_give_coins(interaction: discord.Interaction, member: discord.Member, amount: int):
    if not is_admin(interaction.user.id):
        await interaction.response.send_message("You don't have permission to use this command!", ephemeral=True)
        return
    
    player = await get_player(member.id)
    if not player:
        await interaction.response.send_message(f"{member.display_name} hasn't started playing yet!", ephemeral=True)
        return
    
    await update_player(member.id, coins=player['coins'] + amount)
    embed = create_embed(
        "🔧 Admin Action",
        f"Gave **{amount:,} coins** to **{member.display_name}**\n"
        f"New balance: **{player['coins'] + amount:,} coins**",
        0x00FF00
    )
    await interaction.response.send_message(embed=embed)

@admin_group.command(name="give_gems", description="Give gems to a player")
async def admin_give_gems(interaction: discord.Interaction, member: discord.Member, amount: int):
    if not is_admin(interaction.user.id):
        await interaction.response.send_message("You don't have permission to use this command!", ephemeral=True)
        return
    
    player = await get_player(member.id)
    if not player:
        await interaction.response.send_message(f"{member.display_name} hasn't started playing yet!", ephemeral=True)
        return
    
    await update_player(member.id, gems=player['gems'] + amount)
    embed = create_embed(
        "🔧 Admin Action",
        f"Gave **{amount:,} gems** to **{member.display_name}**\n"
        f"New balance: **{player['gems'] + amount:,} gems**",
        0x00FF00
    )
    await interaction.response.send_message(embed=embed)

@admin_group.command(name="give_unit", description="Give a specific unit to a player")
async def admin_give_unit(interaction: discord.Interaction, member: discord.Member, unit_id: str):
    if not is_admin(interaction.user.id):
        await interaction.response.send_message("You don't have permission to use this command!", ephemeral=True)
        return
    
    player = await get_player(member.id)
    if not player:
        await interaction.response.send_message(f"{member.display_name} hasn't started playing yet!", ephemeral=True)
        return
    
    unit = next((u for u in UNITS if u['id'] == unit_id), None)
    if not unit:
        available_units = ", ".join(u['id'] for u in UNITS[:20])
        await interaction.response.send_message(
            f"Unit not found! Some available units: {available_units}...",
            ephemeral=True
        )
        return
    
    await add_unit_to_inventory(member.id, unit)
    embed = create_embed(
        "🔧 Admin Action",
        f"Gave **{unit['emoji']} {unit['name']}** ({unit['rarity']}) to **{member.display_name}**",
        RARITY_COLORS.get(unit['rarity'], 0x00FF00)
    )
    await interaction.response.send_message(embed=embed)

@admin_group.command(name="set_level", description="Set a player's level")
async def admin_set_level(interaction: discord.Interaction, member: discord.Member, level: int):
    if not is_admin(interaction.user.id):
        await interaction.response.send_message("You don't have permission to use this command!", ephemeral=True)
        return
    
    if level < 1 or level > 500:
        await interaction.response.send_message("Level must be between 1 and 500!", ephemeral=True)
        return
    
    player = await get_player(member.id)
    if not player:
        await interaction.response.send_message(f"{member.display_name} hasn't started playing yet!", ephemeral=True)
        return
    
    await update_player(member.id, level=level, experience=0)
    embed = create_embed(
        "🔧 Admin Action",
        f"Set **{member.display_name}**'s level to **{level}**",
        0x00FF00
    )
    await interaction.response.send_message(embed=embed)

@admin_group.command(name="reset_player", description="Reset a player's data (WARNING: Permanent!)")
async def admin_reset_player(interaction: discord.Interaction, member: discord.Member, confirm: str = ""):
    if not is_admin(interaction.user.id):
        await interaction.response.send_message("You don't have permission to use this command!", ephemeral=True)
        return
    
    if confirm.lower() != "confirm":
        await interaction.response.send_message(
            f"⚠️ This will reset ALL data for **{member.display_name}**!\n"
            f"To confirm, use: `/admin reset_player @{member.name} confirm:confirm`",
            ephemeral=True
        )
        return
    
    player = await get_player(member.id)
    if not player:
        await interaction.response.send_message(f"{member.display_name} hasn't started playing yet!", ephemeral=True)
        return
    
    await update_player(
        member.id,
        coins=500,
        gems=50,
        experience=0,
        level=1,
        wins=0,
        losses=0,
        highest_wave=0
    )
    await clear_loadout(member.id)
    
    embed = create_embed(
        "🔧 Admin Action",
        f"Reset **{member.display_name}**'s progress!\n"
        f"They now have:\n"
        f"💰 500 Coins | 💎 50 Gems | Level 1",
        0xFF6600
    )
    await interaction.response.send_message(embed=embed)

@admin_group.command(name="give_all_units", description="Give all units to a player")
async def admin_give_all(interaction: discord.Interaction, member: discord.Member):
    if not is_admin(interaction.user.id):
        await interaction.response.send_message("You don't have permission to use this command!", ephemeral=True)
        return
    
    player = await get_player(member.id)
    if not player:
        await interaction.response.send_message(f"{member.display_name} hasn't started playing yet!", ephemeral=True)
        return
    
    await interaction.response.defer()
    
    count = 0
    for unit in UNITS:
        await add_unit_to_inventory(member.id, unit)
        count += 1
    
    embed = create_embed(
        "🔧 Admin Action",
        f"Gave **{count}** units to **{member.display_name}**!",
        0x00FF00
    )
    await interaction.followup.send(embed=embed)

@admin_group.command(name="broadcast", description="Send a message to all channels the bot is in")
async def admin_broadcast(interaction: discord.Interaction, message: str):
    if not is_admin(interaction.user.id):
        await interaction.response.send_message("You don't have permission to use this command!", ephemeral=True)
        return
    
    embed = create_embed(
        "📢 TTD Announcement",
        message,
        0xFFD700
    )
    embed.set_footer(text=f"From the TTD Team")
    
    await interaction.response.send_message("Broadcasting message...", ephemeral=True)
    
    sent_count = 0
    for guild in bot.guilds:
        for channel in guild.text_channels:
            try:
                if channel.permissions_for(guild.me).send_messages:
                    await channel.send(embed=embed)
                    sent_count += 1
                    break
            except:
                continue
    
    await interaction.followup.send(f"Broadcast sent to {sent_count} servers!", ephemeral=True)

bot.tree.add_command(admin_group)

BOSS_RUSH_BOSSES = [
    {"id": "g_man_toilet", "name": "G-Man Toilet", "hp": 500, "damage": 60, "reward": 300, "emoji": "👔"},
    {"id": "titan_toilet", "name": "Titan Toilet", "hp": 1000, "damage": 100, "reward": 600, "emoji": "💀"},
    {"id": "upgraded_titan_toilet", "name": "Upgraded Titan Toilet", "hp": 2000, "damage": 150, "reward": 1200, "emoji": "☠️"},
    {"id": "astro_toilet", "name": "Astro Toilet", "hp": 3500, "damage": 200, "reward": 2000, "emoji": "🌌"},
    {"id": "glitch_toilet", "name": "Glitch Toilet", "hp": 5000, "damage": 250, "reward": 3000, "emoji": "👾"},
    {"id": "omega_toilet", "name": "Omega Toilet", "hp": 7500, "damage": 300, "reward": 4500, "emoji": "Ω"},
    {"id": "final_toilet", "name": "The Final Toilet", "hp": 10000, "damage": 400, "reward": 6000, "emoji": "🏆"},
]

WEEKLY_CHALLENGES = [
    {"id": "win_battles", "name": "Battle Master", "description": "Win 20 battles", "target": 20, "reward_coins": 2000, "reward_gems": 100},
    {"id": "defeat_enemies", "name": "Toilet Slayer", "description": "Defeat 500 enemies", "target": 500, "reward_coins": 1500, "reward_gems": 75},
    {"id": "reach_wave", "name": "Wave Rider", "description": "Reach wave 50 in any mode", "target": 50, "reward_coins": 1000, "reward_gems": 50},
    {"id": "summon_units", "name": "Lucky Summoner", "description": "Summon 30 units", "target": 30, "reward_coins": 1200, "reward_gems": 60},
    {"id": "boss_kills", "name": "Boss Hunter", "description": "Defeat 10 bosses", "target": 10, "reward_coins": 2500, "reward_gems": 150},
]

LUCKY_SPIN_REWARDS = [
    {"type": "coins", "amount": 100, "chance": 25, "emoji": "💰", "name": "100 Coins"},
    {"type": "coins", "amount": 500, "chance": 15, "emoji": "💰", "name": "500 Coins"},
    {"type": "coins", "amount": 1000, "chance": 5, "emoji": "💰", "name": "1000 Coins"},
    {"type": "gems", "amount": 10, "chance": 20, "emoji": "💎", "name": "10 Gems"},
    {"type": "gems", "amount": 25, "chance": 10, "emoji": "💎", "name": "25 Gems"},
    {"type": "gems", "amount": 50, "chance": 3, "emoji": "💎", "name": "50 Gems"},
    {"type": "xp", "amount": 200, "chance": 15, "emoji": "⭐", "name": "200 XP"},
    {"type": "crate", "amount": 1, "chance": 5, "emoji": "📦", "name": "Free Crate"},
    {"type": "premium_crate", "amount": 1, "chance": 2, "emoji": "🎁", "name": "Premium Crate"},
]

class BossRushView(discord.ui.View):
    def __init__(self, user_id: int):
        super().__init__(timeout=120)
        self.user_id = user_id
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("This menu is not for you!", ephemeral=True)
            return False
        return True
    
    @discord.ui.button(label="Start Boss Rush", style=discord.ButtonStyle.danger, emoji="💀", row=0)
    async def start_boss_rush(self, interaction: discord.Interaction, button: discord.ui.Button):
        await start_boss_rush_battle(interaction)
    
    @discord.ui.button(label="Back to Menu", style=discord.ButtonStyle.secondary, emoji="◀️", row=0)
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_main_menu(interaction)

class WeeklyChallengeView(discord.ui.View):
    def __init__(self, user_id: int):
        super().__init__(timeout=120)
        self.user_id = user_id
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("This menu is not for you!", ephemeral=True)
            return False
        return True
    
    @discord.ui.button(label="Refresh", style=discord.ButtonStyle.primary, emoji="🔄", row=0)
    async def refresh_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_weekly_challenges(interaction)
    
    @discord.ui.button(label="Back to Menu", style=discord.ButtonStyle.secondary, emoji="◀️", row=0)
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_main_menu(interaction)

class LuckySpinView(discord.ui.View):
    def __init__(self, user_id: int):
        super().__init__(timeout=120)
        self.user_id = user_id
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("This menu is not for you!", ephemeral=True)
            return False
        return True
    
    @discord.ui.button(label="Spin (50 Gems)", style=discord.ButtonStyle.success, emoji="🎰", row=0)
    async def spin_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await do_lucky_spin(interaction)
    
    @discord.ui.button(label="Back to Menu", style=discord.ButtonStyle.secondary, emoji="◀️", row=0)
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_main_menu(interaction)

async def show_boss_rush(interaction: discord.Interaction):
    player = await get_player(interaction.user.id)
    if not player:
        await interaction.response.send_message("Use `/start` first!", ephemeral=True)
        return
    
    if player['level'] < 10:
        embed = create_embed(
            "🔒 Boss Rush Locked",
            "You need to be **Level 10** to unlock Boss Rush mode!\n\n"
            f"Your current level: **{player['level']}**",
            0xFF6600
        )
        try:
            await interaction.response.edit_message(embed=embed, view=MainMenuView(interaction.user.id))
        except:
            await interaction.response.send_message(embed=embed, view=MainMenuView(interaction.user.id))
        return
    
    equipped = await get_equipped_units(interaction.user.id)
    
    boss_list = ""
    for i, boss in enumerate(BOSS_RUSH_BOSSES, 1):
        boss_list += f"**Wave {i}:** {boss['emoji']} {boss['name']}\n   HP: `{boss['hp']:,}` | DMG: `{boss['damage']}` | Reward: 💰`{boss['reward']}`\n"
    
    description = (
        f"```ansi\n"
        f"\u001b[1;31m╔═══════════════════════════════════╗\u001b[0m\n"
        f"\u001b[1;33m      💀 BOSS RUSH MODE 💀         \u001b[0m\n"
        f"\u001b[1;31m╚═══════════════════════════════════╝\u001b[0m\n"
        f"```\n"
        f"**Fight consecutive bosses for massive rewards!**\n\n"
        f"**━━━ 👹 Boss Lineup ━━━**\n"
        f"{boss_list}\n"
        f"**━━━ 📊 Your Loadout ━━━**\n"
        f"📦 Equipped Units: `{len(equipped)}/10`\n\n"
        f"⚠️ *One shot at each boss - no retreating!*"
    )
    
    embed = discord.Embed(
        title="✧ Boss Rush Mode ✧",
        description=description,
        color=THEME_COLORS["danger"]
    )
    embed.set_footer(text="🚽 Toilet Tower Defense 🚽")
    embed.timestamp = discord.utils.utcnow()
    
    try:
        await interaction.response.edit_message(embed=embed, view=BossRushView(interaction.user.id))
    except:
        await interaction.response.send_message(embed=embed, view=BossRushView(interaction.user.id))

async def start_boss_rush_battle(interaction: discord.Interaction):
    try:
        if not interaction.response.is_done():
            await interaction.response.defer()
    except:
        pass
    
    try:
        player = await get_player(interaction.user.id)
        if not player or player['level'] < 10:
            await interaction.followup.send("You need to be Level 10 for Boss Rush!", ephemeral=True)
            return
        
        if interaction.user.id in active_auto_battles:
            await interaction.followup.send("You already have an active battle!", ephemeral=True)
            return
        
        equipped = await get_equipped_units(interaction.user.id)
        if not equipped:
            await interaction.followup.send("You need to equip units first!", ephemeral=True)
            return
        
        battle_units = [dict(u) for u in equipped]
        
        for unit in battle_units:
            if unit.get('placement') == 'front':
                unit['attack'] = int(unit['attack'] * 1.15)
            elif unit.get('placement') == 'back':
                unit['defense'] = int(unit['defense'] * 1.15)
        
        embed = create_embed(
            "💀 Boss Rush Starting!",
            "Prepare yourself for the ultimate challenge!\n\n"
            "⏳ *Battle begins in 3 seconds...*",
            THEME_COLORS["danger"]
        )
        
        try:
            message = await interaction.followup.send(embed=embed, wait=True)
        except:
            message = await interaction.channel.send(embed=embed)
        
        asyncio.create_task(run_boss_rush(interaction.user.id, message, battle_units))
        
    except Exception as e:
        print(f"Boss Rush error: {e}")
        try:
            await interaction.followup.send("An error occurred. Please try again.", ephemeral=True)
        except:
            pass

async def run_boss_rush(user_id: int, message: discord.Message, player_units: list):
    await asyncio.sleep(3)
    
    total_coins = 0
    total_damage = 0
    bosses_defeated = 0
    
    for wave, boss in enumerate(BOSS_RUSH_BOSSES, 1):
        boss_hp = boss['hp']
        player_hp = 100
        
        total_attack = sum(u.get('attack', 0) for u in player_units)
        total_defense = sum(u.get('defense', 0) for u in player_units)
        
        rounds = 0
        while boss_hp > 0 and player_hp > 0 and rounds < 20:
            damage_to_boss = int(total_attack * random.uniform(0.8, 1.2))
            boss_hp = max(0, boss_hp - damage_to_boss)
            total_damage += damage_to_boss
            
            if boss_hp > 0:
                damage_to_player = max(1, int((boss['damage'] * random.uniform(0.7, 1.0)) - (total_defense * 0.05)))
                player_hp = max(0, player_hp - damage_to_player)
            
            rounds += 1
        
        won = boss_hp <= 0
        
        unit_display = " ".join(get_unit_display_icon(u['unit_id']) for u in player_units[:6])
        hp_bar = create_hp_bar(max(0, player_hp), 100)
        
        description = (
            f"```ansi\n"
            f"\u001b[1;{'32' if won else '31'}m══════ BOSS WAVE {wave}/7 ══════\u001b[0m\n"
            f"```\n"
            f"**━━━ 👹 {boss['emoji']} {boss['name']} ━━━**\n"
            f"{'✅ DEFEATED!' if won else '❌ SURVIVED!'}\n\n"
            f"**━━━ ⚔️ Battle Stats ━━━**\n"
            f"🛡️ **Your Team:** {unit_display}\n"
            f"❤️ **Your HP:** {hp_bar}\n"
            f"💥 **Damage Dealt:** `{total_damage:,}`\n"
            f"💰 **Coins Earned:** `{total_coins:,}`"
        )
        
        embed = discord.Embed(
            title=f"💀 Boss Rush - Wave {wave}",
            description=description,
            color=THEME_COLORS["success"] if won else THEME_COLORS["danger"]
        )
        embed.set_footer(text="🚽 Toilet Tower Defense 🚽")
        
        try:
            await message.edit(embed=embed)
        except:
            pass
        
        if not won:
            break
        
        bosses_defeated += 1
        total_coins += boss['reward']
        await asyncio.sleep(2)
    
    player = await get_player(user_id)
    if player:
        xp_earned = bosses_defeated * 100 + total_damage // 100
        await update_player(
            user_id,
            coins=player['coins'] + total_coins,
            experience=player['experience'] + xp_earned,
            wins=player['wins'] + (1 if bosses_defeated == 7 else 0)
        )
    
    final_embed = create_embed(
        "💀 Boss Rush Complete!",
        f"**Results:**\n"
        f"👹 Bosses Defeated: `{bosses_defeated}/7`\n"
        f"💥 Total Damage: `{total_damage:,}`\n\n"
        f"**Rewards:**\n"
        f"💰 Coins: `+{total_coins:,}`\n"
        f"⭐ XP: `+{xp_earned}`\n\n"
        f"{'🏆 **PERFECT CLEAR!**' if bosses_defeated == 7 else ''}",
        THEME_COLORS["gold"] if bosses_defeated == 7 else THEME_COLORS["warning"]
    )
    
    try:
        await message.edit(embed=final_embed)
    except:
        pass

async def show_weekly_challenges(interaction: discord.Interaction):
    player = await get_player(interaction.user.id)
    if not player:
        await interaction.response.send_message("Use `/start` first!", ephemeral=True)
        return
    
    challenges_display = ""
    for i, challenge in enumerate(WEEKLY_CHALLENGES, 1):
        progress = random.randint(0, challenge['target'])
        progress_bar = create_progress_bar(progress, challenge['target'], 10, "▓", "░")
        status = "✅" if progress >= challenge['target'] else "🔄"
        challenges_display += (
            f"**{i}. {challenge['name']}** {status}\n"
            f"   {challenge['description']}\n"
            f"   Progress: `[{progress_bar}]` {progress}/{challenge['target']}\n"
            f"   Rewards: 💰{challenge['reward_coins']} 💎{challenge['reward_gems']}\n\n"
        )
    
    description = (
        f"```ansi\n"
        f"\u001b[1;35m╔═══════════════════════════════════╗\u001b[0m\n"
        f"\u001b[1;33m     📅 WEEKLY CHALLENGES 📅       \u001b[0m\n"
        f"\u001b[1;35m╚═══════════════════════════════════╝\u001b[0m\n"
        f"```\n"
        f"**Complete challenges for bonus rewards!**\n"
        f"⏰ *Resets every Monday at 00:00 UTC*\n\n"
        f"**━━━ 🎯 Active Challenges ━━━**\n\n"
        f"{challenges_display}"
    )
    
    embed = discord.Embed(
        title="✧ Weekly Challenges ✧",
        description=description,
        color=THEME_COLORS["premium"]
    )
    embed.set_footer(text="🚽 Toilet Tower Defense 🚽")
    embed.timestamp = discord.utils.utcnow()
    
    try:
        await interaction.response.edit_message(embed=embed, view=WeeklyChallengeView(interaction.user.id))
    except:
        await interaction.response.send_message(embed=embed, view=WeeklyChallengeView(interaction.user.id))

async def show_lucky_spin(interaction: discord.Interaction):
    player = await get_player(interaction.user.id)
    if not player:
        await interaction.response.send_message("Use `/start` first!", ephemeral=True)
        return
    
    rewards_display = ""
    for reward in LUCKY_SPIN_REWARDS:
        rewards_display += f"{reward['emoji']} **{reward['name']}** - `{reward['chance']}%`\n"
    
    description = (
        f"```ansi\n"
        f"\u001b[1;33m╔═══════════════════════════════════╗\u001b[0m\n"
        f"\u001b[1;35m       🎰 LUCKY SPIN 🎰            \u001b[0m\n"
        f"\u001b[1;33m╚═══════════════════════════════════╝\u001b[0m\n"
        f"```\n"
        f"**Try your luck for amazing rewards!**\n\n"
        f"💎 **Your Gems:** `{player['gems']}`\n"
        f"💰 **Cost per Spin:** `50 Gems`\n\n"
        f"**━━━ 🎁 Possible Rewards ━━━**\n"
        f"{rewards_display}"
    )
    
    embed = discord.Embed(
        title="✧ Lucky Spin ✧",
        description=description,
        color=THEME_COLORS["summon"]
    )
    embed.set_footer(text="🚽 Toilet Tower Defense 🚽")
    embed.timestamp = discord.utils.utcnow()
    
    try:
        await interaction.response.edit_message(embed=embed, view=LuckySpinView(interaction.user.id))
    except:
        await interaction.response.send_message(embed=embed, view=LuckySpinView(interaction.user.id))

async def do_lucky_spin(interaction: discord.Interaction):
    player = await get_player(interaction.user.id)
    if not player:
        await interaction.response.send_message("Use `/start` first!", ephemeral=True)
        return
    
    if player['gems'] < 50:
        await interaction.response.send_message("You need 50 gems to spin!", ephemeral=True)
        return
    
    await update_player(interaction.user.id, gems=player['gems'] - 50)
    
    roll = random.randint(1, 100)
    cumulative = 0
    selected_reward = LUCKY_SPIN_REWARDS[0]
    
    for reward in LUCKY_SPIN_REWARDS:
        cumulative += reward['chance']
        if roll <= cumulative:
            selected_reward = reward
            break
    
    reward_text = ""
    if selected_reward['type'] == 'coins':
        await update_player(interaction.user.id, coins=player['coins'] + selected_reward['amount'])
        reward_text = f"💰 **+{selected_reward['amount']} Coins!**"
    elif selected_reward['type'] == 'gems':
        await update_player(interaction.user.id, gems=player['gems'] - 50 + selected_reward['amount'])
        reward_text = f"💎 **+{selected_reward['amount']} Gems!**"
    elif selected_reward['type'] == 'xp':
        await update_player(interaction.user.id, experience=player['experience'] + selected_reward['amount'])
        reward_text = f"⭐ **+{selected_reward['amount']} XP!**"
    elif selected_reward['type'] == 'crate':
        unit = roll_crate("standard")
        if unit:
            await add_unit_to_inventory(interaction.user.id, unit)
            reward_text = f"📦 **Free Crate!**\nYou got: {RARITY_EMOJIS.get(unit['rarity'], '⚪')} **{unit['name']}**"
    elif selected_reward['type'] == 'premium_crate':
        unit = roll_crate("premium")
        if unit:
            await add_unit_to_inventory(interaction.user.id, unit)
            reward_text = f"🎁 **Premium Crate!**\nYou got: {RARITY_EMOJIS.get(unit['rarity'], '⚪')} **{unit['name']}**"
    
    embed = create_embed(
        "🎰 Lucky Spin Result!",
        f"```\n"
        f"   🎡 SPINNING... 🎡\n"
        f"```\n\n"
        f"**You Won:**\n"
        f"{selected_reward['emoji']} {reward_text}\n\n"
        f"💎 Remaining Gems: `{player['gems'] - 50 + (selected_reward['amount'] if selected_reward['type'] == 'gems' else 0)}`",
        THEME_COLORS["gold"]
    )
    
    try:
        await interaction.response.edit_message(embed=embed, view=LuckySpinView(interaction.user.id))
    except:
        await interaction.response.send_message(embed=embed, view=LuckySpinView(interaction.user.id))

@bot.tree.command(name="bossrush", description="Challenge consecutive bosses for massive rewards!")
async def bossrush_command(interaction: discord.Interaction):
    await show_boss_rush(interaction)

@bot.tree.command(name="challenges", description="View and complete weekly challenges")
async def challenges_command(interaction: discord.Interaction):
    await show_weekly_challenges(interaction)

@bot.tree.command(name="spin", description="Try your luck at the Lucky Spin!")
async def spin_command(interaction: discord.Interaction):
    await show_lucky_spin(interaction)

if __name__ == "__main__":
    token = os.getenv("DISCORD_BOT_TOKEN")
    if not token:
        print("Error: DISCORD_BOT_TOKEN not found!")
        print("Please add your Discord bot token as a secret.")
    else:
        start_keepalive()
bot.run(token)
