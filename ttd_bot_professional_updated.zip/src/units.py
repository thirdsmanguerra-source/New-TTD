import random
from datetime import datetime

RARITY_COLORS = {
    "Basic": 0x808080,
    "Uncommon": 0x00FF00,
    "Rare": 0x0080FF,
    "Epic": 0x8000FF,
    "Legendary": 0xFFD700,
    "Mythic": 0xFF00FF,
    "Godly": 0xFF0000,
    "Celestial": 0x00FFFF,
    "Exclusive": 0xFFFFFF
}

RARITY_EMOJIS = {
    "Basic": "⚪",
    "Uncommon": "🟢",
    "Rare": "🔵",
    "Epic": "🟣",
    "Legendary": "🟡",
    "Mythic": "🔮",
    "Godly": "🔴",
    "Celestial": "💠",
    "Exclusive": "⭐"
}

ABILITY_EMOJIS = {
    "aoe": "💥",
    "stun": "⚡",
    "burn": "🔥",
    "heal": "💚",
    "boost": "⬆️",
    "pierce": "🎯",
    "splash": "💦",
    "slow": "🐌",
    "wormhole": "🌀",
    "quantum": "⚛️",
    "shield": "🛡️",
    "lifesteal": "🩸",
    "crit": "💢",
    "freeze": "❄️",
    "poison": "☠️",
    "rage": "😡"
}

ABILITY_DESCRIPTIONS = {
    "aoe": "Area of Effect - Damages multiple enemies",
    "stun": "Stun - Briefly disables enemies",
    "burn": "Burn - Deals damage over time",
    "heal": "Heal - Restores ally HP",
    "boost": "Boost - Increases ally damage by 15%",
    "pierce": "Pierce - Attacks pass through enemies",
    "splash": "Splash - Damage spreads to nearby foes",
    "slow": "Slow - Reduces enemy speed by 30%",
    "wormhole": "Wormhole - Teleports enemies back on path",
    "quantum": "Quantum Pulse - AOE + 70% slow every 10s",
    "shield": "Shield - Blocks 25% incoming damage",
    "lifesteal": "Lifesteal - Heals for 20% of damage dealt",
    "crit": "Critical - 25% chance for 2x damage",
    "freeze": "Freeze - Completely stops enemies briefly",
    "poison": "Poison - Stacking damage over time",
    "rage": "Rage - Attack increases when HP is low"
}

SHINY_STAT_BOOST = 1.25
SHINY_CHANCE = 0.01

UNITS = [
    {"id": "cameraman", "name": "Cameraman", "rarity": "Basic", "type": "Camera", "attack": 10, "defense": 5, "range": 3, "cost": 50, "emoji": "📷", "ability": None, "dps": 15},
    {"id": "large_cameraman", "name": "Large Cameraman", "rarity": "Uncommon", "type": "Camera", "attack": 18, "defense": 12, "range": 4, "cost": 100, "emoji": "📹", "ability": None, "dps": 25},
    {"id": "camerawoman", "name": "Camerawoman", "rarity": "Uncommon", "type": "Camera", "attack": 15, "defense": 8, "range": 5, "cost": 120, "emoji": "📸", "ability": None, "dps": 22},
    {"id": "ninja_cameraman", "name": "Ninja Cameraman", "rarity": "Rare", "type": "Camera", "attack": 25, "defense": 10, "range": 4, "cost": 180, "emoji": "🥷", "ability": "stun", "dps": 45},
    {"id": "medic_cameraman", "name": "Medic Cameraman", "rarity": "Rare", "type": "Camera", "attack": 12, "defense": 15, "range": 3, "cost": 200, "emoji": "⚕️", "ability": "heal", "dps": 20},
    {"id": "jetpack_cameraman", "name": "Jetpack Cameraman", "rarity": "Rare", "type": "Camera", "attack": 28, "defense": 8, "range": 6, "cost": 220, "emoji": "🚀", "ability": None, "dps": 50},
    {"id": "scientist_cameraman", "name": "Scientist Cameraman", "rarity": "Epic", "type": "Camera", "attack": 30, "defense": 12, "range": 6, "cost": 350, "emoji": "🔬", "ability": "splash", "dps": 65},
    {"id": "engineer_cameraman", "name": "Engineer Cameraman", "rarity": "Epic", "type": "Camera", "attack": 28, "defense": 20, "range": 5, "cost": 400, "emoji": "🔧", "ability": "boost", "dps": 55},
    {"id": "corrupted_cameraman", "name": "Corrupted Cameraman", "rarity": "Epic", "type": "Camera", "attack": 35, "defense": 18, "range": 5, "cost": 450, "emoji": "👁️", "ability": "burn", "dps": 70},
    {"id": "sniper_cameraman", "name": "Sniper Cameraman", "rarity": "Epic", "type": "Camera", "attack": 50, "defense": 8, "range": 10, "cost": 500, "emoji": "🎯", "ability": "crit", "dps": 85},
    {"id": "titan_cameraman", "name": "Titan Cameraman", "rarity": "Legendary", "type": "Camera", "attack": 55, "defense": 40, "range": 8, "cost": 800, "emoji": "🦾", "ability": "aoe", "dps": 120},
    {"id": "upgraded_titan_cameraman", "name": "Upgraded Titan Cameraman", "rarity": "Mythic", "type": "Camera", "attack": 85, "defense": 60, "range": 10, "cost": 1500, "emoji": "⚡", "ability": "aoe", "dps": 200},
    {"id": "mech_cameraman", "name": "Mech Cameraman", "rarity": "Godly", "type": "Mech", "attack": 120, "defense": 80, "range": 12, "cost": 2500, "emoji": "🤖", "ability": "pierce", "dps": 350},
    
    {"id": "speakerman", "name": "Speakerman", "rarity": "Basic", "type": "Speaker", "attack": 12, "defense": 4, "range": 4, "cost": 60, "emoji": "🔊", "ability": None, "dps": 18},
    {"id": "large_speakerman", "name": "Large Speakerman", "rarity": "Uncommon", "type": "Speaker", "attack": 22, "defense": 10, "range": 5, "cost": 130, "emoji": "📢", "ability": None, "dps": 30},
    {"id": "dark_speakerman", "name": "Dark Speakerman", "rarity": "Rare", "type": "Speaker", "attack": 32, "defense": 8, "range": 4, "cost": 220, "emoji": "🖤", "ability": "burn", "dps": 55},
    {"id": "sonic_speakerman", "name": "Sonic Speakerman", "rarity": "Rare", "type": "Speaker", "attack": 26, "defense": 12, "range": 6, "cost": 240, "emoji": "🎵", "ability": "slow", "dps": 48},
    {"id": "dj_speakerman", "name": "DJ Speakerman", "rarity": "Epic", "type": "Speaker", "attack": 38, "defense": 15, "range": 6, "cost": 420, "emoji": "🎧", "ability": "boost", "dps": 75},
    {"id": "announcer_speakerman", "name": "Announcer Speakerman", "rarity": "Epic", "type": "Speaker", "attack": 32, "defense": 18, "range": 7, "cost": 380, "emoji": "📣", "ability": "boost", "dps": 60},
    {"id": "bass_speakerman", "name": "Bass Speakerman", "rarity": "Epic", "type": "Speaker", "attack": 42, "defense": 20, "range": 5, "cost": 460, "emoji": "🔉", "ability": "stun", "dps": 78},
    {"id": "titan_speakerman", "name": "Titan Speakerman", "rarity": "Legendary", "type": "Speaker", "attack": 60, "defense": 35, "range": 9, "cost": 850, "emoji": "🎵", "ability": "aoe", "dps": 130},
    {"id": "upgraded_titan_speakerman", "name": "Upgraded Titan Speakerman", "rarity": "Mythic", "type": "Speaker", "attack": 90, "defense": 55, "range": 11, "cost": 1600, "emoji": "🎶", "ability": "aoe", "dps": 220},
    {"id": "wormhole_speakerman", "name": "Wormhole Speakerman", "rarity": "Godly", "type": "Speaker", "attack": 100, "defense": 70, "range": 10, "cost": 2200, "emoji": "🌀", "ability": "wormhole", "dps": 300},
    
    {"id": "tv_man", "name": "TV Man", "rarity": "Basic", "type": "TV", "attack": 8, "defense": 8, "range": 3, "cost": 55, "emoji": "📺", "ability": None, "dps": 12},
    {"id": "tv_woman", "name": "TV Woman", "rarity": "Rare", "type": "TV", "attack": 28, "defense": 18, "range": 5, "cost": 250, "emoji": "🖥️", "ability": "burn", "dps": 50},
    {"id": "large_tv_man", "name": "Large TV Man", "rarity": "Uncommon", "type": "TV", "attack": 16, "defense": 14, "range": 4, "cost": 140, "emoji": "🎬", "ability": None, "dps": 24},
    {"id": "plasma_tv_man", "name": "Plasma TV Man", "rarity": "Rare", "type": "TV", "attack": 30, "defense": 15, "range": 5, "cost": 260, "emoji": "⚡", "ability": "freeze", "dps": 52},
    {"id": "dj_tv_man", "name": "DJ TV Man", "rarity": "Legendary", "type": "TV", "attack": 45, "defense": 30, "range": 6, "cost": 700, "emoji": "🎛️", "ability": "boost", "dps": 95},
    {"id": "titan_tv_man", "name": "Titan TV Man", "rarity": "Legendary", "type": "TV", "attack": 50, "defense": 45, "range": 7, "cost": 780, "emoji": "📡", "ability": "stun", "dps": 110},
    {"id": "titan_cinemaman", "name": "Titan Cinemaman", "rarity": "Mythic", "type": "TV", "attack": 80, "defense": 65, "range": 9, "cost": 1400, "emoji": "🎥", "ability": "aoe", "dps": 180},
    {"id": "upgraded_titan_cinemaman", "name": "Upgraded Titan Cinemaman", "rarity": "Godly", "type": "TV", "attack": 150, "defense": 90, "range": 12, "cost": 3000, "emoji": "🎞️", "ability": "pierce", "dps": 400},
    
    {"id": "camera_helicopter", "name": "Camera Helicopter", "rarity": "Epic", "type": "Vehicle", "attack": 35, "defense": 22, "range": 7, "cost": 450, "emoji": "🚁", "ability": "aoe", "dps": 70},
    {"id": "speaker_helicopter", "name": "Speaker Helicopter", "rarity": "Epic", "type": "Vehicle", "attack": 40, "defense": 18, "range": 8, "cost": 480, "emoji": "🛩️", "ability": "aoe", "dps": 80},
    {"id": "camera_attack_helicopter", "name": "Camera Attack Helicopter", "rarity": "Legendary", "type": "Vehicle", "attack": 65, "defense": 30, "range": 9, "cost": 900, "emoji": "✈️", "ability": "pierce", "dps": 145},
    {"id": "stealth_bomber", "name": "Stealth Bomber", "rarity": "Mythic", "type": "Vehicle", "attack": 100, "defense": 40, "range": 12, "cost": 1800, "emoji": "🛸", "ability": "aoe", "dps": 250},
    
    {"id": "clockman", "name": "Clockman", "rarity": "Rare", "type": "Clock", "attack": 24, "defense": 12, "range": 5, "cost": 200, "emoji": "⏰", "ability": "slow", "dps": 40},
    {"id": "chrono_clockman", "name": "Chrono Clockman", "rarity": "Epic", "type": "Clock", "attack": 36, "defense": 22, "range": 6, "cost": 420, "emoji": "⌚", "ability": "freeze", "dps": 68},
    {"id": "titan_clockman", "name": "Titan Clockman", "rarity": "Legendary", "type": "Clock", "attack": 52, "defense": 38, "range": 8, "cost": 820, "emoji": "🕐", "ability": "slow", "dps": 115},
    {"id": "quantum_clockman", "name": "Quantum Clockman", "rarity": "Godly", "type": "Clock", "attack": 110, "defense": 75, "range": 11, "cost": 2400, "emoji": "⚛️", "ability": "quantum", "dps": 320},
    
    {"id": "drillman", "name": "Drillman", "rarity": "Rare", "type": "Drill", "attack": 30, "defense": 15, "range": 3, "cost": 230, "emoji": "⛏️", "ability": "pierce", "dps": 52},
    {"id": "mega_drillman", "name": "Mega Drillman", "rarity": "Epic", "type": "Drill", "attack": 45, "defense": 28, "range": 4, "cost": 440, "emoji": "🔨", "ability": "pierce", "dps": 82},
    {"id": "titan_drillman", "name": "Titan Drillman", "rarity": "Legendary", "type": "Drill", "attack": 58, "defense": 42, "range": 6, "cost": 860, "emoji": "🔩", "ability": "pierce", "dps": 125},
    
    {"id": "medic_speakerman", "name": "Medic Speakerman", "rarity": "Rare", "type": "Support", "attack": 14, "defense": 18, "range": 4, "cost": 220, "emoji": "💊", "ability": "heal", "dps": 22},
    {"id": "shield_cameraman", "name": "Shield Cameraman", "rarity": "Epic", "type": "Support", "attack": 20, "defense": 35, "range": 3, "cost": 380, "emoji": "🛡️", "ability": "shield", "dps": 35},
    {"id": "vampire_tv_man", "name": "Vampire TV Man", "rarity": "Epic", "type": "Support", "attack": 38, "defense": 20, "range": 5, "cost": 440, "emoji": "🧛", "ability": "lifesteal", "dps": 72},
    {"id": "berserker_cameraman", "name": "Berserker Cameraman", "rarity": "Legendary", "type": "Special", "attack": 70, "defense": 25, "range": 4, "cost": 750, "emoji": "😡", "ability": "rage", "dps": 140},
    {"id": "poison_speakerman", "name": "Poison Speakerman", "rarity": "Legendary", "type": "Special", "attack": 48, "defense": 32, "range": 6, "cost": 720, "emoji": "☠️", "ability": "poison", "dps": 105},
    
    {"id": "astro_cameraman", "name": "Astro Cameraman", "rarity": "Celestial", "type": "Special", "attack": 150, "defense": 100, "range": 15, "cost": 5000, "emoji": "🌟", "ability": "aoe", "dps": 450},
    {"id": "glitch_cameraman", "name": "Glitch Cameraman", "rarity": "Celestial", "type": "Special", "attack": 180, "defense": 70, "range": 13, "cost": 5500, "emoji": "👾", "ability": "pierce", "dps": 500},
    {"id": "cosmic_speakerman", "name": "Cosmic Speakerman", "rarity": "Celestial", "type": "Special", "attack": 160, "defense": 90, "range": 14, "cost": 5200, "emoji": "🌌", "ability": "quantum", "dps": 480},
    {"id": "titan_titan_man", "name": "Titan Titan Man", "rarity": "Exclusive", "type": "Fusion", "attack": 200, "defense": 120, "range": 14, "cost": 6000, "emoji": "💎", "ability": "aoe", "dps": 600},
    {"id": "ultimate_cameraman", "name": "Ultimate Cameraman", "rarity": "Exclusive", "type": "Fusion", "attack": 220, "defense": 130, "range": 15, "cost": 6500, "emoji": "👑", "ability": "pierce", "dps": 650},
    {"id": "omega_speakerman", "name": "Omega Speakerman", "rarity": "Exclusive", "type": "Fusion", "attack": 210, "defense": 140, "range": 14, "cost": 6200, "emoji": "Ω", "ability": "quantum", "dps": 620},
]

ENEMIES = [
    {"id": "toilet", "name": "Toilet", "hp": 20, "damage": 5, "reward": 10, "emoji": "🚽", "type": "normal", "speed": 1.0},
    {"id": "large_toilet", "name": "Large Toilet", "hp": 50, "damage": 10, "reward": 25, "emoji": "🪠", "type": "normal", "speed": 0.8},
    {"id": "fast_toilet", "name": "Fast Toilet", "hp": 30, "damage": 8, "reward": 20, "emoji": "💨", "type": "fast", "speed": 1.8},
    {"id": "g_toilet", "name": "G-Toilet", "hp": 80, "damage": 15, "reward": 40, "emoji": "💩", "type": "armored", "speed": 0.7},
    {"id": "scientist_toilet", "name": "Scientist Toilet", "hp": 120, "damage": 20, "reward": 60, "emoji": "🧪", "type": "normal", "speed": 1.0},
    {"id": "dual_toilet", "name": "Dual Toilet", "hp": 160, "damage": 25, "reward": 80, "emoji": "🚿", "type": "normal", "speed": 0.9},
    {"id": "spider_toilet", "name": "Spider Toilet", "hp": 200, "damage": 30, "reward": 100, "emoji": "🕷️", "type": "fast", "speed": 1.5},
    {"id": "rocket_toilet", "name": "Rocket Toilet", "hp": 250, "damage": 35, "reward": 130, "emoji": "🚀", "type": "flying", "speed": 2.0},
    {"id": "armored_toilet", "name": "Armored Toilet", "hp": 400, "damage": 28, "reward": 150, "emoji": "🔒", "type": "armored", "speed": 0.5},
    {"id": "strider_toilet", "name": "Strider Toilet", "hp": 300, "damage": 40, "reward": 160, "emoji": "🦿", "type": "armored", "speed": 0.6},
    {"id": "glass_toilet", "name": "Glass Toilet", "hp": 150, "damage": 50, "reward": 200, "emoji": "🔮", "type": "glass", "speed": 1.2},
    {"id": "stealth_toilet", "name": "Stealth Toilet", "hp": 180, "damage": 45, "reward": 180, "emoji": "👻", "type": "stealth", "speed": 1.3},
    {"id": "healer_toilet", "name": "Healer Toilet", "hp": 220, "damage": 20, "reward": 170, "emoji": "💚", "type": "healer", "speed": 0.9},
    {"id": "g_man_toilet", "name": "G-Man Toilet", "hp": 500, "damage": 60, "reward": 300, "emoji": "👔", "type": "boss", "speed": 0.8},
    {"id": "titan_toilet", "name": "Titan Toilet", "hp": 1000, "damage": 100, "reward": 600, "emoji": "💀", "type": "boss", "speed": 0.6},
    {"id": "upgraded_titan_toilet", "name": "Upgraded Titan Toilet", "hp": 2000, "damage": 150, "reward": 1200, "emoji": "☠️", "type": "boss", "speed": 0.5},
    {"id": "astro_toilet", "name": "Astro Toilet", "hp": 3500, "damage": 200, "reward": 2000, "emoji": "🌌", "type": "boss", "speed": 0.7},
    {"id": "glitch_toilet", "name": "Glitch Toilet", "hp": 5000, "damage": 250, "reward": 3000, "emoji": "👾", "type": "boss", "speed": 1.0},
    {"id": "omega_toilet", "name": "Omega Toilet", "hp": 7500, "damage": 300, "reward": 4500, "emoji": "Ω", "type": "boss", "speed": 0.4},
    {"id": "final_toilet", "name": "The Final Toilet", "hp": 10000, "damage": 400, "reward": 6000, "emoji": "🏆", "type": "boss", "speed": 0.3},
]

BOSS_ABILITIES = {
    "g_man_toilet": {"name": "Summon Minions", "effect": "Spawns 3 small toilets"},
    "titan_toilet": {"name": "Ground Pound", "effect": "Stuns all front units for 2s"},
    "upgraded_titan_toilet": {"name": "Rage Mode", "effect": "50% damage boost at 50% HP"},
    "astro_toilet": {"name": "Meteor Shower", "effect": "AOE damage to all units"},
    "glitch_toilet": {"name": "Reality Break", "effect": "Teleports randomly, immune to slow"},
    "omega_toilet": {"name": "Omega Beam", "effect": "Piercing laser that ignores defense"},
    "final_toilet": {"name": "Apocalypse", "effect": "All abilities combined"}
}

MAPS = {
    "classic": {
        "id": "classic",
        "name": "Classic Map",
        "emoji": "🏠",
        "description": "The original TTD battleground",
        "difficulty_mult": 1.0,
        "reward_mult": 1.0,
        "unlock_level": 1,
        "color": 0x00AA00
    },
    "city": {
        "id": "city",
        "name": "Apocalypse City",
        "emoji": "🏙️",
        "description": "Fight through destroyed city streets",
        "difficulty_mult": 1.2,
        "reward_mult": 1.3,
        "unlock_level": 5,
        "color": 0x666666
    },
    "steampunk": {
        "id": "steampunk",
        "name": "Steampunk Factory",
        "emoji": "⚙️",
        "description": "Gears and steam power the battlefield",
        "difficulty_mult": 1.4,
        "reward_mult": 1.5,
        "unlock_level": 10,
        "special": "30% chance for bonus crate keys",
        "color": 0xB87333
    },
    "wastelands": {
        "id": "wastelands",
        "name": "Wastelands",
        "emoji": "☢️",
        "description": "A toxic wasteland with dangerous enemies",
        "difficulty_mult": 1.6,
        "reward_mult": 1.8,
        "unlock_level": 15,
        "special": "Enemies deal poison damage",
        "color": 0x8B4513
    },
    "space": {
        "id": "space",
        "name": "Space Station",
        "emoji": "🚀",
        "description": "Zero gravity combat in space",
        "difficulty_mult": 1.8,
        "reward_mult": 2.0,
        "unlock_level": 20,
        "special": "Flying enemies more common",
        "color": 0x191970
    },
    "void": {
        "id": "void",
        "name": "The Void",
        "emoji": "🕳️",
        "description": "The ultimate challenge awaits",
        "difficulty_mult": 2.5,
        "reward_mult": 3.0,
        "unlock_level": 30,
        "special": "All enemy types spawn",
        "color": 0x1a0033
    }
}

DIFFICULTIES = {
    "easy": {"name": "Easy", "emoji": "🟢", "hp_mult": 0.7, "damage_mult": 0.7, "reward_mult": 0.8, "max_wave": 20, "color": 0x00FF00},
    "normal": {"name": "Normal", "emoji": "🟡", "hp_mult": 1.0, "damage_mult": 1.0, "reward_mult": 1.0, "max_wave": 40, "color": 0xFFFF00},
    "hard": {"name": "Hard", "emoji": "🟠", "hp_mult": 1.5, "damage_mult": 1.3, "reward_mult": 1.5, "max_wave": 60, "color": 0xFF8C00},
    "nightmare": {"name": "Nightmare", "emoji": "🔴", "hp_mult": 2.0, "damage_mult": 1.7, "reward_mult": 2.0, "max_wave": 80, "color": 0xFF0000},
    "endless": {"name": "Endless", "emoji": "💀", "hp_mult": 1.2, "damage_mult": 1.2, "reward_mult": 1.3, "max_wave": 999, "color": 0x800080}
}

CRATES = {
    "standard": {"name": "Standard Crate", "emoji": "📦", "cost": 100, "currency": "coins", "rates": {"Basic": 40, "Uncommon": 35, "Rare": 20, "Epic": 4.5, "Legendary": 0.5}},
    "premium": {"name": "Premium Crate", "emoji": "💎", "cost": 50, "currency": "gems", "rates": {"Rare": 50, "Epic": 35, "Legendary": 12, "Mythic": 2.8, "Godly": 0.2}},
    "mythic": {"name": "Mythic Crate", "emoji": "🔮", "cost": 150, "currency": "gems", "rates": {"Epic": 40, "Legendary": 35, "Mythic": 20, "Godly": 4.5, "Celestial": 0.5}},
    "titan": {"name": "Titan Crate", "emoji": "⚡", "cost": 200, "currency": "gems", "rates": {"Legendary": 60, "Mythic": 30, "Godly": 9, "Celestial": 1}},
    "event": {"name": "Event Crate", "emoji": "🎉", "cost": 100, "currency": "event_tokens", "rates": {"Rare": 35, "Epic": 40, "Legendary": 20, "Mythic": 4.5, "Godly": 0.5}}
}

GACHA_RATES = {
    "Basic": 40.0,
    "Uncommon": 30.0,
    "Rare": 18.0,
    "Epic": 8.0,
    "Legendary": 3.0,
    "Mythic": 0.8,
    "Godly": 0.15,
    "Celestial": 0.05
}

ACHIEVEMENTS = {
    "first_win": {"name": "First Victory", "description": "Win your first battle", "reward_coins": 100, "reward_gems": 10, "emoji": "🏆", "requirement": {"wins": 1}},
    "collector_10": {"name": "Collector", "description": "Collect 10 units", "reward_coins": 200, "reward_gems": 15, "emoji": "📦", "requirement": {"units": 10}},
    "collector_50": {"name": "Hoarder", "description": "Collect 50 units", "reward_coins": 500, "reward_gems": 50, "emoji": "🗄️", "requirement": {"units": 50}},
    "wave_10": {"name": "Wave Warrior", "description": "Reach wave 10", "reward_coins": 150, "reward_gems": 10, "emoji": "🌊", "requirement": {"wave": 10}},
    "wave_25": {"name": "Wave Master", "description": "Reach wave 25", "reward_coins": 300, "reward_gems": 25, "emoji": "🌊", "requirement": {"wave": 25}},
    "wave_50": {"name": "Wave Legend", "description": "Reach wave 50", "reward_coins": 600, "reward_gems": 60, "emoji": "🌊", "requirement": {"wave": 50}},
    "wave_100": {"name": "Wave God", "description": "Reach wave 100", "reward_coins": 1500, "reward_gems": 150, "emoji": "👑", "requirement": {"wave": 100}},
    "shiny_hunter": {"name": "Shiny Hunter", "description": "Obtain a shiny unit", "reward_coins": 500, "reward_gems": 50, "emoji": "✨", "requirement": {"shiny": 1}},
    "mythic_pull": {"name": "Mythic Pull", "description": "Summon a Mythic unit", "reward_coins": 400, "reward_gems": 40, "emoji": "🔮", "requirement": {"mythic": 1}},
    "godly_pull": {"name": "Godly Pull", "description": "Summon a Godly unit", "reward_coins": 800, "reward_gems": 80, "emoji": "🔴", "requirement": {"godly": 1}},
    "celestial_pull": {"name": "Celestial Pull", "description": "Summon a Celestial unit", "reward_coins": 1500, "reward_gems": 150, "emoji": "💠", "requirement": {"celestial": 1}},
    "win_streak_5": {"name": "Hot Streak", "description": "Win 5 battles in a row", "reward_coins": 300, "reward_gems": 30, "emoji": "🔥", "requirement": {"streak": 5}},
    "win_streak_10": {"name": "Unstoppable", "description": "Win 10 battles in a row", "reward_coins": 700, "reward_gems": 70, "emoji": "💪", "requirement": {"streak": 10}},
    "boss_slayer": {"name": "Boss Slayer", "description": "Defeat 10 bosses", "reward_coins": 400, "reward_gems": 40, "emoji": "💀", "requirement": {"bosses": 10}},
    "boss_master": {"name": "Boss Master", "description": "Defeat 50 bosses", "reward_coins": 1000, "reward_gems": 100, "emoji": "☠️", "requirement": {"bosses": 50}},
    "millionaire": {"name": "Millionaire", "description": "Earn 1,000,000 total coins", "reward_coins": 5000, "reward_gems": 500, "emoji": "💰", "requirement": {"total_coins": 1000000}},
    "level_10": {"name": "Rising Star", "description": "Reach level 10", "reward_coins": 200, "reward_gems": 20, "emoji": "⭐", "requirement": {"level": 10}},
    "level_25": {"name": "Veteran", "description": "Reach level 25", "reward_coins": 500, "reward_gems": 50, "emoji": "🌟", "requirement": {"level": 25}},
    "level_50": {"name": "Elite", "description": "Reach level 50", "reward_coins": 1000, "reward_gems": 100, "emoji": "💫", "requirement": {"level": 50}},
    "nightmare_clear": {"name": "Nightmare Survivor", "description": "Complete Nightmare difficulty", "reward_coins": 2000, "reward_gems": 200, "emoji": "😱", "requirement": {"nightmare_clear": 1}},
    "endless_50": {"name": "Endless Explorer", "description": "Reach wave 50 in Endless", "reward_coins": 1000, "reward_gems": 100, "emoji": "♾️", "requirement": {"endless_wave": 50}},
}

EVENTS = {
    "summer_splash": {
        "name": "Summer Splash",
        "emoji": "🏖️",
        "description": "Summer themed units and bonuses!",
        "bonus_coins": 1.5,
        "bonus_gems": 1.2,
        "special_units": ["beach_cameraman", "surfer_speakerman"],
        "color": 0xFFD700
    },
    "halloween_hunt": {
        "name": "Halloween Hunt",
        "emoji": "🎃",
        "description": "Spooky units emerge from the shadows!",
        "bonus_coins": 1.3,
        "bonus_gems": 1.5,
        "special_units": ["ghost_cameraman", "vampire_tv_man"],
        "color": 0xFF6600
    },
    "winter_wonderland": {
        "name": "Winter Wonderland",
        "emoji": "❄️",
        "description": "Frozen foes and icy units!",
        "bonus_coins": 1.4,
        "bonus_gems": 1.4,
        "special_units": ["frost_cameraman", "snowman_speakerman"],
        "color": 0x87CEEB
    },
    "anniversary": {
        "name": "Anniversary Celebration",
        "emoji": "🎂",
        "description": "Special anniversary rewards!",
        "bonus_coins": 2.0,
        "bonus_gems": 2.0,
        "special_units": ["anniversary_titan"],
        "color": 0xFF69B4
    }
}

EVENT_UNITS = [
    {"id": "beach_cameraman", "name": "Beach Cameraman", "rarity": "Epic", "type": "Event", "attack": 38, "defense": 22, "range": 6, "cost": 0, "emoji": "🏖️", "ability": "splash", "dps": 72, "event": "summer_splash"},
    {"id": "surfer_speakerman", "name": "Surfer Speakerman", "rarity": "Legendary", "type": "Event", "attack": 55, "defense": 35, "range": 7, "cost": 0, "emoji": "🏄", "ability": "aoe", "dps": 115, "event": "summer_splash"},
    {"id": "ghost_cameraman", "name": "Ghost Cameraman", "rarity": "Epic", "type": "Event", "attack": 42, "defense": 15, "range": 8, "cost": 0, "emoji": "👻", "ability": "pierce", "dps": 78, "event": "halloween_hunt"},
    {"id": "frost_cameraman", "name": "Frost Cameraman", "rarity": "Legendary", "type": "Event", "attack": 50, "defense": 40, "range": 7, "cost": 0, "emoji": "🥶", "ability": "freeze", "dps": 105, "event": "winter_wonderland"},
    {"id": "snowman_speakerman", "name": "Snowman Speakerman", "rarity": "Epic", "type": "Event", "attack": 35, "defense": 30, "range": 5, "cost": 0, "emoji": "⛄", "ability": "slow", "dps": 65, "event": "winter_wonderland"},
    {"id": "anniversary_titan", "name": "Anniversary Titan", "rarity": "Mythic", "type": "Event", "attack": 95, "defense": 70, "range": 10, "cost": 0, "emoji": "🎂", "ability": "aoe", "dps": 210, "event": "anniversary"},
]

def get_units_by_rarity(rarity: str):
    return [u for u in UNITS if u['rarity'] == rarity]

def roll_for_shiny():
    return random.random() < SHINY_CHANCE

def apply_shiny_bonus(unit: dict):
    unit['is_shiny'] = True
    unit['attack'] = int(unit['attack'] * SHINY_STAT_BOOST)
    unit['defense'] = int(unit['defense'] * SHINY_STAT_BOOST)
    unit['dps'] = int(unit.get('dps', unit['attack']) * SHINY_STAT_BOOST)
    unit['name'] = f"✨ {unit['name']}"
    return unit

def roll_gacha(rates=None, shiny_boost=1.0):
    if rates is None:
        rates = GACHA_RATES
    
    roll = random.uniform(0, 100)
    cumulative = 0
    
    for rarity, rate in rates.items():
        cumulative += rate
        if roll <= cumulative:
            units = get_units_by_rarity(rarity)
            if units:
                unit = random.choice(units).copy()
                if roll_for_shiny() or random.random() < (SHINY_CHANCE * (shiny_boost - 1)):
                    unit = apply_shiny_bonus(unit)
                return unit
    
    return random.choice(get_units_by_rarity("Basic")).copy()

def roll_crate(crate_type: str, shiny_boost=1.0):
    if crate_type not in CRATES:
        return None
    
    crate = CRATES[crate_type]
    return roll_gacha(crate["rates"], shiny_boost)

def get_enemies_for_wave(wave: int, difficulty: str = "normal", map_id: str = "classic"):
    diff = DIFFICULTIES.get(difficulty, DIFFICULTIES["normal"])
    map_data = MAPS.get(map_id, MAPS["classic"])
    enemies = []
    base_count = min(3 + wave // 2, 25)
    
    available_enemies = [e for e in ENEMIES if ENEMIES.index(e) <= min(wave // 3, len(ENEMIES) - 1) and e['type'] != 'boss']
    
    if map_id == "space":
        flying_enemies = [e for e in available_enemies if e['type'] == 'flying']
        if flying_enemies:
            for _ in range(base_count // 3):
                enemy = random.choice(flying_enemies).copy()
                enemies.append(enemy)
    
    for _ in range(base_count - len(enemies)):
        enemy = random.choice(available_enemies).copy()
        wave_multiplier = 1 + (wave * 0.12)
        map_mult = map_data['difficulty_mult']
        enemy['hp'] = int(enemy['hp'] * wave_multiplier * diff['hp_mult'] * map_mult)
        enemy['damage'] = int(enemy['damage'] * wave_multiplier * diff['damage_mult'] * map_mult)
        enemy['reward'] = int(enemy['reward'] * wave_multiplier * diff['reward_mult'] * map_data['reward_mult'])
        enemies.append(enemy)
    
    if wave % 5 == 0 and wave > 0:
        boss_index = min(wave // 5, len([e for e in ENEMIES if e['type'] == 'boss']) - 1)
        bosses = [e for e in ENEMIES if e['type'] == 'boss']
        if bosses and boss_index < len(bosses):
            boss = bosses[boss_index].copy()
            boss['hp'] = int(boss['hp'] * (2.5 + wave * 0.18) * diff['hp_mult'] * map_data['difficulty_mult'])
            boss['damage'] = int(boss['damage'] * (1.8 + wave * 0.12) * diff['damage_mult'] * map_data['difficulty_mult'])
            boss['reward'] = int(boss['reward'] * 4 * diff['reward_mult'] * map_data['reward_mult'])
            boss['name'] = f"👑 BOSS: {boss['name']}"
            boss['is_boss'] = True
            if boss['id'] in BOSS_ABILITIES:
                boss['boss_ability'] = BOSS_ABILITIES[boss['id']]
            enemies.append(boss)
    
    return enemies

def calculate_battle_power(units: list):
    total_attack = sum(u['attack'] * (1 + (u.get('level', 1) - 1) * 0.1) for u in units)
    total_defense = sum(u['defense'] * (1 + (u.get('level', 1) - 1) * 0.05) for u in units)
    total_range = sum(u['range'] for u in units)
    
    ability_bonus = sum(10 for u in units if u.get('ability'))
    shiny_bonus = sum(20 for u in units if u.get('is_shiny'))
    
    return int(total_attack + total_defense * 0.5 + total_range * 0.3 + ability_bonus + shiny_bonus)

def get_ability_effect(ability: str, base_value: float) -> dict:
    effects = {
        "boost": {"damage_mult": 1.15},
        "slow": {"enemy_speed_mult": 0.7},
        "stun": {"stun_chance": 0.2, "stun_duration": 1},
        "burn": {"dot_damage": base_value * 0.1, "dot_duration": 3},
        "poison": {"dot_damage": base_value * 0.08, "dot_duration": 5, "stacking": True},
        "freeze": {"freeze_chance": 0.15, "freeze_duration": 2},
        "heal": {"heal_amount": base_value * 0.05},
        "shield": {"damage_reduction": 0.25},
        "lifesteal": {"lifesteal_percent": 0.2},
        "crit": {"crit_chance": 0.25, "crit_mult": 2.0},
        "rage": {"damage_mult_low_hp": 1.5},
        "pierce": {"pierce_count": 3},
        "aoe": {"aoe_percent": 0.5, "aoe_range": 2},
        "splash": {"splash_percent": 0.3, "splash_range": 1},
        "wormhole": {"teleport_chance": 0.1, "teleport_distance": 5},
        "quantum": {"aoe_percent": 0.4, "slow_percent": 0.7, "cooldown": 10}
    }
    return effects.get(ability, {})

def simulate_wave(player_units: list, enemies: list, is_boss_wave: bool = False):
    if not player_units:
        return {"won": False, "player_hp": 0, "rounds": 0, "coins_earned": 0, "enemies_defeated": 0, "damage_dealt": 0, "bosses_defeated": 0, "is_boss_wave": is_boss_wave}
    
    shiny_mult = 1 + sum(0.1 for u in player_units if u.get('is_shiny'))
    total_dps = sum(u.get('dps', u['attack']) * (1 + (u.get('level', 1) - 1) * 0.15) for u in player_units) * shiny_mult
    total_defense = sum(u['defense'] * (1 + (u.get('level', 1) - 1) * 0.1) for u in player_units)
    
    if is_boss_wave:
        for e in enemies:
            e['hp'] = int(e['hp'] * 2.5)
            e['damage'] = int(e['damage'] * 1.5)
            e['reward'] = int(e['reward'] * 3)
    
    boost_multiplier = 1 + sum(0.15 for u in player_units if u.get('ability') == 'boost')
    slow_count = sum(1 for u in player_units if u.get('ability') in ['slow', 'freeze', 'quantum'])
    stun_units = sum(1 for u in player_units if u.get('ability') == 'stun')
    heal_amount = sum(u['defense'] * 0.05 for u in player_units if u.get('ability') == 'heal')
    shield_reduction = min(0.5, sum(0.1 for u in player_units if u.get('ability') == 'shield'))
    lifesteal = sum(0.05 for u in player_units if u.get('ability') == 'lifesteal')
    crit_chance = min(0.5, sum(0.08 for u in player_units if u.get('ability') == 'crit'))
    
    total_dps *= boost_multiplier
    
    total_enemy_hp = sum(e['hp'] for e in enemies)
    total_enemy_damage = sum(e['damage'] for e in enemies)
    total_rewards = sum(e['reward'] for e in enemies)
    bosses_in_wave = sum(1 for e in enemies if e.get('is_boss'))
    
    speed_reduction = 1 - (slow_count * 0.1)
    total_enemy_damage *= speed_reduction
    
    player_hp = 100
    damage_dealt = 0
    enemies_killed = 0
    bosses_killed = 0
    rounds = 0
    
    remaining_hp = total_enemy_hp
    
    while remaining_hp > 0 and player_hp > 0:
        rounds += 1
        
        damage_this_round = total_dps * random.uniform(0.85, 1.15)
        if random.random() < crit_chance:
            damage_this_round *= 2
        if stun_units > 0 and random.random() < 0.2:
            damage_this_round *= 1.3
        
        remaining_hp -= damage_this_round
        damage_dealt += damage_this_round
        
        if remaining_hp > 0:
            damage_taken = max(1, (total_enemy_damage * random.uniform(0.75, 1.1) * (remaining_hp / total_enemy_hp)) - total_defense * 0.25)
            damage_taken *= (1 - shield_reduction)
            player_hp -= damage_taken
            
            player_hp += heal_amount
            player_hp += damage_this_round * lifesteal
            player_hp = min(100, player_hp)
        
        if rounds > 100:
            break
    
    won = remaining_hp <= 0
    enemies_killed = len(enemies) if won else int(len(enemies) * (1 - max(0, remaining_hp) / total_enemy_hp))
    bosses_killed = bosses_in_wave if won else 0
    
    bonus_coins = total_rewards * 2 if is_boss_wave and won else 0
    
    return {
        "won": won,
        "player_hp": max(0, int(player_hp)),
        "rounds": rounds,
        "coins_earned": (total_rewards if won else int(total_rewards * 0.3)) + bonus_coins,
        "enemies_defeated": enemies_killed,
        "damage_dealt": int(damage_dealt),
        "bosses_defeated": bosses_killed,
        "is_boss_wave": is_boss_wave,
        "boss_bonus": bonus_coins
    }

def get_unit_value(unit: dict) -> int:
    rarity_values = {
        "Basic": 10, "Uncommon": 25, "Rare": 75, "Epic": 200,
        "Legendary": 500, "Mythic": 1500, "Godly": 5000,
        "Celestial": 15000, "Exclusive": 50000
    }
    base_value = rarity_values.get(unit.get('rarity', 'Basic'), 10)
    if unit.get('is_shiny'):
        base_value *= 3
    level_mult = 1 + (unit.get('level', 1) - 1) * 0.2
    return int(base_value * level_mult)

def get_marketplace_fee(value: int) -> int:
    return max(10, int(value * 0.05))
