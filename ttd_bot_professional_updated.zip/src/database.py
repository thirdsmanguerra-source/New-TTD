import aiosqlite
import os

DATABASE_PATH = "ttd_game.db"

MAX_LOADOUT_SLOTS = {
    "easy": 5,
    "normal": 6,
    "hard": 7,
    "nightmare": 8,
    "endless": 10
}

async def init_db():
    async with aiosqlite.connect(DATABASE_PATH) as db:
        await db.execute('''
            CREATE TABLE IF NOT EXISTS players (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                coins INTEGER DEFAULT 500,
                gems INTEGER DEFAULT 50,
                experience INTEGER DEFAULT 0,
                level INTEGER DEFAULT 1,
                wins INTEGER DEFAULT 0,
                losses INTEGER DEFAULT 0,
                highest_wave INTEGER DEFAULT 0,
                last_daily TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        await db.execute('''
            CREATE TABLE IF NOT EXISTS inventory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                unit_id TEXT,
                unit_name TEXT,
                rarity TEXT,
                level INTEGER DEFAULT 1,
                attack INTEGER,
                defense INTEGER,
                range INTEGER,
                obtained_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES players(user_id)
            )
        ''')
        
        await db.execute('''
            CREATE TABLE IF NOT EXISTS equipped_units (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                inventory_id INTEGER,
                slot INTEGER,
                placement TEXT DEFAULT 'front',
                UNIQUE(user_id, slot),
                UNIQUE(user_id, inventory_id),
                FOREIGN KEY (user_id) REFERENCES players(user_id),
                FOREIGN KEY (inventory_id) REFERENCES inventory(id) ON DELETE CASCADE
            )
        ''')
        
        await db.execute('''
            CREATE TABLE IF NOT EXISTS trades (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sender_id INTEGER,
                receiver_id INTEGER,
                unit_inventory_id INTEGER,
                status TEXT DEFAULT 'pending',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        await db.execute('''
            CREATE TABLE IF NOT EXISTS battle_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                current_wave INTEGER DEFAULT 1,
                hp INTEGER DEFAULT 100,
                coins_earned INTEGER DEFAULT 0,
                difficulty TEXT DEFAULT 'normal',
                is_active INTEGER DEFAULT 1,
                started_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        await db.execute('CREATE INDEX IF NOT EXISTS idx_inventory_user ON inventory(user_id)')
        await db.execute('CREATE INDEX IF NOT EXISTS idx_equipped_user ON equipped_units(user_id)')
        
        await db.execute('''
            CREATE TABLE IF NOT EXISTS achievements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                achievement_id TEXT,
                unlocked_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, achievement_id),
                FOREIGN KEY (user_id) REFERENCES players(user_id)
            )
        ''')
        
        await db.execute('''
            CREATE TABLE IF NOT EXISTS daily_streaks (
                user_id INTEGER PRIMARY KEY,
                current_streak INTEGER DEFAULT 0,
                longest_streak INTEGER DEFAULT 0,
                last_claim TEXT,
                total_claims INTEGER DEFAULT 0,
                FOREIGN KEY (user_id) REFERENCES players(user_id)
            )
        ''')
        
        await db.execute('''
            CREATE TABLE IF NOT EXISTS weekly_challenges (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                challenge_id TEXT,
                progress INTEGER DEFAULT 0,
                target INTEGER,
                completed INTEGER DEFAULT 0,
                week_start TEXT,
                FOREIGN KEY (user_id) REFERENCES players(user_id)
            )
        ''')
        
        await db.commit()

async def get_player(user_id: int):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            'SELECT * FROM players WHERE user_id = ?', (user_id,)
        )
        return await cursor.fetchone()

async def create_player(user_id: int, username: str):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        await db.execute(
            'INSERT OR IGNORE INTO players (user_id, username) VALUES (?, ?)',
            (user_id, username)
        )
        await db.commit()

async def update_player(user_id: int, **kwargs):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        sets = ', '.join(f'{k} = ?' for k in kwargs.keys())
        values = list(kwargs.values()) + [user_id]
        await db.execute(
            f'UPDATE players SET {sets} WHERE user_id = ?', values
        )
        await db.commit()

async def add_unit_to_inventory(user_id: int, unit_data: dict):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        cursor = await db.execute('''
            INSERT INTO inventory (user_id, unit_id, unit_name, rarity, attack, defense, range)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            user_id,
            unit_data['id'],
            unit_data['name'],
            unit_data['rarity'],
            unit_data['attack'],
            unit_data['defense'],
            unit_data['range']
        ))
        await db.commit()
        return cursor.lastrowid

async def get_inventory(user_id: int):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            'SELECT * FROM inventory WHERE user_id = ? ORDER BY rarity DESC, unit_name',
            (user_id,)
        )
        rows = await cursor.fetchall()
        return list(rows)

async def get_unit_by_id(inventory_id: int, user_id: int):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            'SELECT * FROM inventory WHERE id = ? AND user_id = ?',
            (inventory_id, user_id)
        )
        return await cursor.fetchone()

async def remove_unit(inventory_id: int, user_id: int):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        await db.execute(
            'DELETE FROM equipped_units WHERE inventory_id = ? AND user_id = ?',
            (inventory_id, user_id)
        )
        await db.execute(
            'DELETE FROM inventory WHERE id = ? AND user_id = ?',
            (inventory_id, user_id)
        )
        await db.commit()

async def transfer_unit(inventory_id: int, from_user: int, to_user: int):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        await db.execute(
            'DELETE FROM equipped_units WHERE inventory_id = ? AND user_id = ?',
            (inventory_id, from_user)
        )
        await db.execute(
            'UPDATE inventory SET user_id = ? WHERE id = ? AND user_id = ?',
            (to_user, inventory_id, from_user)
        )
        await db.commit()

async def get_leaderboard(order_by: str = 'wins', limit: int = 10):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            f'SELECT * FROM players ORDER BY {order_by} DESC LIMIT ?',
            (limit,)
        )
        rows = await cursor.fetchall()
        return list(rows)

async def equip_unit(user_id: int, inventory_id: int, slot: int, placement: str = 'front'):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        cursor = await db.execute(
            'SELECT id FROM inventory WHERE id = ? AND user_id = ?',
            (inventory_id, user_id)
        )
        if not await cursor.fetchone():
            return False, "Unit not found in your inventory"
        
        cursor = await db.execute(
            'SELECT slot FROM equipped_units WHERE inventory_id = ? AND user_id = ?',
            (inventory_id, user_id)
        )
        existing = await cursor.fetchone()
        if existing:
            return False, f"This unit is already equipped in slot {existing[0]}"
        
        await db.execute(
            'DELETE FROM equipped_units WHERE user_id = ? AND slot = ?',
            (user_id, slot)
        )
        
        await db.execute('''
            INSERT INTO equipped_units (user_id, inventory_id, slot, placement)
            VALUES (?, ?, ?, ?)
        ''', (user_id, inventory_id, slot, placement))
        await db.commit()
        return True, "Unit equipped successfully"

async def unequip_unit(user_id: int, slot: int):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        cursor = await db.execute(
            'SELECT inventory_id FROM equipped_units WHERE user_id = ? AND slot = ?',
            (user_id, slot)
        )
        if not await cursor.fetchone():
            return False, "No unit in that slot"
        
        await db.execute(
            'DELETE FROM equipped_units WHERE user_id = ? AND slot = ?',
            (user_id, slot)
        )
        await db.commit()
        return True, "Unit unequipped"

async def unequip_unit_by_inventory_id(user_id: int, inventory_id: int):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        cursor = await db.execute(
            'SELECT slot FROM equipped_units WHERE user_id = ? AND inventory_id = ?',
            (user_id, inventory_id)
        )
        result = await cursor.fetchone()
        if not result:
            return False, "Unit is not equipped"
        
        await db.execute(
            'DELETE FROM equipped_units WHERE user_id = ? AND inventory_id = ?',
            (user_id, inventory_id)
        )
        await db.commit()
        return True, f"Unit unequipped from slot {result[0]}"

async def get_equipped_units(user_id: int):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute('''
            SELECT e.slot, e.placement, i.*
            FROM equipped_units e
            JOIN inventory i ON e.inventory_id = i.id
            WHERE e.user_id = ?
            ORDER BY e.slot
        ''', (user_id,))
        rows = await cursor.fetchall()
        return list(rows)

async def get_loadout_count(user_id: int):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        cursor = await db.execute(
            'SELECT COUNT(*) FROM equipped_units WHERE user_id = ?',
            (user_id,)
        )
        result = await cursor.fetchone()
        return result[0] if result else 0

async def is_unit_equipped(user_id: int, inventory_id: int):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        cursor = await db.execute(
            'SELECT slot FROM equipped_units WHERE user_id = ? AND inventory_id = ?',
            (user_id, inventory_id)
        )
        result = await cursor.fetchone()
        return result[0] if result else None

async def update_unit_placement(user_id: int, slot: int, placement: str):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        await db.execute(
            'UPDATE equipped_units SET placement = ? WHERE user_id = ? AND slot = ?',
            (placement, user_id, slot)
        )
        await db.commit()

async def upgrade_unit(user_id: int, inventory_id: int, attack_boost: int, defense_boost: int):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        await db.execute('''
            UPDATE inventory 
            SET level = level + 1, 
                attack = attack + ?, 
                defense = defense + ?
            WHERE id = ? AND user_id = ?
        ''', (attack_boost, defense_boost, inventory_id, user_id))
        await db.commit()

async def get_duplicate_units(user_id: int, unit_id: str):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute('''
            SELECT i.* FROM inventory i
            LEFT JOIN equipped_units e ON i.id = e.inventory_id AND e.user_id = i.user_id
            WHERE i.user_id = ? AND i.unit_id = ? AND e.id IS NULL
            ORDER BY i.level ASC
        ''', (user_id, unit_id))
        rows = await cursor.fetchall()
        return list(rows)

async def create_battle_session(user_id: int, difficulty: str = 'normal'):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        await db.execute(
            'UPDATE battle_sessions SET is_active = 0 WHERE user_id = ?',
            (user_id,)
        )
        cursor = await db.execute(
            'INSERT INTO battle_sessions (user_id, difficulty) VALUES (?, ?)',
            (user_id, difficulty)
        )
        await db.commit()
        return cursor.lastrowid

async def get_active_battle(user_id: int):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            'SELECT * FROM battle_sessions WHERE user_id = ? AND is_active = 1',
            (user_id,)
        )
        return await cursor.fetchone()

async def update_battle(session_id: int, **kwargs):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        sets = ', '.join(f'{k} = ?' for k in kwargs.keys())
        values = list(kwargs.values()) + [session_id]
        await db.execute(
            f'UPDATE battle_sessions SET {sets} WHERE id = ?', values
        )
        await db.commit()

async def end_battle(session_id: int):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        await db.execute(
            'UPDATE battle_sessions SET is_active = 0 WHERE id = ?',
            (session_id,)
        )
        await db.commit()

async def clear_loadout(user_id: int):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        await db.execute(
            'DELETE FROM equipped_units WHERE user_id = ?',
            (user_id,)
        )
        await db.commit()

async def auto_equip_best_units(user_id: int, max_slots: int = 6):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        db.row_factory = aiosqlite.Row
        
        rarity_order = "CASE rarity " + \
            "WHEN 'Exclusive' THEN 1 " + \
            "WHEN 'Celestial' THEN 2 " + \
            "WHEN 'Godly' THEN 3 " + \
            "WHEN 'Mythic' THEN 4 " + \
            "WHEN 'Legendary' THEN 5 " + \
            "WHEN 'Epic' THEN 6 " + \
            "WHEN 'Rare' THEN 7 " + \
            "WHEN 'Uncommon' THEN 8 " + \
            "WHEN 'Basic' THEN 9 " + \
            "ELSE 10 END"
        
        cursor = await db.execute(f'''
            SELECT * FROM inventory 
            WHERE user_id = ? 
            ORDER BY {rarity_order}, (attack + defense) DESC, level DESC
            LIMIT ?
        ''', (user_id, max_slots))
        best_units = list(await cursor.fetchall())
        
        await db.execute('DELETE FROM equipped_units WHERE user_id = ?', (user_id,))
        
        for slot, unit in enumerate(best_units):
            placement = 'front' if slot < max_slots // 2 else 'back'
            await db.execute('''
                INSERT INTO equipped_units (user_id, inventory_id, slot, placement)
                VALUES (?, ?, ?, ?)
            ''', (user_id, unit['id'], slot, placement))
        
        await db.commit()
        return len(best_units)

async def get_achievements(user_id: int):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            'SELECT * FROM achievements WHERE user_id = ?', (user_id,)
        )
        return list(await cursor.fetchall())

async def unlock_achievement(user_id: int, achievement_id: str):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        try:
            await db.execute(
                'INSERT INTO achievements (user_id, achievement_id) VALUES (?, ?)',
                (user_id, achievement_id)
            )
            await db.commit()
            return True
        except:
            return False

async def has_achievement(user_id: int, achievement_id: str) -> bool:
    async with aiosqlite.connect(DATABASE_PATH) as db:
        cursor = await db.execute(
            'SELECT 1 FROM achievements WHERE user_id = ? AND achievement_id = ?',
            (user_id, achievement_id)
        )
        return await cursor.fetchone() is not None

async def get_daily_streak(user_id: int):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            'SELECT * FROM daily_streaks WHERE user_id = ?', (user_id,)
        )
        return await cursor.fetchone()

async def update_daily_streak(user_id: int, new_streak: int, last_claim: str):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        await db.execute('''
            INSERT INTO daily_streaks (user_id, current_streak, longest_streak, last_claim, total_claims)
            VALUES (?, ?, ?, ?, 1)
            ON CONFLICT(user_id) DO UPDATE SET
                current_streak = ?,
                longest_streak = MAX(longest_streak, ?),
                last_claim = ?,
                total_claims = total_claims + 1
        ''', (user_id, new_streak, new_streak, last_claim, new_streak, new_streak, last_claim))
        await db.commit()

async def fuse_units(user_id: int, unit_ids: list) -> dict:
    if len(unit_ids) < 3:
        return {"success": False, "error": "Need at least 3 units to fuse"}
    
    async with aiosqlite.connect(DATABASE_PATH) as db:
        db.row_factory = aiosqlite.Row
        
        placeholders = ','.join('?' for _ in unit_ids)
        cursor = await db.execute(f'''
            SELECT * FROM inventory 
            WHERE id IN ({placeholders}) AND user_id = ?
        ''', (*unit_ids, user_id))
        units = list(await cursor.fetchall())
        
        if len(units) != len(unit_ids):
            return {"success": False, "error": "Some units not found"}
        
        equipped_cursor = await db.execute(f'''
            SELECT inventory_id FROM equipped_units 
            WHERE inventory_id IN ({placeholders}) AND user_id = ?
        ''', (*unit_ids, user_id))
        equipped = await equipped_cursor.fetchone()
        if equipped:
            return {"success": False, "error": "Cannot fuse equipped units"}
        
        rarities = [u['rarity'] for u in units]
        if len(set(rarities)) != 1:
            return {"success": False, "error": "All units must be same rarity"}
        
        rarity_upgrade = {
            "Basic": "Uncommon",
            "Uncommon": "Rare",
            "Rare": "Epic",
            "Epic": "Legendary",
            "Legendary": "Mythic",
            "Mythic": "Godly",
            "Godly": "Celestial"
        }
        
        current_rarity = rarities[0]
        if current_rarity not in rarity_upgrade:
            return {"success": False, "error": "Cannot upgrade this rarity further"}
        
        new_rarity = rarity_upgrade[current_rarity]
        base_unit = units[0]
        
        new_attack = int(sum(u['attack'] for u in units) * 0.5)
        new_defense = int(sum(u['defense'] for u in units) * 0.5)
        new_range = max(u['range'] for u in units)
        
        for unit_id in unit_ids:
            await db.execute('DELETE FROM inventory WHERE id = ? AND user_id = ?', (unit_id, user_id))
        
        cursor = await db.execute('''
            INSERT INTO inventory (user_id, unit_id, unit_name, rarity, level, attack, defense, range)
            VALUES (?, ?, ?, ?, 1, ?, ?, ?)
        ''', (user_id, base_unit['unit_id'], base_unit['unit_name'], new_rarity, new_attack, new_defense, new_range))
        
        await db.commit()
        
        return {
            "success": True,
            "new_unit": {
                "id": cursor.lastrowid,
                "unit_id": base_unit['unit_id'],
                "unit_name": base_unit['unit_name'],
                "rarity": new_rarity,
                "attack": new_attack,
                "defense": new_defense,
                "range": new_range
            },
            "units_consumed": len(unit_ids)
        }
