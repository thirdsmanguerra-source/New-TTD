# keep_alive.py
# Simple Flask keep-alive server to prevent free hosts from idling.
from flask import Flask
import threading
import os

def start_keepalive(host="0.0.0.0", port=8080):
    app = Flask("keepalive")

    @app.route("/")
    def home():
        return "Bot is alive!", 200

    def run():
        app.run(host=host, port=int(os.environ.get("PORT", port)))

    t = threading.Thread(target=run)
    t.daemon = True
    t.start()