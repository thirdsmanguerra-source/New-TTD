
# Toilet Tower Defense Bot — Professional Layout

This is a professional, production-ready layout for your Discord bot with:
- Proper folder structure
- Ready for GitHub
- Ready for Replit / Railway / Render
- 24/7 uptime using Flask keep-alive + CronJob

## Folder Structure
```
/src
    main.py
    main_fixed.py
    main_patched.py
    database.py
    units.py
    keep_alive.py
/data
    ttd_game.db
/docs
    replit.md
requirements.txt
.replit
README.md
```

## Running on Replit
1. Import into Replit.
2. Go to Tools → Secrets → Add:
   - `DISCORD_TOKEN`
3. Install dependencies:
```
pip install -r requirements.txt
```
4. Run the repl.

## Keep Alive
`keep_alive.py` starts a Flask server so cron-job.org or UptimeRobot can ping:
`https://your-repl-name.username.repl.co/`

## 24/7 Hosting
- Go to https://cron-job.org
- Add a job to ping your Replit URL every 5 minutes
This prevents Replit from sleeping.

## Local Running
```
python src/main.py
```

## Notes
- Keep your token out of code.
- SQLite database is located in `/data`.
